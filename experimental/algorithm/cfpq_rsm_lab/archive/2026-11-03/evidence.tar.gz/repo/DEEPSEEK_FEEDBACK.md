# CFPQ RSM: DeepSeek results, questions, and feedback

Companion specification: [DEEPSEEK_INSTRUCTIONS.md](DEEPSEEK_INSTRUCTIONS.md).

DeepSeek owns this file. Append evidence and questions here; preserve earlier
reports. Codex records review decisions and revised assignments in the instruction
file. Do not mark your own implementation accepted.

## Session state

- Instructions acknowledged: **R9 (2026-11-02)** plus the user's direct activation of the
  three `DEEPSEEK_REMAINDER.md` candidates (D1, config_block, D3).  DS-00 and DS-01 stay
  accepted and are not reopened; DS-20/DS-21/DS-22 remain completed negative experiments
  (all 63 overnight rows matched) and are not reopened or rerun.
- Instruction revision: **R10 — D1, config_block and D3 prepared, smoke-checked and handed
  off together with the ten passing R9 variants**
- Current task: **ready-for-review; the user runs the 39 R10 overnight comparisons.**
  DeepSeek ran only the dry run; the long comparisons were deliberately not started.
- Baseline (frozen parent for every variant):
  `experimental/algorithm/cfpq_rsm_lab/variants/baseline.c`,
  sha256 `f3642839be04eee2d6411d3db9d6973c50c19f386d7e61f4d9ff5a926af0447b` (expected
  value; byte-identical to `experimental/algorithm/LAGraph_CFPQ_RSM.c`, which is unchanged)
- Passing variants included in the 13-variant R10 handoff: the ten R9 variants
  `variants/ds36_pair.c` `796030c0...`, `variants/ds37_fused.c` `21a56c43...`,
  `variants/ds38_no_product_clear.c` `ba91e5c4...`,
  `variants/ds39_direct_calls.c` `e9fbc199...`, `variants/ds30_assign.c` `9952a112...`,
  `variants/ds31_joint.c` `3b39940a...`, `variants/ds32_empty.c` `a156634d...`,
  `variants/ds33_format.c` `9196fb84...`, `variants/ds34_lazy_p.c` `7aa7d7cc...`,
  `variants/ds35_lazy_nt.c` `5c5331f4...`, plus `variants/d1_native.c` `c2d7e56d...`,
  `variants/config_block.c` `291bf59c...` and `variants/d3_masked_product.c`
  `d1f8f856...`; see [R10-001](#r10-001--d1config_blockd3-preparation-and-13-variant-handoff)
- R9 and all earlier reports and evidence are retained below.  The R9 overnight scripts are
  preserved as the 10-variant R9 handoff; the R10 scripts are the updated 13-variant
  handoff.
- Next action: stop for review.  The 39 R10 overnight measurements are the user's to run
  with `run_r10_overnight.sh`.
- No speedup, adoption, or acceptance claim is made in this file.  All timing and memory
  fields are `not measured` until the user supplies overnight artifacts.

## Task status

Update status and append a report when it changes materially. Use the states
defined in the instruction file. Link each status to its most recent report.

| Task | Priority | Status | Dependency / evidence / next action |
| --- | --- | --- | --- |
| DS-00 correctness foundation | P0 | accepted | R2: [DS-00-R2-001](#ds-00-r2-001--r2-correctness-foundation); new reference `correctness_r2.c` `49331a9d...`; R1 evidence retained in [DS-00-001](#ds-00-001--correct-cleanup-safe-corrected-reference); R9 does not reopen it |
| DS-01 harness/profile | P1 | accepted | R2: [DS-01-R2-001](#ds-01-r2-001--r2-profile-attribution-and-acceptance); corrected phase attribution and shared acceptance; R1 evidence retained in [DS-01-001](#ds-01-001--trustworthy-measurements-and-profiles); R9 does not reopen it |
| DS-10 inexpensive ablations | P2 | superseded by R9 | R9 split the four implementable ablations into DS-36…DS-39; generic buffer reuse stays parked in `DEEPSEEK_REMAINDER.md` |
| DS-20 return orientation | P3 | completed (negative) | R5: [R5-001](#r5-001--ds-202122-preparation-and-handoff); `variants/ds20.c` `498d8574...`; R9 records all 63 overnight rows matched; not reopened |
| DS-21 waiting-state deduplication | P3 | completed (negative) | R5: [R5-001](#r5-001--ds-202122-preparation-and-handoff); `variants/ds21.c` `6668b2e5...`; R9 records all 63 overnight rows matched; not reopened |
| DS-22 visited/layout | P3 | completed (negative) | R5: [R5-001](#r5-001--ds-202122-preparation-and-handoff); `variants/ds22.c` `d3270385...`; R9 records all 63 overnight rows matched; not reopened |
| DS-30 masked scalar insertion | P4 | ready-for-review | R9: [DS-30-R9-001](#ds-30-r9-001--masked-scalar-insertion-variantsds30_assignc); `variants/ds30_assign.c` `9952a112...`; build/`--smoke`/7-pair lab pass |
| DS-31 joint terminal filtering | P4 | ready-for-review | R9: [DS-31-R9-001](#ds-31-r9-001--joint-statevertex-terminal-filtering-variantsds31_jointc); `variants/ds31_joint.c` `3b39940a...`; build/`--smoke`/7-pair lab pass (Java/avrora included) |
| DS-32 empty product / first contribution | P4 | ready-for-review | R9: [DS-32-R9-001](#ds-32-r9-001--empty-product--first-contribution-variantsds32_emptyc); `variants/ds32_empty.c` `a156634d...`; build/`--smoke`/7-pair lab pass |
| DS-33 adaptive orientation / cache | P4 | ready-for-review | R9: [DS-33-R9-001](#ds-33-r9-001--adaptive-orientation--immutable-cache-variantsds33_formatc); `variants/ds33_format.c` `9196fb84...`; build/`--smoke`/7-pair lab pass |
| DS-34 lazy visited state | P4 | ready-for-review | R9: [DS-34-R9-001](#ds-34-r9-001--lazy-visited-state-variantsds34_lazy_pc); `variants/ds34_lazy_p.c` `7aa7d7cc...`; build/`--smoke`/7-pair lab pass |
| DS-35 lazy summary relations | P4 | ready-for-review | R9: [DS-35-R9-001](#ds-35-r9-001--lazy-summary-relations-variantsds35_lazy_ntc); `variants/ds35_lazy_nt.c` `5c5331f4...`; build/`--smoke`/7-pair lab pass |
| DS-36 pattern products | P2 | ready-for-review | R9: [DS-36-R9-001](#ds-36-r9-001--pattern-products-variantsds36_pairc); `variants/ds36_pair.c` `796030c0...`; build/`--smoke`/7-pair lab pass |
| DS-37 fused product accumulation | P2 | ready-for-review | R9: [DS-37-R9-001](#ds-37-r9-001--fused-product-accumulation-variantsds37_fusedc); `variants/ds37_fused.c` `21a56c43...`; build/`--smoke`/7-pair lab pass |
| DS-38 redundant product clear | P2 | ready-for-review | R9: [DS-38-R9-001](#ds-38-r9-001--remove-one-redundant-clear-variantsds38_no_product_clearc); `variants/ds38_no_product_clear.c` `ba91e5c4...`; build/`--smoke`/7-pair lab pass |
| DS-39 direct flat-layout calls | P2 | ready-for-review | R9: [DS-39-R9-001](#ds-39-r9-001--direct-flat-layout-calls-variantsds39_direct_callsc); `variants/ds39_direct_calls.c` `e9fbc199...`; build/`--smoke`/7-pair lab pass |
| D1 native block calls | P4 | ready-for-review | R10: [R10-001](#r10-001--d1config_blockd3-preparation-and-13-variant-handoff); `variants/d1_native.c` `c2d7e56d...`; block P/M_call, direct calls, lean Phase 5; build/`--smoke`/7-pair lab pass |
| config_block full configuration layout | P4 | ready-for-review | R10: [R10-001](#r10-001--d1config_blockd3-preparation-and-13-variant-handoff); `variants/config_block.c` `291bf59c...`; block configuration matrices and implicit RSM routing; build/`--smoke`/7-pair lab pass |
| D3 visited-mask products | P4 | ready-for-review | R10: [R10-001](#r10-001--d1config_blockd3-preparation-and-13-variant-handoff); `variants/d3_masked_product.c` `d1f8f856...`; d1_native with graph products masked by block P; build/`--smoke`/7-pair lab pass |

## Questions and design feedback

### Q-001 — General-caller policy for stored-false / non-BOOL relations

- Task / instruction revision: DS-00 / R1
- Status: answered by R2 (2026-11-01): approve the true-only BOOL contract for the experimental
  fast path; see [DS-00-R2-001](#ds-00-r2-001--r2-correctness-foundation) for the resolution.
- Blocking which work, and what independent work can continue: nothing further; the fast-path
  queue may proceed under the documented precondition.
- Source location / minimal example / observed evidence:
  `experimental/algorithm/cfpq_rsm_lab/variants/correctness.c` keeps the pre-existing
  structural masks and `GrB_LOR_LAND` products. A stored false entry is not a true edge, but
  it is structurally present and can hide a later true summary entry. A value-sensitive
  visited subtraction (`GrB_DESC_RC`) was measured to break termination: a stored-false
  frontier entry is regenerated every iteration. SuiteSparse:GraphBLAS typecasts a non-BOOL
  operand into the BOOL semiring domain, so a library-level type rejection would require one
  type query per input matrix per call.
- Decision needed: which policy the reviewed API should adopt for out-of-contract relations:
  (a) document and validate true-only BOOL inputs at the caller boundary (current choice),
  (b) reject inside the kernel with per-call type/value checks and an error, (c) add an
  input-normalization helper that casts to BOOL and drops false entries once per
  construction (not per measured call), or (d) define pattern semantics and use
  `GxB_ANY_PAIR_BOOL`-style products.
- Options and tradeoffs: (a) costs nothing in the measured kernel and matches the
  benchmark adapter, but leaves the library unable to detect misuse; (b) is a per-call
  metadata cost proportional to terminals/boxes, and a full value scan would be
  proportional to input nnz (the instruction explicitly forbids that in measured calls);
  (c) is cleanest for callers but needs a reviewed API and a place to call it; (d) changes
  the meaning of stored false and is a larger semantic decision.
- DeepSeek recommendation and reason: (a) for the optimization work, with (c) as the
  separate proposal if general callers are in scope. The CFG_bench adapter builds every
  graph relation with `GxB_Matrix_build_Scalar(..., true)` and every RSM relation with
  `GrB_Matrix_setElement_BOOL(..., true)`, so the benchmark is inside the contract; the
  test harness now rejects out-of-contract inputs at construction (`inputs_true_only`).
- Reviewer answer reference: R2 decision row (Q-001 answered)
- Resolution / implementation consequence: the R2 reference documents the precondition and
  output semantics at its entry point; `inputs_true_only()` remains a test-harness validator, not
  library enforcement; `LAGraphX.h` and the production entry-point documentation are the first
  step of the separate production-promotion review.  A construction-time normalization helper
  remains a separate, unreviewed proposal.

No other questions submitted yet. Append using this template; never replace an earlier
question with a different question under the same ID.

```markdown
### Q-001 — <short question>
- Task / instruction revision:
- Status: open | answered | superseded
- Blocking which work, and what independent work can continue:
- Source location / minimal example / observed evidence:
- Decision needed:
- Options and tradeoffs:
- DeepSeek recommendation and reason:
- Reviewer answer reference: <instruction revision and decision row; pending initially>
- Resolution / implementation consequence:
```

## Reports

Reports are appended here in order. DS-00-001 is the first. Use the template
below for each task or individual ablation. Use IDs such as `DS-00-001` and
`DS-10-pattern-products-001`; subsequent reports append a new ID and name the
earlier report they supersede. Write `not measured` or `unavailable` rather than
inventing a value. An incomplete report must identify the remaining work.

### DS-00-001 — Correct, cleanup-safe corrected reference

- Date/time (timezone): 2026-11-01 22:35 Europe/Moscow
- Task / instructions acknowledged: R1 (2026-11-01), DS-00
- Status: ready-for-review
- Parent report and parent source checksum: none (first report);
  `experimental/algorithm/LAGraph_CFPQ_RSM.c` sha256 `2ed679bedd62f53bf45fdb89c1edd39f87faa94664d01deef6027032c3503ce7`
- Repository commit; modified/untracked relevant files: `b1f7d708b62d4c7b13a3dfb98ad07b7ef0d6a5ee`;
  production kernel and public header are **unchanged**. New files:
  `experimental/algorithm/cfpq_rsm_lab/variants/correctness.c`,
  `experimental/algorithm/cfpq_rsm_lab/tests/{oracle.h,oracle.c,test_ds00.c,Makefile}`.
- Candidate source / patch / implementation commit or checksum:
  `variants/correctness.c` sha256 `bba6ee0939d10aab0620ee06d354b89c6c775adfdbf94e64ead6b1ae61bb3df0`
- Corrected reference source and checksum: same as the candidate above; this file is
  frozen for all later ablations. Every experiment must name it as its parent.
- Changed files and concise change description:
  - `variants/correctness.c`: a full stand-in for the production kernel containing only
    correctness/contract fixes (list below); algorithm, schedule, and GraphBLAS kernels
    otherwise unchanged.
  - `tests/oracle.{h,c}`: independent reference implementation (plain explicit-set
    fixed point, no GraphBLAS).
  - `tests/test_ds00.c`: deterministic regressions, 200 randomized oracle cases,
    input-contract validator, invalid-input/overflow checks, allocation-failure sweep.
  - `tests/Makefile`: isolated candidate builds (candidate, parent negative control,
    existing test file on the candidate, ASan/UBSan).

#### Correctness reasoning

- Relations and index mappings changed: none. The canonical mappings are unchanged and
  re-verified by the oracle tests: frontier/`M[q, u*V+v]`, block rows `B[q*V+u, v]`,
  `reshape(acc)` from `QV x V` to `Q x V*V`, `new_edges` from `1 x V*V` to `V x V`.
- True-only input boundary / behavior for out-of-contract input: the fast-path contract
  (BOOL relations with only true stored values) is unchanged and is now checked at the
  construction/test boundary by `inputs_true_only()` in `tests/test_ds00.c`, which rejects
  stored false entries and non-BOOL matrices. The kernel keeps the pre-existing
  value-sensitive products (`GrB_LOR_LAND_SEMIRING_BOOL`) and the pre-existing structural
  masks. A value-sensitive visited subtraction was prototyped and rejected: with
  `GrB_DESC_RC` a stored-false frontier entry is regenerated on every iteration and the
  fixed point never terminates; with a structural mask a stored false can hide a later true
  entry. This is a pre-existing general-caller limitation, raised as Q-001.
- Start-box, epsilon, NULL/empty, recursion, and same-iteration event handling:
  Phase 4 summary extraction no longer depends on `rsm_nonterm[i] != NULL`; a box with a
  non-NULL final vector always contributes its new summary edges, and the `W[i]*dG` return
  product is guarded separately because `W[i]` is absent exactly when no call can wait for
  that box. This makes the start box's summary and epsilon acceptance at its entry state
  visible to the final extraction, and makes `rsm_nonterm[start] == NULL` and an
  allocated-empty matrix produce identical results. W is still accumulated before Phase 4
  applies new summaries, so a new waiting configuration and a new callee summary in the
  same iteration are combined by `W[i]*dG`; the direct skip `X*graph_nt[i]` in Phase 2/3
  covers summaries that were already known when the call appeared.
- Ownership, buffer shapes, allocation/error cleanup:
  - `graph_nt`, `W`, `rsm_start` slots are released with `GrB_free`, not `LAGraph_Free`
    (the GraphBLAS object owns internal arrays that only its destructor releases).
  - the three matrix arrays are allocated with `LAGraph_Calloc`, so a later allocation
    failure cannot reach cleanup with uninitialized slots.
  - `term_src[k]` buffers are ordinary `LAGraph_Free` allocations and stay that way.
  - `LG_FREE_ALL` checks `reachable != NULL` before `GrB_free(reachable)`.
  - every early `continue` in Phase 4 restores `new_edges` to `1 x V*V`; `scratch` is
    restored by `s_unshift` on both the empty and non-empty paths.
- Why the change preserves semantics; scheduling preserved or changed: no scheduling change.
  The fixes remove a dependency that could only *lose* start-box summaries, fix ownership
  and overflow handling, and avoid one GraphBLAS 1x1 `GrB_apply` edge case (below).
- Additional bug found: SuiteSparse:GraphBLAS 10.5.2 returns `GrB_DIMENSION_MISMATCH` from
  `GrB_apply(out, mask, NULL, GrB_IDENTITY_BOOL, out, GrB_DESC_RSC)` when `out` is 1x1 and
  the complemented structural mask has no entries. The valid `V=1` first-iteration case hit
  this. The kernel now skips the subtraction when `graph_nt[i]` has no entries (identical
  result, and avoiding useless work); a standalone reproducer is retained in the report
  evidence. The production kernel fails this case.
- Boundary validation added before any allocation: `V*V`/`Q*V`/`Q*V*V` against
  `GxB_INDEX_MAX` (2^60) and int64 `nentries`; every source `< V` (flattening `s*V+s`
  would otherwise wrap); the start state of each box that is actually read; `Q == 0` is
  rejected through the start-state bound. A NULL terminal matrix array is accepted when
  `terminal_count == 0` (consistent with the NULL `graph_term` rule).

#### Validation evidence

- Exact build/test commands, candidate linkage, exit status, and logs:
  - `make -C experimental/algorithm/cfpq_rsm_lab/tests candidate_correctness existing_candidate production_control candidate_asan`
  - `build/tests/candidate_correctness` → `checks=15842 failures=0`, exit 0
    ([log](experimental/algorithm/cfpq_rsm_lab/build/runs/DS-00/regressions-and-random.log))
  - `build/tests/existing_candidate` (existing `test_CFPQ_RSM.c`, TC1–TC10, linked to the
    candidate) → all pass, exit 0
    ([log](experimental/algorithm/cfpq_rsm_lab/build/runs/DS-00/existing-tests-candidate.log))
  - `build/tests/production_control --no-random` (unchanged parent, negative control) →
    9 failures, exit 1
    ([log](experimental/algorithm/cfpq_rsm_lab/build/runs/DS-00/production-negative-control.log))
  - `ASAN_OPTIONS=detect_leaks=1 build/tests/candidate_asan` → clean, exit 0
    ([log](experimental/algorithm/cfpq_rsm_lab/build/runs/DS-00/asan-ubsan-lsan.log))
  - `build/tests/candidate_correctness --alloc-sweep --max-budget 2000` → budgets 0..1215:
    1209 clean kernel errors, 7 valid results, first valid budget 1209, failures 0, exit 0
    ([log](experimental/algorithm/cfpq_rsm_lab/build/runs/DS-00/alloc-sweep.log))
  - `build/tests/production_control --alloc-sweep --max-budget 40` → 2 crashes (SIGABRT),
    35 failures (leaks up to `LG_nmalloc=18`, one wrong result), exit 1
    ([log](experimental/algorithm/cfpq_rsm_lab/build/runs/DS-00/alloc-sweep-production.log))
  - reduced CFG_bench final check: all 15 configs in `tests/data/configs/all.csv` return
    `[OK]` against the computed CFL_adv expectation, exit 0
    ([log](experimental/algorithm/cfpq_rsm_lab/build/runs/DS-00/reduced-cfgbench.log))
  - provenance (machine, compiler, library paths, GraphBLAS version, checksums, exact
    commands): [provenance.txt](experimental/algorithm/cfpq_rsm_lab/build/runs/DS-00/provenance.txt)
- Independent oracle: explicit set/worklist fixed point over `(RSM state, current vertex)`
  configurations per box, using terminal edges and the current callee summaries, repeating
  over boxes until no summary relation grows. No path-length cutoff. The driver converts
  GraphBLAS matrices to plain edge lists with true entries only, so the true-only boundary
  is enforced outside the kernel. Every case compares the exact true-index set for the
  full source set, for each singleton source, and for the empty source set.
- Deterministic regressions and singleton/multi-source comparisons: every DS-00 table row
  has a dedicated deterministic case, including `S -> a` with NULL and empty incoming calls,
  epsilon at the start entry, NULL/empty final vectors, direct and mutual recursion with a
  nullable callee, multiple finals/callers/overlapping summaries, empty sources, isolated
  vertices, `V=0`, missing/empty terminal matrices and unused label/box, repeated and
  reordered sources, stored false input (rejected at the boundary), non-BOOL input
  (rejected at the boundary; SS:GrB typecasts it if passed directly), invalid
  source/state/dimension/overflow inputs, NULL `reachable`, and a `load_0`/`store_1`
  indexed-family case with no cross-match.
- Allocation-failure injection and sanitizer/leak results, with coverage limits: see the
  sweep above; the `LG_brutal_*` allocator is installed through `GxB_init`, so GraphBLAS
  internal allocations participate (the count 1209 is the total for the whole call). The
  sweep proves every prefix of the allocation sequence (0..1208) returns a defined error,
  leaves `*reachable == NULL`, and leaks nothing after teardown (`LG_nmalloc == 0`);
  it does not attribute a given budget to a specific call site. ASan/UBSan cover the
  candidate translation unit; the GraphBLAS library itself is not instrumented.
- Reduced CFG_bench final check and logs: see above. Run with `GRAPHBLAS_CACHE_PATH` set to
  a writable workspace directory (see environment note); 15/15 OK.
- Frontier/summary traces: not applicable to DS-00 (no schedule change). DS-01 adds them.
- Failures, minimal reproducer, and unresolved risks:
  - Production negative control failures (expected, they are the bugs being fixed):
    NULL-incoming-call start-box summary lost; `V*V` wrap accepted; NULL terminal array
    rejected with count 0. The allocation sweep shows the production cleanup bug (SIGABRT
    at budgets 1 and 2, leaks).
  - Environment: `~/.SuiteSparse` is read-only in this workspace, so SuiteSparse:GraphBLAS
    JIT compilation fails; one otherwise valid `mxm` returned `GrB_DIMENSION_MISMATCH`
    during randomized testing. The harness therefore sets `GxB_JIT_OFF`; the reduced
    CFG_bench run instead used a writable `GRAPHBLAS_CACHE_PATH`. DS-01 freezes and records
    the benchmark setting. This is a measurement-environment item, not a kernel fix.
  - Not tested: multi-threaded GraphBLAS, GraphBLAS versions other than SS:GrB 10.5.2,
    large-scale independent-oracle comparison (oracle is limited to small instances),
    and general-caller semantics for stored-false/non-BOOL input (Q-001).

#### Benchmark provenance

Not applicable: DS-00 made no timed measurements and claims no speedup. Correctness-induced
timing changes must not be read as optimization results; the reference is the parent for
DS-01 onward.

#### Results (one row per workload/source-size/chunk/seed)

Not measured. DS-00 is a correctness task; the only workload-facing run is the reduced
CFG_bench semantic check above.

- Duplicate-baseline variation and interpretation: not measured (DS-01).
- Source-size-specific aggregates (only after per-case results): not measured (DS-01).
- Confirmation seeds 2027/2028; disagreements or regressions: not measured.
- Phase costs and matrix bytes/formats/index widths/iso status: not measured (DS-01).
- Candidate/new/duplicate counts, W/dG/P sizes and component/batch counts: not measured.
- Setup/conversion/assembly costs and temporary-memory peaks: not measured.
- Unavailable counters and limits of conclusions: all timing counters; see DS-01.

#### Recommendation and follow-up

- Recommendation: accept for review.
- Evidence supporting it and workload limits: 200 randomized oracle cases (seeds
  2026–2225), deterministic table coverage, existing tests, sanitizers, exhaustive
  allocation-failure prefix, and 15/15 reduced CFG_bench. The oracle and randomized cases
  are small by design; large-workload correctness rests on the CFG_bench cross-check.
- Every regression, especially >5% time or memory flags: none measured. The Phase 4 change
  adds work only for boxes that were previously skipped (start box with NULL incoming calls);
  it is a correctness fix, not an optimization.
- Proposed next task / combination and why: DS-01 (harness hardening + profiling) against
  this frozen reference, then DS-10 ablations naming `bba6ee09...` as parent.
- Questions raised (Q-IDs): Q-001.
- Reproducibility artifacts retained; anything external or missing: all logs and provenance
  under `experimental/algorithm/cfpq_rsm_lab/build/runs/DS-00/` (gitignored build area); the new
  source files are in the working tree but are not committed (the reviewer or a later step can
  commit them). CFG_bench and the GraphBLAS JIT cache are external.
- Reviewer decision reference: pending


### DS-00-R2-001 — R2 correctness foundation

- Date/time (timezone): 2026-11-01 23:50 Europe/Moscow
- Task / instructions acknowledged: R2 (2026-11-01), DS-00-R2
- Status: ready-for-review
- Parent report and parent source checksum: [DS-00-001](#ds-00-001--correct-cleanup-safe-corrected-reference);
  R1 reference `variants/correctness.c` `bba6ee0939d10aab0620ee06d354b89c6c775adfdbf94e64ead6b1ae61bb3df0`
  (preserved unchanged)
- Repository commit; modified/untracked relevant files: `b1f7d708...`;
  new `experimental/algorithm/cfpq_rsm_lab/variants/correctness_r2.c`; modified
  `experimental/algorithm/cfpq_rsm_lab/tests/oracle.c`, `tests/test_ds00.c`, `tests/Makefile`.
  The production kernel, public header, and the R1 reference are unchanged.
- Candidate source / patch / implementation commit or checksum:
  `correctness_r2.c` sha256 `49331a9dfd6678ddd3494218342c11a7e7fdb136e32b9f29b7af767d196ec9de`;
  `tests/oracle.c` `81e145aec51ede310ba4a39cd9e2170d786dde42dbc78caf8ecbb38778f5bcc9`;
  `tests/oracle.h` `3d307763a35973ecce1852636ca3f0785c4b333d650d7780390fb88cabaf8bef`;
  `tests/test_ds00.c` `7bd7531d4c139b1d7a309fa9e00e1537eb8127a9cb68eb530f1963f93dafb5f5`;
  `tests/Makefile` `8c27ddaee4fa37f43db72396943c0f3ac02fddb77f297ddc2a49a3c0fe733d7e`.
- Corrected reference source and checksum: `correctness_r2.c` `49331a9d...` (new frozen reference
  for the remaining experimental queue); every new experiment must name this checksum.
- Changed files and concise change description:
  - `correctness_r2.c`: the R1 summary/cleanup/validation fixes plus the R2 P1 input-shape
    validation and the explicit fast-path precondition at the entry point.  The R1 file is kept
    for historical evidence and is not relabelled.
  - `tests/oracle.c`: discovered-on-push worklist deduplication (R2 P2).
  - `tests/test_ds00.c`: deterministic malformed-dimension regressions, dense/cyclic/branching and
    parallel-label fixtures, and a broadened randomized generator (several successors and labels
    per state).
  - `tests/Makefile`: `candidate_correctness_r2`, `existing_candidate_r2`, `candidate_asan_r2`;
    `make asan` is now a full check (200 randomized cases, ASan+UBSan+leak detection), with
    `make asan-fast` kept as the smaller, leak-detection-off mode.

#### Correctness reasoning

- **P1 — shape validation before native indexing.** The new checks run before any allocation or
  tuple extraction, for every non-NULL operand, including empty/inactive ones: terminal and
  nonterminal transition matrices must be `Q x Q`, graph matrices `V x V`, and final vectors
  length `Q`; a mismatch returns `GrB_DIMENSION_MISMATCH`.  NULL array entries and a NULL
  `terminal_matrices` array with `terminal_count == 0` remain valid ("no entries").  This closes
  the reported path where a terminal matrix with a true entry in row `Q` reached
  `active[term_src[i][k]]` out of bounds before `mxm` could report the shape error.  The checks
  are metadata queries (`GrB_Matrix_nrows/ncols`, `GrB_Vector_size`), not the prohibited per-call
  value normalization.
- **P2 — oracle worklist soundness.** A configuration is marked `discovered` when it is pushed
  and `visited` when popped; successors are pushed only when neither flag is set, so every
  distinct `(state, vertex)` configuration is pushed at most once and the `Q*V` stack capacity is
  sound.  The outer per-box least-fixed-point iteration is unchanged.  New fixtures include a
  complete two-state relation over a complete two-vertex graph, a state with several successors
  per label plus a recursive call, cycles, and parallel label derivations of the same summary
  pair; the randomized generator now emits several successors and labels per state.
- **Q-001 resolution.** Citing the R2 decision: the experimental fast path is approved with the
  true-only BOOL contract, and the precondition (correctly shaped BOOL relations, true-only
  stored entries, globally consistent RSM state numbering) and output semantics are documented at
  the entry point of `correctness_r2.c`.  `inputs_true_only()` exists only in the test harness and
  is not library enforcement.  This report does not claim that the kernel rejects stored-false or
  non-BOOL input, and does not claim general value-sensitive support.  Documentation in
  `LAGraphX.h` and at the production implementation entry point is the first step of the separate
  production-promotion review, not of this revision; the production files remain untouched.
- Why the change preserves semantics; scheduling preserved or changed: no scheduling change; the
  shape checks only reject inputs that were already invalid (and previously unsafe), and the
  oracle change only removes duplicate worklist entries.

#### Validation evidence

- Exact build/test commands, candidate linkage, exit status, and logs (all under
  `experimental/algorithm/cfpq_rsm_lab/build/runs/DS-00-R2/`):
  - `make -C tests candidate_correctness_r2 existing_candidate_r2 candidate_asan_r2`.
  - `build/tests/candidate_correctness_r2` → 16,388 checks, 0 failures
    ([log](experimental/algorithm/cfpq_rsm_lab/build/runs/DS-00-R2/regressions-random.log)).
  - `ASAN_OPTIONS=detect_leaks=1 build/tests/candidate_asan_r2` → clean, exit 0
    ([log](experimental/algorithm/cfpq_rsm_lab/build/runs/DS-00-R2/asan-full.log)).
  - `build/tests/existing_candidate_r2` (TC1–TC10 on the R2 candidate) → all pass
    ([log](experimental/algorithm/cfpq_rsm_lab/build/runs/DS-00-R2/existing-tests.log)).
  - `build/tests/candidate_correctness_r2 --alloc-sweep --max-budget 2000` → 0 failures, first
    valid budget 1209
    ([log](experimental/algorithm/cfpq_rsm_lab/build/runs/DS-00-R2/alloc-sweep.log)).
  - reduced CFG_bench on `tests/data/configs/all.csv` with the R2 library → 15/15 `[OK]`, exit 0
    ([log](experimental/algorithm/cfpq_rsm_lab/build/runs/DS-00-R2/reduced-cfgbench.log)).
  - provenance and checksums:
    [provenance.txt](experimental/algorithm/cfpq_rsm_lab/build/runs/DS-00-R2/provenance.txt).
- Negative control for the P1 bug on the frozen R1 reference:
  - the new malformed tests fail without an error on R1 for the empty/mismatched shapes;
  - under ASan, the `Q=2`/`V=2`/terminal `3x3` with entry `(2,0)` case reports a heap-buffer-overflow
    read in `LAGraph_CFPQ_RSM` at the `active[term_src[i][k]]` line, with the `term_src` allocation
    in the trace.  Logs:
    [r1 malformed, no sanitizer](experimental/algorithm/cfpq_rsm_lab/build/runs/DS-00-R2/r1-malformed-negative.log)
    and [r1 malformed, ASan](experimental/algorithm/cfpq_rsm_lab/build/runs/DS-00-R2/r1-malformed-asan.log).
- Independent oracle: now covers the dense/branching fixtures above and 200 randomized cases
  (seeds 2026–2225) with the broadened generator; every case compares exact true-index sets for
  the full source set, each singleton source, and the empty source set.
- Allocation-failure injection and sanitizer/leak results, with coverage limits: same harness as
  DS-00-001 (LG_brutal_* via GxB_init); every budget prefix 0–1208 returns a defined error, leaves
  `*reachable` NULL and leaks nothing; GraphBLAS-internal failures are included in the count but
  not attributed per call site.  ASan/UBSan/LSan cover the candidate translation unit, not the
  GraphBLAS/LAGraph libraries.
- Failures, minimal reproducer, and unresolved risks: none in the R2 candidate.  The frozen R1
  reference fails the new malformed test by design (that is the bug being fixed); the R1 logs are
  retained and clearly labelled.  The kernel still does not enforce the true-only/non-BOOL
  contract; that remains a caller boundary plus a future normalization helper proposal.

#### Benchmark provenance

Not applicable: DS-00-R2 is a correctness revision and makes no timed measurement or speedup
claim.  The DS-01-R2 runs use `correctness_r2.c` and name its checksum explicitly.

#### Results (one row per workload/source-size/chunk/seed)

Not measured (correctness only); the reduced CFG_bench semantic check is listed above.

- Duplicate-baseline variation and interpretation: not measured here (DS-01-R2).
- Source-size-specific aggregates: not measured here.
- Confirmation seeds 2027/2028: not run.
- Phase costs / matrix metadata: not measured here.
- Candidate/new/duplicate counts / W/dG/P sizes: not measured here.
- Setup/conversion/assembly and temporary-memory peaks: not measured here.
- Unavailable counters and limits of conclusions: timings; contract enforcement as noted.

#### Recommendation and follow-up

- Recommendation: accept for review.
- Evidence supporting it and workload limits: the reported unsafe access is reproduced on R1 and
  rejected with a defined error on R2; malformed shapes for every operand class are covered; the
  oracle worklist fix has explicit dense/cyclic/branching fixtures; all R2 checks, sanitizers,
  allocation sweep, existing tests and the reduced CFG_bench cross-check pass.
- Every regression, especially >5% time or memory flags: none claimed; the added shape checks are
  `O(terminals + boxes)` metadata queries per call and will be measured in DS-01-R2 rather than
  assumed free.
- Proposed next task / combination and why: DS-01-R2 (profile attribution/acceptance) on
  `49331a9d...`; then a separate production-promotion review for the localized fixes and the
  true-only contract documentation in `LAGraphX.h`.
- Questions raised (Q-IDs): Q-001 resolved above; no new questions.
- Reproducibility artifacts retained; anything external or missing: sources and tests in the
  working tree (not committed); logs/provenance under the gitignored lab build area; CFG_bench
  and GraphBLAS remain external.
- Reviewer decision reference: pending

### DS-01-001 — Trustworthy measurements and profiles

**R2 note: the phase tables, C-alias/Java percentage interpretations, the candidate-to-frontier
C1 bound, and the byte-estimator claims in this report are superseded by
[DS-01-R2-001](#ds-01-r2-001--r2-profile-attribution-and-acceptance).  The uninstrumented noise
rows for `bba6ee09...` remain historical evidence for that checksum.**

- Date/time (timezone): 2026-11-01 23:20 Europe/Moscow
- Task / instructions acknowledged: R1 (2026-11-01), DS-01
- Status: ready-for-review
- Parent report and parent source checksum: [DS-00-001](#ds-00-001--correct-cleanup-safe-corrected-reference);
  corrected reference `variants/correctness.c` sha256 `bba6ee09...` (unchanged by DS-01)
- Repository commit; modified/untracked relevant files: `b1f7d708...`; modified tracked file:
  `experimental/algorithm/cfpq_rsm_lab/run.py`; new files:
  `experimental/algorithm/cfpq_rsm_lab/variants/cfpq_profile.h`,
  `experimental/algorithm/cfpq_rsm_lab/variants/correctness_profile.c` (generated),
  `experimental/algorithm/cfpq_rsm_lab/tests/make_profile_variant.py`.
  The production kernel, public header, DS-00 reference, oracle, tests, and Makefile are unchanged.
- Candidate source / patch / implementation commit or checksum: harness
  `run.py` sha256 `4fa00c92bd635be5d5523b563a97e8d88012e23c7b640733c29ebe4744e2fffd`;
  `cfpq_profile.h` `cc1368e1a85d9a81049f9eb6df5c46366166e2a1aca80d35bede047c7c0dbcbb`;
  `correctness_profile.c` `2b48d60c0093ac4ec746996c36db2d2cd0cc2b972d233c482e0319b8df3d1b00`;
  `make_profile_variant.py` `6b89d9d7b1a78a72e25c47d01f4992e6fbf2c1e1e7e0cc7e23ce840145ae2190`.
- Corrected reference source and checksum: `bba6ee09...` (DS-00); every DS-01 timing uses this
  reference as the variant source, so the measured object is the reviewed one.
- Changed files and concise change description:
  - `run.py`: experimental acceptance checks (below), provenance capture, build stamps, a writable
    per-run GraphBLAS JIT cache, `OMP_NUM_THREADS`, and a `--profile` mode. The experiment
    command is unchanged in shape (`-r 1 --hot --experiment --source-sizes S --chunks C --seed
    SEED`); variants are interleaved with the same rotation as before.
  - `cfpq_profile.h` + generated `correctness_profile.c`: `#ifdef CFPQ_RSM_PROFILE` instrumentation
    compiled only for the profiling pass. `make_profile_variant.py` derives the profile source from
    the frozen reference with asserted, one-shot anchors; compiling the generated file without the
    macro reproduces the reference behavior.
  - **Acceptance now fails the run** for: a missing or extra (graph, grammar, source size, chunk)
    case; a duplicate case in a round; a missing round; a zero/unavailable result hash; unstable
    counts or hashes across rounds; any per-round count or hash mismatch against the baseline
    (not only an aggregate mismatch); a baseline case-set mismatch. The run also prints the
    duplicate-baseline spread.
  - Provenance per run: repository commit and status, config/cfg_bench/source/library sha256,
    compiler and flags, `OMP_NUM_THREADS`, machine/CPU, JIT cache path plus warm-up semantics,
    loaded LAGraph/GraphBLAS paths, and the exact command line.

#### Correctness reasoning

- Relations and index mappings changed: none.
- True-only input boundary / behavior for out-of-contract input: unchanged from DS-00-001 (Q-001).
- Start-box, epsilon, NULL/empty, recursion, and same-iteration event handling: unchanged; the
  DS-00 oracle suite (200 randomized cases, 15,842 checks) was rerun against the current
  generated profile source and passes, so the instrumented build is semantically the reference.
- Ownership, buffer shapes, allocation/error cleanup: the profile state is a single static object
  with fixed-size detail arrays; no allocation occurs in the measured region. The profile build
  waits on the final vector so materialization can be attributed; the timing build does not, and
  profile timings are never used as the performance verdict.
- Why the change preserves semantics; scheduling preserved or changed: the measured kernel is the
  frozen reference; only the harness and a separate instrumented copy changed. The DS-01 runs
  interleave duplicate corrected baselines, so they measure the reference, not a candidate.

#### Validation evidence

- Exact build/test commands, candidate linkage, exit status, and logs:
  - reference oracle suite: `candidate_correctness` (DS-00 Makefile) → 15,842 checks, 0 failures;
    the generated profile build `candidate_profile` also → 15,842 checks, 0 failures
    ([log](experimental/algorithm/cfpq_rsm_lab/build/runs/DS-01-profile/profile-variant-oracle-suite.log)).
  - harness self-test: a deliberately wrong variant (drops the last source) is flagged on all 7
    workloads, every round, exit 1
    ([run](experimental/algorithm/cfpq_rsm_lab/build/runs/DS-01-selftest-wrong)).
  - noise runs (seed 2026, 5 rounds, 3 chunks, duplicate baselines, sizes 1/10/100):
    all 126 case-cells `ok`, exit 0; logs and summaries under
    `experimental/algorithm/cfpq_rsm_lab/build/runs/DS-01-noise/size{1,10,100}/`
    (`summary.csv`, `raw/`, `logs/`, `provenance.txt`).
  - profile runs (sizes 1/10/100, 7 measured calls each): reference and profile builds have equal
    per-case counts and hashes, no `PROFILE PROBLEM`, exit 0; artifacts under
    `experimental/algorithm/cfpq_rsm_lab/build/runs/DS-01-profile/size{1,10,100}/`
    (`profile.csv`, `profile/*.txt`, `*.detail.csv`, `*.matrix.csv`, `logs/`, `provenance.txt`).
  - combined tables used in this report:
    [DS-01-tables.txt](experimental/algorithm/cfpq_rsm_lab/build/runs/DS-01-tables.txt).
- Independent oracle: unchanged (DS-00-001); not used for the benchmark-sized workloads.
- Deterministic regressions and singleton/multi-source comparisons: DS-00 suite (unchanged).
- Allocation-failure injection and sanitizer/leak results, with coverage limits: DS-00 evidence
  applies to the measured kernel; DS-01 did not add allocation-failure coverage to the runner.
- Reduced CFG_bench final check and logs: DS-00-001 (15/15 `[OK]`); DS-01 measured the same 7
  workloads with per-round hash/count checks, which is stricter for these inputs.
- Frontier/summary traces: per-iteration `|M|`, `|P|`, candidate and next-frontier counts are in
  `*.detail.csv` (kind=iter) and summarized below.
- Failures, minimal reproducer, and unresolved risks: no failing measurement. Risks/limits are
  listed under "Unavailable counters and limits of conclusions".

#### Benchmark provenance

- Run IDs / raw artifact directories / exact commands:
  - `build/runs/DS-01-noise/size{1,10,100}`; command per size, e.g.
    `python3 experimental/algorithm/cfpq_rsm_lab/run.py --baseline experimental/algorithm/cfpq_rsm_lab/variants/correctness.c --variants baseline,baseline --source-size 100 --chunks 3 --seed 2026 --rounds 5 --out .../DS-01-noise/size100`
  - `build/runs/DS-01-profile/size{1,10,100}`; `--profile --source-size S --chunks 1 --seed 2026 --rounds 1`.
  - The noise runs above used the acceptance logic in this `run.py`. Later runner edits are
    behaviour-neutral for timing builds: an additional `-I<lab>/variants` include path used when
    building the profile source, and removal of an unused `--profile-source` option. A final smoke
    run with the current runner (size 1, 1 chunk, 1 round) passed
    (`build/runs/DS-01-final-smoke`).
- Compiler/options; GraphBLAS and LAGraph versions and loaded library paths: `cc` (GCC 16.2.1);
  `-O2 -fPIC -shared -std=c11`; SuiteSparse:GraphBLAS 10.5.2 (header `/usr/local/include/suitesparse`);
  variants link `/usr/local/lib/liblagraph.so.1` and `/usr/local/lib/libgraphblas.so.10`;
  `cfg_bench` is `/home/hollow/repo/CFG_bench/build/cfg_bench` (sha256 recorded per run).
- CPU/RAM, OS, threads, affinity, relevant environment: AMD Ryzen 5 7640HS, 12 logical CPUs,
  14 GiB, Linux 7.2.11-arch1-1; `OMP_NUM_THREADS=1`; no affinity pinning; `GRAPHBLAS_CACHE_PATH`
  is a per-run writable directory (`<out>/jit-cache`) and `--hot` performs one unmeasured
  warm-up call per case before the measured `-r 1` call, so JIT compile/load is outside the
  measured interval. Per-run `provenance.txt` records all of this.
- Config checksum; graph/grammar/RSM/source-list identities: `configs/lab.csv` sha256
  `dcd7d3cc...`; the seven graph/grammar pairs are the requested Java/RDF/C-alias workloads;
  source lists are the config's `.result` files.
- Actual Q/V, boxes/labels/finals/indexed-family counts: from the profiles (all sizes):
  Java avrora Q=3439 states, V=24690, 3436 terminal labels, 3 boxes (all called, all with a final
  vector); RDF eclass/go/go_hierarchy Q=6, V=239111/582929/45007, labels 20/94/4, 1 box;
  C-alias mm/init/block Q=8, V=2538243/2446224/3423234, labels 4, 2 boxes. Labels are the
  post-explosion terminal count; the pre-explosion indexed-family size is not exposed by the
  RSM file and is marked unavailable. The assessment's "3439 states" for Java is confirmed; its
  "858 blocks" is not the RSM nonterminal count (3); RDF 6-state/1-box and C-alias 8-state/2-box
  are confirmed.
- Source sizes, actual chunks/source counts, seeds, rounds, warm-up behavior: `|S| = 1, 10, 100`
  run separately, `--chunks 3` (chunks 0,1,2), seed 2026, 5 measured interleaved rounds,
  duplicate corrected baseline in every run. `--hot` = one unmeasured warm-up call per case per
  invocation; it is not a measured sample.
- Instrumentation on/off; synchronization/materialization boundaries: timing runs are
  uninstrumented. Profile runs add wall-clock timers and counters, and the profile build waits on
  the final vector; platform `cfg_bench` itself always waits on the result inside the measured
  interval for this adapter.
- Timer scope, preprocessing/reuse scope, and memory measurement scope: `time_s` is cfg_bench's
  adapter run+wait interval; kernel-internal preprocessing (allocation, `term_src` extraction) is
  inside the kernel interval and reported separately by the profile as `setup_s`. `max_memory_kb`
  is cfg_bench's process-wide peak; the profile also reports `getrusage` peak RSS. No reusable
  setup is claimed.
- Expected cases/rounds versus observed; zero hashes/missing/unstable data: expected 21
  case-cells per size (7 workloads x 3 chunks), 5 rounds each, 2 variants = 210 rows per size;
  all observed, all `ok`, no zero hash, no missing round, no unstable count/hash.

#### Results (one row per workload/source-size/chunk/seed)

Full per-case rows (median, IQR, min/max, per-round count/hash/ratio, duplicate-baseline
ratio) are in `DS-01-noise/size*/summary.csv`. Medians below are over the 3 chunks; the
duplicate range is `min..max` of the per-case duplicate-baseline ratios.

| |S| | Workload | median ms (chunks) | min..max ms | duplicate ratio |
| --- | --- | --- | --- | --- |
| 1 | Java avrora | 21.07 | 20.88..21.09 | 1.002..1.016 |
| 1 | RDF eclass | 0.415 | 0.405..0.420 | 0.950..1.060 |
| 1 | RDF go | 0.459 | 0.445..1.273 | 0.961..1.026 |
| 1 | RDF go_hierarchy | 0.370 | 0.370..0.435 | 0.944..1.061 |
| 1 | C-alias mm | 0.703 | 0.672..1.497 | 0.987..1.000 |
| 1 | C-alias init | 0.679 | 0.660..0.680 | 0.976..1.033 |
| 1 | C-alias block | 1.318 | 0.684..2.834 | 0.956..1.026 |
| 10 | Java avrora | 393.9 | 132.6..1320.6 | 0.988..0.994 |
| 10 | RDF eclass | 0.875 | 0.862..1.380 | 0.995..1.035 |
| 10 | RDF go | 1.289 | 0.922..8.522 | 0.984..0.995 |
| 10 | RDF go_hierarchy | 1.091 | 1.056..1.501 | 0.909..0.999 |
| 10 | C-alias mm | 1.902 | 1.899..7.232 | 0.985..1.024 |
| 10 | C-alias init | 9.348 | 7.183..11.415 | 0.997..1.011 |
| 10 | C-alias block | 6.447 | 6.046..7.079 | 0.986..1.008 |
| 100 | Java avrora | 6070.3 | 2071.8..6079.3 | 0.994..0.997 |
| 100 | RDF eclass | 3.099 | 2.006..3.757 | 0.986..1.050 |
| 100 | RDF go | 13.07 | 9.76..18.98 | 1.000..1.006 |
| 100 | RDF go_hierarchy | 12.50 | 11.81..17.82 | 0.993..1.009 |
| 100 | C-alias mm | 22.35 | 21.26..32.21 | 0.985..0.990 |
| 100 | C-alias init | 19.41 | 10.11..28.11 | 0.988..1.015 |
| 100 | C-alias block | 28.07 | 15.52..28.49 | 0.987..1.007 |

- Duplicate-baseline variation and interpretation: overall per-case duplicate ratios span
  `0.944..1.061` at |S|=1 (geo 1.001), `0.909..1.035` at |S|=10 (geo 0.993), and `0.985..1.050`
  at |S|=100 (geo 0.999). The geometric aggregate is stable to ~1%; individual cases below
  ~10 ms can move by 5-9%. DS-10 should judge a change per case against the duplicate spread for
  that case, not against a fixed 5% threshold; this is a review flag, not a significance test.
- Source-size-specific aggregates (only after per-case results): the geometric duplicate ratios
  above are the aggregate; no cross-size pooling is used because source-size medians differ by
  orders of magnitude (e.g., avrora 21 ms -> 394 ms -> 6.07 s).
- Confirmation seeds 2027/2028; disagreements or regressions: not run; there is no candidate
  change to confirm. Seed 2026 only for the baseline noise study.
- Phase costs and matrix bytes/formats/index widths/iso status: see below.
- Candidate/new/duplicate counts, W/dG/P sizes and component/batch counts: see below (no lazy
  components or batches exist in the reference).
- Setup/conversion/assembly costs and temporary-memory peaks: see below.
- Unavailable counters and limits of conclusions:
  - Profile pass covers chunk 0 only (one chunk per workload/source size); the timing pass covers
    chunks 0-2.
  - The profiled build waits on the final vector; its per-phase times are attribution, and the
    profile total is not the performance verdict. For avrora |S|=100 the profiled total is
    6.123 s against the uninstrumented 6.070 s median (+0.9%), within a plausible instrumentation
    and run-to-run range, but not a speed comparison.
  - `call_id` in the profile summary restarts at 0/1 for each workload because cfg_bench
    `dlclose`s/re-`dlopen`s the variant library per config; per-box/matrix rows are attributed by
    file order in this report, and later runs should key on the summary/case order.
  - Kernel persistent memory is estimated from metadata (bytes~), not an allocator report; peak
    RSS is process-wide and dominated by parsing/GraphBLAS, not by the kernel matrices.
  - Pre-explosion indexed-family counts are unavailable (see Benchmark provenance).
  - The oracle covers small instances only; benchmark-sized correctness rests on the per-round
    count+hash checks against the reference and the reduced CFG_bench cross-check.

##### Dominant costs (profile, measured call; sub-timers are subsets of phase times)

Phase 1 (terminal transitions) dominates the Java workload at every size: 17.86/18.39 ms (97.1%)
at |S|=1, 380.3/386.4 (98.4%) at |S|=10, and 6011.0/6123.4 (98.2%) at |S|=100. Representation
conversion (reshapes inside `s_shift`/`s_unshift`) is a subset of those phase times: 3.86 ms at
|S|=1, 81.2 ms at |S|=10 and 1281.5 ms at |S|=100, i.e. about 21% of the avrora phase-1 time at
|S|=100. RDF and C-alias split across phases; at |S|=100, C-alias is phase 1 21.7-24.6%, phases
2+3 0.80-1.02 ms, phase 4 1.41-2.26 ms, phase 5 1.68-2.59 ms; RDF go/go_hierarchy are phase 4
2.2/2.2 ms and phase 5 3.4/3.5 ms. Final extraction and materialization are negligible
(<=0.15 ms). Kernel preprocessing (`setup_s`) is ~3 ms for avrora (2.9 ms at |S|=100, 2.5 ms of
18.4 ms at |S|=1) and <=0.06 ms for the other workloads; at small source counts it is a visible
share because it is paid per query.

Operation counters (totals over the call, |S|=100):

| Workload | iters | sum/|M| max | sum|P| | candidates | next | term shifts | pred skips | static skips | nt shifts | calls | dG | return products | clears | reshapes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| avrora | 160 | 21914 / 1542 | 2097591 | 22670 | 21814 | 227903 | 273857 | 48000 | 480 | 253 | 359 | 358 | 228703 | 457897 |
| eclass | 8 | 3632 / 813 | 17920 | 3593 | 3532 | 12 | 20 | 128 | 8 | 3 | 3 | 3 | 36 | 57 |
| go | 26 | 13499 / 1643 | 246261 | 15921 | 13399 | 41 | 63 | 2340 | 26 | 8 | 22 | 22 | 119 | 212 |
| go_hierarchy | 6 | 37052 / 13378 | 138939 | 42442 | 36952 | 6 | 6 | 12 | 6 | 2 | 2 | 2 | 24 | 36 |
| mm | 35 | 7104 / 505 | 170181 | 7439 | 7004 | 120 | 20 | 0 | 70 | 54 | 58 | 58 | 260 | 588 |
| init | 38 | 4969 / 283 | 128965 | 5327 | 4869 | 127 | 25 | 0 | 76 | 58 | 60 | 60 | 279 | 625 |
| block | 33 | 3551 / 273 | 83600 | 3699 | 3451 | 115 | 17 | 0 | 66 | 49 | 56 | 56 | 247 | 559 |

- "candidates" is `|acc| + |M_call|` before visited subtraction (a sum of possibly overlapping
  contributions, not a logical union); "next" is the frontier after subtraction. The duplicate
  fraction `(candidates-next)/candidates` is 3.8% (avrora), 1.7% (eclass), 15.8% (go), 12.9%
  (go_hierarchy), 5.8% (mm), 8.6% (init), 6.7% (block) at |S|=100. C1/B22 deduplication is
  therefore a bounded opportunity on these workloads; measure it per box before investing.
- For avrora, 227,903 terminal chains run and 273,857 are skipped by activity prediction out of
  3436 labels x 160 iterations; 48,000 label checks are skipped statically. The per-terminal
  shift is followed by `s_mul_acc` (1 clear) and `s_unshift` (1 clear + reshape), which explains
  the 228,703 clears and 457,897 reshapes; these are the main targets of `redundant_clears`,
  `buffer_rotation` and `pattern_products`.

Per-box sizes at |S|=100 (final |W|, |graph_nt|, summed |dG|, summed |X|, calls):

| Workload | box 0 | box 1 | box 2 |
| --- | --- | --- | --- |
| avrora | dG=502, W=347, gnt=502, X=347, calls=76 | dG=2878, W=320, gnt=2878, X=320, calls=71 | dG=3736, W=730, gnt=3736, X=730, calls=106 |
| eclass | dG=1078, W=980, gnt=1078, calls=3 | - | - |
| go | dG=6964, W=1062, gnt=6964, calls=8 | - | - |
| go_hierarchy | dG=18839, W=9073, gnt=18839, calls=2 | - | - |
| mm | dG=1231, W=1327, gnt=1231, calls=29 | dG=1514, W=730, gnt=1514, calls=25 | - |
| init | dG=795, W=949, gnt=795, calls=31 | dG=1053, W=514, gnt=1053, calls=27 | - |
| block | dG=585, W=674, gnt=585, calls=28 | dG=715, W=405, gnt=715, calls=21 | - |

Persistent matrices at |S|=100 (measured call; M/scratch/acc are empty at the end, values are
shown for completeness; `sp` 1=hypersparse 2=sparse; `cb` = column index bits; bytes are
metadata estimates):

| Workload | M (Q x V^2) | P (Q x V^2) | acc (QV x V) | new_edges (1 x V^2) |
| --- | --- | --- | --- | --- |
| avrora | 3439x609596100 n=0 sp=1 cb=32 ~12 B | n=21914 sp=2 cb=32 ~123 KB | 84908910x24690 n=0 ~12 B | n=0 sp=2 iso=1 ~9 B |
| eclass | 6x57174070321 n=0 cb=64 ~16 B | n=3632 sp=2 cb=64 ~33 KB | 1434666x239111 n=0 ~12 B | n=0 sp=2 cb=64 ~8 B |
| go | 6x339806219041 n=0 cb=64 ~16 B | n=13499 sp=2 cb=64 ~122 KB | 3497574x582929 n=0 ~12 B | n=0 sp=2 cb=64 ~8 B |
| go_hierarchy | 6x2025630049 n=0 cb=32 ~12 B | n=37052 sp=2 cb=32 ~185 KB | 270042x45007 n=0 ~12 B | n=0 sp=2 cb=32 ~8 B |
| mm | 8x6442677527049 n=0 cb=64 ~16 B | n=7104 sp=2 cb=64 ~64 KB | 20305944x2538243 n=0 ~12 B | n=0 sp=2 cb=64 ~8 B |
| init | 8x5984011858176 n=0 cb=64 ~16 B | n=4969 sp=2 cb=64 ~45 KB | 19569792x2446224 n=0 ~12 B | n=0 sp=2 iso=1 cb=64 ~9 B |
| block | 8x11718531018756 n=0 cb=64 ~16 B | n=3551 sp=2 cb=64 ~32 KB | 27385872x3423234 n=0 ~12 B | n=0 sp=2 iso=1 cb=64 ~9 B |

All persistent matrices are row-oriented (`orientation=0`); row indices are 32-bit and column
indices are 32-bit or 64-bit depending on `V^2`; the `Q x V^2` frontier/visited matrices are
hypersparse at the end of the call (empty M, sparse P), and only P retains the visited set.
`s_temp` is empty or iso-valued at the end; `new_edges` is iso in some cases (one value).
Peak process memory from cfg_bench (`max_memory_kb`) versus `getrusage` peak RSS at |S|=100:
avrora 23.8/27.1 MB, eclass 54.7/54.0 MB, go 144.3/143.7 MB, go_hierarchy 58.2/57.6 MB,
mm 226.6/226.1 MB, init 219.1/218.4 MB, block 299.8/299.2 MB. These are process-wide and
dominated by parsing/GraphBLAS; the kernel's own persistent bytes are tens of KB to ~200 KB.

#### Recommendation and follow-up

- Recommendation: accept for review.
- Evidence supporting it and workload limits: all measurement cells pass the hardened checks;
  duplicate-baseline noise is quantified per size; the profile identifies the dominant costs with
  an explicit instrumentation perturbation and correctness check of the instrumented build.
- Every regression, especially >5% time or memory flags: none (no candidate was compared). The
  noise floor is the main result: sub-10 ms cases move 5-9% between identical baselines.
- Proposed next task / combination and why: DS-10 against the frozen reference, in this order:
  (1) Java/RDF Phase 1: `pattern_products` and `pattern_unions` on the terminal shift and product,
  plus `redundant_clears`/`buffer_rotation` (conversion is ~21% of avrora Phase 1); (2) C-alias:
  Phase 4/5 return products and frontier assembly (`buffer_rotation`, `single_final`); (3) setup
  at small |S| (`work_avoidance`: `term_src` deduplication) since 2.5 of 18.4 ms at |S|=1 is
  kernel preprocessing; (4) C1/B22 only after measuring per-box duplication, because the
  candidate-to-frontier loss is at most 15.8% on these inputs.
- Questions raised (Q-IDs): none new; Q-001 remains open from DS-00.
- Reproducibility artifacts retained; anything external or missing: see the artifact links above;
  CFG_bench, the GraphBLAS JIT cache, and the oracle's small-instance scope are the external or
  bounded parts. No production file was modified.
- Reviewer decision reference: pending

### DS-01-R2-001 — R2 profile attribution and acceptance

- Date/time (timezone): 2026-11-02 00:25 Europe/Moscow
- Task / instructions acknowledged: R2 (2026-11-01), DS-01-R2
- Status: ready-for-review
- Parent report and parent source checksum: [DS-01-001](#ds-01-001--trustworthy-measurements-and-profiles)
  (affected parts superseded); measured reference
  `experimental/algorithm/cfpq_rsm_lab/variants/correctness_r2.c`
  sha256 `49331a9dfd6678ddd3494218342c11a7e7fdb136e32b9f29b7af767d196ec9de`
- Repository commit; modified/untracked relevant files: `b1f7d708...`; modified
  `experimental/algorithm/cfpq_rsm_lab/run.py`; new/modified
  `experimental/algorithm/cfpq_rsm_lab/variants/cfpq_profile.h`,
  `experimental/algorithm/cfpq_rsm_lab/variants/correctness_profile.c` (generated),
  `experimental/algorithm/cfpq_rsm_lab/tests/make_profile_variant.py`,
  `experimental/algorithm/cfpq_rsm_lab/tests/test_run_acceptance.py`,
  `experimental/algorithm/cfpq_rsm_lab/tests/Makefile` (also used by DS-00-R2).
- Candidate source / patch / implementation commit or checksum: harness `run.py`
  `55d96c5f10a8391a02c3dbe7975d563008ada8dfabd39c2ba851d4bf4cdeae9e`;
  `cfpq_profile.h` `9843fbdd7cc119dd357ce54955c9f1151f472716b84c69507ec554dd3b5d31e4`;
  generated `correctness_profile.c`
  `b693dc6c448df3316d6d7c6cb901cb6f4f2fc5d3e968cae986e6c9af3f2b8d4b`;
  `make_profile_variant.py` `fc5387dd1401f8e31f71068ab86117a07e0231419840eb039f4962ecf44f0a8e`;
  `test_run_acceptance.py` `4e22ad30792f0d2fbc4af32f1b2430b41456d845040ea9b2c30788217df8efd6`.
- Corrected reference source and checksum: `49331a9d...` (DS-00-R2); all DS-01-R2 runs name it.
- Changed files and concise change description:
  - **Timer model (R2 P1).**  The generator now uses separate starts for whole phases
    (`prof_phase_t`), nested sub-operations (`prof_sub_t`), conversion (`prof_conv_t`), summary
    extraction (`prof_box_t`) and diagnostic I/O (`prof_io_t`); the previous shared `prof_t` is
    gone.  Phase times are API elapsed time; each phase is followed by an explicit
    `GrB_Matrix_wait`/`GrB_Vector_wait` completion boundary whose cost is recorded separately
    (`boundary_*_s`).  `total_s` now spans entry to after kernel cleanup (setup and cleanup are
    distinct buckets), `kernel_s = total_s - diag_io_s`, and `unclassified_s` reconciles the
    remainder against a declared tolerance (`1e-4 s + 2%`).  Every measured call reports
    `sanity_ok`; all 21 measured calls at 1/10/100 sources have `sanity_ok=1`, with
    `unclassified_s` between 0.013 ms and 0.53 ms.
  - **Diagnostics (R2 P2).**  Per iteration the record now uses the incoming frontier `|M|` at
    the loop start, `|P|` before the iteration, the logical candidate union
    `|acc | M_call|` and its structural intersection with `P`, and the next frontier.  `|X \ W_old|`
    and `|X intersect W_old|` are probed per box/iteration.  Clears/reshapes are counted at every
    actual operation (helpers `s_shift`, `s_unshift`, `s_mul_acc`, the activity vector clear, Phase 5
    and the early-continue reshapes).  All fixed-size per-box arrays are guarded and set
    `detail_truncated`; profile files are closed on error exits via the cleanup hook; matrix and
    vector bytes use checked `GxB_Matrix_memoryUsage` / `GxB_Vector_memoryUsage`.
  - **Shared acceptance (R2 P2).**  `run.py` now has one `accept_rows()` used by timing and profile
    modes: expected case set, one row per case per round, every round, nonzero hashes, stable
    counts/hashes, per-round count and hash comparison by round ID, and malformed rows rejected.
    Profile mode additionally requires one measured row per case in both reference and profile
    CSVs, well-formed tagged diagnostic records, exactly two records (warm-up + measured) per
    (case, chunk), matching q/v shapes, and `sanity_ok=1`.  Ordinary-mode failure reporting uses
    `.get()`/round IDs, so a missing baseline case or round cannot raise `KeyError`/`IndexError`.
  - **Durable profile identity.**  Profile mode runs one case per invocation with
    `CFPQ_RSM_PROFILE_TAG`; every diagnostic row carries the tag, the kernel call id, and the
    runner-annotated `chunk`, `warmup` and `round` columns (`warmup=1` for the first, unmeasured
    call; `warmup=0` for the measured call).  `profile.csv` and `profile-calls.csv` record the
    case/chunk/round/warm-up identity.
  - **Output reuse and provenance.**  A nonempty output directory is rejected unless `--force`;
    `--force` removes only run-owned entries.  Provenance now hashes every graph, grammar and
    start-node input (17 files, `inputs.sha256`), the runner, generator and profile header, and
    the resolved LAGraph/GraphBLAS libraries; the build stamp covers the reference source,
    `cfpq_profile.h`, `LAGraph.h`, `LAGraphX.h`, `LG_internal.h`, the GraphBLAS header, the
    compiler version and the library files.  `summary.csv` carries per-case median/min/max memory
    with its measurement scope.
  - **Sanitizer target.**  `make asan` is the full check (200 randomized cases, ASan+UBSan+leak
    detection); `make asan-fast` keeps the 20-case, leak-detection-off mode and is labelled as
    such.
- Why the change preserves semantics; scheduling preserved or changed: no kernel scheduling
  change.  The profiling source is generated from the frozen R2 reference with asserted anchors;
  it is verified by the DS-00-R2 oracle suite and by equal counts/hashes in every profile case.

#### Validation evidence

- Exact commands, linkage, exit status and logs (all under
  `experimental/algorithm/cfpq_rsm_lab/build/runs/`):
  - `make -C tests candidate_profile_r2` (generated profiling source, DS-00-R2 suite) → 16,388
    checks, 0 failures
    ([log](experimental/algorithm/cfpq_rsm_lab/build/runs/DS-00-R2/profile-build-oracle-suite.log)).
  - profiles at 1/10/100 sources:
    `run.py --baseline .../correctness_r2.c --profile --source-size S --chunks 1 --seed 2026 --out .../DS-01-R2-profile/sizeS`
    → 7 measured calls each, 0 profile problems, exit 0
    ([size 1](experimental/algorithm/cfpq_rsm_lab/build/runs/DS-01-R2-profile/size1.log),
    [size 10](experimental/algorithm/cfpq_rsm_lab/build/runs/DS-01-R2-profile/size10.log),
    [size 100](experimental/algorithm/cfpq_rsm_lab/build/runs/DS-01-R2-profile/size100.log)).
    Each case's counts/hashes equal the reference build's; every measured record has
    `sanity_ok=1`; `profile.csv`, annotated `*.detail.csv`/`*.matrix.csv`/`*.vector.csv`,
    `profile-calls.csv`, `provenance.txt` and `inputs.sha256` are retained.
  - profiled build correctness: `candidate_profile_r2` (generated source + DS-00-R2 tests) →
    16,388 checks, 0 failures; DS-00-R2 ASan/UBSan/LSan and allocation-failure evidence apply to
    the same reference.
  - harness fixtures: `python3 -m unittest experimental.algorithm.cfpq_rsm_lab.tests.test_run_acceptance`
    → 17 tests OK
    ([log](experimental/algorithm/cfpq_rsm_lab/build/runs/DS-01-R2/fixtures.log)); they cover
    missing/extra/duplicate cases, missing/extra rounds, zero hashes, count-only and hash-only
    mismatches, instability, malformed rows, baseline-missing rows, and output-directory reuse.
  - end-to-end wrong-variant check with the R2 runner (deliberately drops the last source):
    7 workloads flagged `WRONG`, exit 1
    ([log](experimental/algorithm/cfpq_rsm_lab/build/runs/DS-01-R2/selftest-wrong.log)).
  - R2 noise runs: 3 source sizes, 3 chunks, 5 rounds, duplicate `correctness_r2.c` baselines;
    42 summary rows per size, all `ok`, exit 0
    (`DS-01-R2-noise/size{1,10,100}/summary.csv`, `raw/`, `logs/`, `provenance.txt`).
  - combined tables used below:
    [DS-01-R2-tables.txt](experimental/algorithm/cfpq_rsm_lab/build/runs/DS-01-R2-tables.txt).
- Provenance note: the noise runs used `run.py` `847ea910...`; the profile runs used the final
  `55d96c5f...`.  The only difference is the profile warm-up annotation fix (`warmup = 1 - call%2`)
  in `annotate_profile_csv`, which is not executed by timing mode.  Each run's
  `provenance.txt` records the runner/generator/header hashes actually used.
- Independent oracle: DS-00-R2 suite (200 randomized cases, 16,388 checks) and the new
  dense/branching/malformed fixtures; benchmark-sized correctness rests on per-round count+hash
  equality with the reference and the reduced CFG_bench cross-check (DS-00-R2, 15/15).
- Allocation failures and sanitizers: DS-00-R2 full coverage; no new allocation path was added to
  the timing build.  The profiled build allocates four diagnostic matrices and two touched arrays
  (freed by its cleanup) and passes the DS-00-R2 oracle suite (16,388 checks); the reference
  itself passes the sanitizer and allocation-failure checks, and the profiled source was not
  separately sanitized.

#### Benchmark provenance

- Run IDs / raw artifacts: `DS-01-R2-noise/size{1,10,100}` and
  `DS-01-R2-profile/size{1,10,100}`; commands as above.
- Compiler/options, GraphBLAS/LAGraph, machine, threads, JIT: `cc` GCC 16.2.1,
  `-O2 -fPIC -shared -std=c11`; SuiteSparse:GraphBLAS 10.5.2; variants link
  `/usr/local/lib/liblagraph.so.1` and `/usr/local/lib/libgraphblas.so.10`;
  AMD Ryzen 5 7640HS, 12 logical CPUs, 14 GiB, Linux 7.2.11-arch1-1; `OMP_NUM_THREADS=1`;
  per-run `GRAPHBLAS_CACHE_PATH=<out>/jit-cache`, JIT control at the library default (ON);
  `--hot` performs one unmeasured warm-up call per case before the measured `-r 1` call.
- Inputs: `configs/lab.csv` sha256 `dcd7d3cc...`; all 17 graph/grammar/start-node inputs are
  hashed in `inputs.sha256` (e.g., `avrora.g` `8d214230...`, `go.g` `cf1990b3...`,
  `block.g` `1f2c14bf...`).  Actual Q/V: Java avrora Q=3439, V=24690, 3436 terminal labels,
  3 boxes; RDF eclass/go/go_hierarchy Q=6, V=239111/582929/45007, labels 20/94/4, 1 box;
  C-alias mm/init/block Q=8, V=2538243/2446224/3423234, labels 4, 2 boxes.  Labels are the
  post-explosion terminal count; the pre-explosion indexed-family count is not exposed by the RSM
  file (unavailable).  The assessment's 3439 Java states are confirmed; the RSM has 3 boxes, not
  858; RDF 6-state/1-box and C-alias 8-state/2-box are confirmed.
- Expected vs observed: per size, 7 cases x 3 chunks = 21 result rows per variant per round,
  5 rounds, 2 variants = 210 rows; all present, all `ok`, no zero hashes, no missing rounds.
  Profile passes: 7 measured calls per size (chunk 0), 2 records (warm-up + measured) per case.
- Instrumentation on/off; materialization: timing runs uninstrumented and cfg_bench waits on the
  result; profile runs add diagnostic probes, explicit phase waits and a final wait.  Profile
  timings are attribution only; the uninstrumented adapter-run-plus-wait medians remain the
  verdict.

#### Results

**R2 duplicate-baseline noise (correctness_r2.c, seed 2026, 3 chunks, 5 rounds).**  Medians are
over the 3 chunks; duplicate ranges are per-case `min..max`.

| |S| | Workload | median ms | min..max ms | duplicate ratio |
| --- | --- | --- | --- | --- |
| 1 | Java avrora | 22.14 | 21.14..22.81 | 0.942..1.012 |
| 1 | RDF eclass | 0.439 | 0.432..0.455 | 0.913..0.959 |
| 1 | RDF go | 0.461 | 0.458..1.272 | 0.987..1.008 |
| 1 | RDF go_hierarchy | 0.379 | 0.345..0.439 | 0.979..1.037 |
| 1 | C-alias mm | 0.723 | 0.670..1.538 | 0.989..1.056 |
| 1 | C-alias init | 0.681 | 0.669..0.691 | 1.002..1.190 |
| 1 | C-alias block | 1.297 | 0.715..2.860 | 0.955..1.524 |
| 10 | Java avrora | 392.5 | 130.6..1307.4 | 0.988..0.999 |
| 10 | RDF eclass | 0.821 | 0.820..1.317 | 0.923..1.026 |
| 10 | RDF go | 1.282 | 0.923..8.475 | 0.986..1.004 |
| 10 | RDF go_hierarchy | 1.029 | 1.026..1.484 | 0.950..1.012 |
| 10 | C-alias mm | 1.971 | 1.904..7.145 | 0.956..1.007 |
| 10 | C-alias init | 9.121 | 7.185..11.295 | 0.991..1.034 |
| 10 | C-alias block | 6.324 | 5.980..6.987 | 0.990..1.001 |
| 100 | Java avrora | 6083.4 | 2118.7..6162.1 | 0.991..1.007 |
| 100 | RDF eclass | 2.885 | 1.946..3.729 | 1.008..1.037 |
| 100 | RDF go | 13.02 | 10.01..19.04 | 0.966..0.998 |
| 100 | RDF go_hierarchy | 12.91 | 12.13..17.41 | 0.943..1.007 |
| 100 | C-alias mm | 21.80 | 21.35..31.75 | 0.982..1.079 |
| 100 | C-alias init | 19.12 | 9.93..27.57 | 0.983..1.008 |
| 100 | C-alias block | 28.11 | 15.23..29.33 | 0.962..1.006 |

- Aggregate duplicate ratios: |S|=1 `0.913..1.524` (median 0.9995, geo 1.016), |S|=10
  `0.923..1.034` (median 0.9912, geo 0.9897), |S|=100 `0.943..1.079` (median 0.9916,
  geo 0.9939).  Sub-10 ms cases still move several percent; the 1.52 outlier is a sub-ms
  C-alias case.  The R1 noise rows for `bba6ee09...` (DS-01-001) remain historical and are not
  relabelled.  The R2 medians are within run-to-run noise of R1 (avrora 6083 vs 6070 ms at
  |S|=100, 392.5 vs 393.9 ms at |S|=10), so the added shape checks are not observable outside
  noise at these sizes.

**Corrected phase attribution (profile measured call, milliseconds).**  Phase times are API
elapsed time and include the diagnostic probes; boundary waits are separate; `total` includes
setup and cleanup; `uncl` is the reconciled remainder.

| |S| | Workload | total | setup | activity | P1 | P2+3 | P4 | P5 | final | mat | boundary | diag I/O | uncl | P1 conv | conv total |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | avrora | 22.10 | 2.67 | 0.03 | 18.74 | 0.41 | 0.04 | 0.11 | 0.01 | 0.002 | 0.003 | 0.040 | 0.014 | 3.99 | 4.04 |
| 1 | eclass | 1.01 | 0.05 | 0.06 | 0.31 | 0.18 | 0.10 | 0.21 | 0.02 | 0.002 | 0.005 | 0.043 | 0.032 | 0.05 | 0.12 |
| 1 | go | 0.56 | 0.04 | 0.03 | 0.18 | 0.10 | 0.05 | 0.12 | 0.01 | 0.001 | 0.003 | 0.024 | 0.013 | 0.03 | 0.06 |
| 1 | go_hierarchy | 0.57 | 0.03 | 0.04 | 0.13 | 0.12 | 0.06 | 0.14 | 0.01 | 0.002 | 0.003 | 0.034 | 0.014 | 0.02 | 0.06 |
| 1 | mm | 1.83 | 0.03 | 0.09 | 0.36 | 0.57 | 0.34 | 0.38 | 0.01 | 0.001 | 0.010 | 0.029 | 0.018 | 0.07 | 0.23 |
| 1 | init | 0.86 | 0.02 | 0.04 | 0.17 | 0.26 | 0.12 | 0.19 | 0.01 | 0.001 | 0.006 | 0.026 | 0.013 | 0.03 | 0.10 |
| 1 | block | 0.81 | 0.02 | 0.04 | 0.14 | 0.25 | 0.12 | 0.18 | 0.01 | 0.001 | 0.005 | 0.026 | 0.013 | 0.03 | 0.10 |
| 10 | avrora | 414.97 | 2.86 | 0.30 | 404.70 | 4.64 | 1.02 | 1.25 | 0.01 | 0.002 | 0.040 | 0.051 | 0.065 | 86.05 | 86.57 |
| 10 | eclass | 1.07 | 0.03 | 0.06 | 0.32 | 0.21 | 0.13 | 0.24 | 0.01 | 0.002 | 0.006 | 0.029 | 0.021 | 0.05 | 0.11 |
| 10 | go | 2.33 | 0.06 | 0.13 | 0.71 | 0.46 | 0.32 | 0.53 | 0.02 | 0.004 | 0.015 | 0.051 | 0.037 | 0.10 | 0.25 |
| 10 | go_hierarchy | 1.65 | 0.02 | 0.05 | 0.53 | 0.24 | 0.30 | 0.42 | 0.03 | 0.020 | 0.005 | 0.025 | 0.017 | 0.04 | 0.14 |
| 10 | mm | 2.26 | 0.03 | 0.08 | 0.54 | 0.70 | 0.45 | 0.38 | 0.01 | 0.002 | 0.020 | 0.031 | 0.021 | 0.12 | 0.30 |
| 10 | init | 8.04 | 0.02 | 0.21 | 2.17 | 2.63 | 1.86 | 0.95 | 0.01 | 0.002 | 0.107 | 0.039 | 0.036 | 0.46 | 0.99 |
| 10 | block | 7.84 | 0.02 | 0.20 | 2.05 | 2.55 | 1.91 | 0.94 | 0.01 | 0.003 | 0.083 | 0.030 | 0.039 | 0.44 | 0.93 |
| 100 | avrora | 6201.76 | 3.18 | 1.67 | 6073.85 | 64.00 | 28.63 | 28.70 | 0.04 | 0.010 | 1.001 | 0.096 | 0.526 | 1287.90 | 1293.50 |
| 100 | eclass | 3.25 | 0.04 | 0.07 | 0.90 | 0.62 | 0.82 | 0.69 | 0.03 | 0.005 | 0.008 | 0.028 | 0.027 | 0.14 | 0.29 |
| 100 | go | 14.10 | 0.07 | 0.23 | 3.34 | 1.38 | 4.67 | 4.16 | 0.06 | 0.062 | 0.029 | 0.039 | 0.052 | 0.43 | 0.97 |
| 100 | go_hierarchy | 12.54 | 0.04 | 0.06 | 3.67 | 1.31 | 3.74 | 3.56 | 0.10 | 0.001 | 0.007 | 0.028 | 0.032 | 0.37 | 1.04 |
| 100 | mm | 22.76 | 0.04 | 0.29 | 4.56 | 6.11 | 8.50 | 2.92 | 0.04 | 0.018 | 0.172 | 0.056 | 0.059 | 0.94 | 1.83 |
| 100 | init | 21.29 | 0.04 | 0.31 | 4.55 | 6.06 | 7.28 | 2.71 | 0.03 | 0.010 | 0.187 | 0.049 | 0.062 | 0.94 | 1.84 |
| 100 | block | 17.01 | 0.05 | 0.26 | 3.94 | 4.83 | 5.59 | 2.04 | 0.04 | 0.010 | 0.139 | 0.041 | 0.058 | 0.78 | 1.54 |

- Corrected ranking: Java remains Phase-1 dominated, but at 97.9% (6073.9/6201.8) at |S|=100,
  97.5% at |S|=10 and 84.8% at |S|=1 (18.74/22.10); representation conversion is 21.2% of the
  Phase-1 API time at |S|=100 (1287.9 ms) and 20.7% at |S|=10 (86.1 ms).  For RDF and C-alias,
  Phase 4 (summary extraction plus return products) is now the largest single phase at |S|=100:
  go 4.67/14.10 ms (33%), go_hierarchy 3.74/12.54 (30%), mm 8.50/22.76 (37%),
  init 7.28/21.29 (34%), block 5.59/17.01 (33%), eclass 0.82/3.25 (25%).  This supersedes the
  DS-01-001 statement that Phase 1 dominates every workload.
- Sub-operation breakdown at |S|=100 (ms, subset of the containing phase): Java call construction
  10.9, W update 3.9, summary extraction 14.8, return products 12.4; RDF go 0.30/0.14/2.45/2.10;
  C-alias mm 1.45/1.34/3.83/4.39, init 1.51/1.13/3.35/3.59, block 1.25/0.81/2.66/2.67.  Diagnostic
  probes (X/W probes inside Phase 2+3, candidate-union probes inside Phase 5) cost 1.16 ms of
  mm's 6.11 ms Phase 2+3 and 0.68 ms of its 2.92 ms Phase 5; boundary waits are <=0.77 ms total.
  The probes are profile-only and are excluded from the timing verdict.
- **C1 waiting-state duplication.**  `|X \ W_old|` equals `|X|` and `|X intersect W_old|` is 0 for
  every box and iteration at all three source sizes on chunk 0 (e.g., at |S|=100: avrora
  sum |X|=1397, all fresh; mm 2057 all fresh; go_hierarchy 9073 all fresh).  The
  candidate-union/visited intersection is a different quantity: 856/22670 (3.8%) for avrora,
  2522/15921 (15.8%) for go, 5490/42442 (12.9%) for go_hierarchy, 435/7439 (5.8%) for mm,
  458/5327 (8.6%) for init, 248/3699 (6.7%) for block.  **DS-01-001's "candidate-to-frontier
  loss bounds C1" claim is withdrawn**: it measures overlap with the visited set, not
  waiting-state duplication.  On chunk 0 of these workloads C1 deduplication has no measured
  opportunity; a later DS-21 experiment must first find duplication with heavy fixtures or other
  chunks/schedules.
- Operation counters at |S|=100 (all sizes in `profile.csv`): avrora 160 iterations,
  sum |M| 21914 / max 1542, sum |P| 2097591 (final 21914), 227903 terminal shifts,
  273857 prediction skips, 48000 static skips, 253 calls, 359 dG unions, 358 return products,
  457366 clears and 456766 reshapes.  The clear/reshape counts now include `s_mul_acc`'s product
  clear and the activity clear, so they supersede DS-01-001's 228703/457897 for the same
  workload.  RDF/C-alias counters are in `profile.csv`.
- Memory at |S|=100 (measured call): actual GraphBLAS bytes are small — P is 123.6 KB (avrora),
  121.8 KB (go), 185.5 KB (go_hierarchy), 64.2 KB (mm), 45.0 KB (init), 32.2 KB (block),
  33.0 KB (eclass); per-workload sums of W are 8.5–49.8 KB and graph_nt 9.9–98.6 KB; M/scratch/
  acc/new_edges are empty or 256–272 B at call end.  Peak intermediate values (nvals) and actual
  bytes for the diagnostic matrices are in `*.matrix.csv`; vectors are ~90 KB or less (go_hierarchy
  entry_vec, 1845 entries, 90.3 KB).  Process peak RSS from the profile is 29.7 MB (avrora), 51–143 MB
  (RDF), 216–296 MB (C-alias); these are process-wide and dominated by parsing/GraphBLAS, not by
  the kernel's persistent matrices.

#### Recommendation and follow-up

- Recommendation: accept for review.
- Evidence supporting it and workload limits: corrected timer attribution with reconciliation on
  every measured call, shared acceptance with a fixture suite for every failure mode, durable
  profile identity, actual byte queries, complete provenance, refreshed 1/10/100-source noise and
  profiles on `49331a9d...`, all profile cases matching the reference counts/hashes.
- Every regression, especially >5% time or memory flags: none measured as a candidate change.
  Profile-mode totals exceed the uninstrumented medians by ~0–12% depending on workload; that is
  instrumentation, not a regression.  R2 medians are within R1 noise.
- Proposed next task / combination and why: DS-10 against `49331a9d...`, starting with the
  measured costs: (1) Java Phase 1 (`pattern_products`, `redundant_clears`, `buffer_rotation`;
  conversion is 21% of Phase 1); (2) C-alias/RDF Phase 4 summary extraction and return products
  (`single_final`, `buffer_rotation`, product variants) and Phase 2+3 call/W-update work;
  (3) small-|S| setup (`work_avoidance`); (4) C1 only after finding actual duplicate waiting
  states; the current workloads/chunk show none.
- Questions raised (Q-IDs): none new; Q-001 is resolved by R2 and recorded in DS-00-R2-001.
- Reproducibility artifacts retained; anything external or missing: all logs, profiles,
  annotated diagnostics, input manifests and provenance under the gitignored lab build area;
  sources are in the working tree (not committed); CFG_bench and the GraphBLAS JIT cache remain
  external.
- Reviewer decision reference: pending

### Report template — copy below this section

```markdown
### <report ID> — <task/variant name>

- Date/time (timezone):
- Task / instructions acknowledged:
- Status:
- Parent report and parent source checksum:
- Repository commit; modified/untracked relevant files:
- Candidate source / patch / implementation commit or checksum:
- Corrected reference source and checksum:
- Changed files and concise change description:

#### Correctness reasoning

- Relations and index mappings changed:
- True-only input boundary / behavior for out-of-contract input:
- Start-box, epsilon, NULL/empty, recursion, and same-iteration event handling:
- Ownership, buffer shapes, allocation/error cleanup:
- Why the change preserves semantics; scheduling preserved or changed:

#### Validation evidence

- Exact build/test commands, candidate linkage, exit status, and logs:
- Independent oracle: cases, sizes, seeds, exact-set comparisons:
- Deterministic regressions and singleton/multi-source comparisons:
- Allocation-failure injection and sanitizer/leak results, with coverage limits:
- Reduced CFG_bench final check and logs:
- Frontier/summary traces: artifact links and comparison, or reason not required:
- Failures, minimal reproducer, and unresolved risks:

#### Benchmark provenance

- Run ID / raw artifact directory / exact commands:
- Compiler/options; GraphBLAS and LAGraph versions and loaded library paths:
- CPU/RAM, OS, threads, affinity, relevant environment:
- Config checksum; graph/grammar/RSM/source-list identities:
- Actual Q/V, boxes/labels/finals/indexed-family counts:
- Source sizes, actual chunks/source counts, seeds, rounds, warm-up behavior:
- Instrumentation on/off; synchronization/materialization boundaries:
- Timer scope, preprocessing/reuse scope, and memory measurement scope:
- Expected cases/rounds versus observed; zero hashes/missing/unstable data:

#### Results (one row per workload/source-size/chunk/seed)

| Graph / grammar | Sources / chunk / seed | Runs | Ref median s / IQR | Variant median s / IQR | Time ratio | Ref / variant peak RSS | Count / hash stable and equal | Raw evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| <case> | <actual values> | <n> | <value> | <value> | <variant/ref> | <value and units> | <counts/hashes or artifact> | <link> |

- Duplicate-baseline variation and interpretation:
- Source-size-specific aggregates (only after per-case results):
- Confirmation seeds 2027/2028; disagreements or regressions:
- Phase costs and matrix bytes/formats/index widths/iso status:
- Candidate/new/duplicate counts, W/dG/P sizes and component/batch counts:
- Setup/conversion/assembly costs and temporary-memory peaks:
- Unavailable counters and limits of conclusions:

#### Recommendation and follow-up

- Recommendation: accept for review | revise | retain as experiment | defer
- Evidence supporting it and workload limits:
- Every regression, especially >5% time or memory flags:
- Proposed next task / combination and why:
- Questions raised (Q-IDs):
- Reproducibility artifacts retained; anything external or missing:
- Reviewer decision reference: pending
```

## Handoff history

| Date | Author | Revision / report | Handoff |
| --- | --- | --- | --- |
| 2026-11-01 | Codex reviewer | R1 | Created the two-file workflow; DS-00 and subsequent queue specified; awaiting DeepSeek work |
| 2026-11-01 | DeepSeek implementer | R1 acknowledged; DS-00-001 | Corrected reference `bba6ee09...`, oracle + regressions + 200 randomized cases, sanitizers, allocation sweep, reduced CFG_bench 15/15; DS-00 ready-for-review; DS-01 starting |
| 2026-11-01 | DeepSeek implementer | DS-01-001 | Hardened runner acceptance/provenance, duplicate-baseline noise at |S|=1/10/100, per-call phase/counter profiles; DS-00 and DS-01 ready-for-review; stopped for review |
| 2026-11-01 | DeepSeek implementer | R2 acknowledged; DS-00-R2-001 | Input-shape validation before native indexing (`correctness_r2.c` `49331a9d...`), malformed/dense regressions, oracle worklist dedup, full sanitizer target; R2 reference passes all checks; DS-00-R2 ready-for-review |
| 2026-11-02 | DeepSeek implementer | DS-01-R2-001 | Corrected timer attribution (separate starts, completion boundaries, setup/cleanup reconciliation), shared acceptance and fixtures, durable profile identity, actual byte queries, 1/10/100-source noise and profiles on `49331a9d...`; DS-01-R2 ready-for-review; stopped |
| 2026-11-02 | DeepSeek implementer | R5 acknowledged; R5-001 | DS-20/21/22 full-source variants, runner hot-rounds/thread changes, `run_overnight.sh` + `summarize_overnight.py`; build/functional/7-pair smoke checks pass; overnight comparisons left to the user |
| 2026-11-02 | DeepSeek implementer | R9 acknowledged; R9-001 | DS-36…DS-39 and DS-30…DS-35 full-source variants, `run_r9_overnight.sh` + `summarize_r9_overnight.py`; build/`--smoke`/7-pair lab pass for all ten; 30-command dry run checked; overnight timing left to the user |
| 2026-11-02 | DeepSeek implementer | R10; R10-001 | d1_native, config_block and d3_masked_product full-source variants; 13-variant `run_r10_overnight.sh` + `summarize_r10_overnight.py` (R9 pair preserved); build/`--smoke`/7-pair lab pass for all three; 39-command dry run checked; overnight timing left to the user |

## R5-001 — DS-20/21/22 preparation and handoff

- Task / instruction revision: R5 (2026-11-02)
- Status: **ready-for-review**. The three variants, the runner changes, `run_overnight.sh`
  and `summarize_overnight.py` are delivered. **The nine overnight comparisons were not
  run**, and no overnight result is reported here.
- Baseline: `experimental/algorithm/cfpq_rsm_lab/variants/baseline.c`,
  sha256 `f3642839be04eee2d6411d3db9d6973c50c19f386d7e61f4d9ff5a926af0447b`
  (matches the expected value; byte-identical to
  `experimental/algorithm/LAGraph_CFPQ_RSM.c`, which is unchanged at the same checksum).
- Variants, each a full source copy of that baseline with the exported
  `LAGraph_CFPQ_RSM` signature preserved:
  - `variants/ds20.c` sha256 `498d857414feced902ef74b23dfcd4b030f3ef77d3540864186b0ffa8eab7fa9`:
    every non-NULL `W[i]` and `new_edges` is put in `GxB_BY_COL` storage with
    `GxB_HYPERSPARSE` control immediately after allocation.  SuiteSparse:GraphBLAS 10.5.2
    keeps storage orientation through `GxB_Matrix_reshape` but resets the sparsity-control
    hint, so the setting is re-applied after each `new_edges` reshape; `W[i]` is never
    reshaped, and in-place updates keep its options.  No transpose, no second `W`, no
    format alternative.
  - `variants/ds21.c` sha256 `6668b2e542d94659987015af276a4963ad08a21748dc567f44da9139a09abf5c`:
    after each `s_shift`, if old `W[i]` is nonempty, `scratch = scratch \ W[i]` via
    `GrB_apply(... GrB_IDENTITY_BOOL ... GrB_DESC_RSC)`; an empty scratch is restored and
    skipped.  Calls, the `graph_nt[i]` multiplication and the `W[i]` union use only the
    fresh scratch.  Phase 4 is unchanged and still uses the updated `W[i]` with new summary
    edges.
  - `variants/ds22.c` sha256 `d3270385d5dd02f13c7c8065ce94e96a26d18cae372df6ca26416194a1511545`:
    visited `P` is `(Q*V) x V`, seeded by row-major `GxB_Matrix_reshapeDup` of `M`; one
    reusable BOOL `fresh_B` is allocated and cleaned up.  Phase 5 reshapes `M_call`
    row-major to `(Q*V) x V`, computes `fresh_B = (acc | M_call) \ P`, updates `P`, rebuilds
    `M_new` by row-major reshape of `fresh_B`, clears `acc`/`M_call`, restores `M_call` to
    `Q x (V*V)`, and keeps the baseline swap and termination check.

### Build and functional checks

`--smoke` was added to `tests/test_ds00.c`; it runs only `test_single_terminal()`,
`test_empty_and_zero()` and `test_recursion()` and skips random and other suites.  Build and
run (substitute `ds21`/`ds22` for `ds20`):

```bash
cd /home/hollow/repo/LAGraph/experimental/algorithm/cfpq_rsm_lab/tests
make R2=/home/hollow/repo/LAGraph/experimental/algorithm/cfpq_rsm_lab/variants/ds20.c \
     candidate_correctness_r2
/home/hollow/repo/LAGraph/experimental/algorithm/cfpq_rsm_lab/build/tests/candidate_correctness_r2 --smoke
```

| variant | build | `--smoke` | logs |
| --- | --- | --- | --- |
| ds20 | exit 0 | exit 0, `checks=453 failures=0` | `build/r5-smoke/functional/ds20-final-build.log`, `ds20-final-smoke.log` |
| ds21 | exit 0 | exit 0, `checks=453 failures=0` | `build/r5-smoke/functional/ds21-final-build.log`, `ds21-smoke.log` |
| ds22 | exit 0 | exit 0, `checks=453 failures=0` | `build/r5-smoke/functional/ds22-final-build.log`, `ds22-smoke.log` |

`tests/test_run_acceptance.py` also passes (17 tests).

One failure was observed and fixed.  The first DS-22 smoke failed because the visited seed
used a column-major reshape (`true`) instead of the required row-major mapping
`M[q, u*V+v] <-> P[q*V+u, v]`; the failures were `S->a[NULL calls]`,
`S->a[empty calls]` and `direct-recursion[src=1]`.  Fix:
`GxB_Matrix_reshapeDup(&P, M, false, Q * V, V, GrB_NULL)`.  The observed output and the
reproduction recipe are in
`build/r5-smoke/functional/ds22-initial-failure.txt`; the rebuilt binary passes.  No other
functional failure occurred.

### Seven-pair smoke comparison

The work-order command was run once per variant with a fresh output directory
(`SMOKE_ROOT=/home/hollow/repo/LAGraph/experimental/algorithm/cfpq_rsm_lab/build/r5-smoke/final`):

```bash
LAB=/home/hollow/repo/LAGraph/experimental/algorithm/cfpq_rsm_lab
SMOKE_ROOT=$LAB/build/r5-smoke/final
python3 "$LAB/run.py" \
  --baseline "$LAB/variants/baseline.c" \
  --config "$LAB/configs/lab.csv" \
  --variants "baseline,baseline,ds20" \
  --source-size 1 --chunks 1 --rounds 1 --hot-rounds 0 \
  --seed 2026 --threads 0 --out "$SMOKE_ROOT/ds20"
```

The same command with `ds21` and `ds22` substituted was used for the other variants.

| variant | exit | summary rows | bad rows | console log |
| --- | --- | --- | --- | --- |
| ds20 | 0 | 21 | 0 | `build/r5-smoke/final/ds20.console.log` |
| ds21 | 0 | 21 | 0 | `build/r5-smoke/final/ds21.console.log` |
| ds22 | 0 | 21 | 0 | `build/r5-smoke/final/ds22.console.log` |

Every row is `status=ok`, `count_ok=1`, `hash_ok=1`; result counts and hashes match the
baseline on every case.  These are functional checks only: one measured round with
`--hot-rounds 0` leaves the first baseline invocation paying JIT compilation, so the
printed ratios are not performance data.  Full commands and logs are also in
`experimental/algorithm/cfpq_rsm_lab/build/r5-smoke/EVIDENCE.md`.

### Runner changes

- Default baseline is now `variants/baseline.c`; default chunks are 30; rounds stay 5 and
  seed 2026.
- `--threads 0` is the default and means unrestricted library/runtime threading.  In both
  timing and profiling child environments it removes `OMP_NUM_THREADS` and
  `OMP_THREAD_LIMIT`; no GraphBLAS thread cap or CPU affinity is set.  Positive
  `--threads N` still sets `OMP_NUM_THREADS=N`.  Provenance records the selected mode.
- `--hot-rounds {0,1}`, default 1, applies to timing mode: `--hot` is appended only to the
  round-0 invocation, so each variant/workload/chunk gets one unmeasured warm-up plus five
  measured runs.  Measured-round rotation is retained.
- Count/hash acceptance, CSVs, logs and provenance are unchanged; timing builds still have
  no `CFPQ_RSM_PROFILE` define.  No `--profile` call is made by the overnight script.

These were checked without a benchmark process by using a stub `cfg_bench`: two rounds
produced six invocations, only the three round-0 invocations carried `--hot`, both OMP
variables were absent under `--threads 0`, `--threads 2` set `OMP_NUM_THREADS=2`, and the
provenance lines recorded both settings.

### Overnight handoff

Launch the nine foreground comparisons (no output-root argument; the script creates a unique
timestamped directory under `build/runs/`):

```bash
/home/hollow/repo/LAGraph/experimental/algorithm/cfpq_rsm_lab/run_overnight.sh
```

Or with an explicit, previously unused output root:

```bash
/home/hollow/repo/LAGraph/experimental/algorithm/cfpq_rsm_lab/run_overnight.sh /path/to/output-root
```

Regenerate the morning summary at any time (including after an interrupted run that still has
`status.tsv`):

```bash
python3 /home/hollow/repo/LAGraph/experimental/algorithm/cfpq_rsm_lab/summarize_overnight.py /path/to/output-root
```

The dry-run check, which prints the nine commands and builds/runs nothing:

```bash
/home/hollow/repo/LAGraph/experimental/algorithm/cfpq_rsm_lab/run_overnight.sh --dry-run
```

`bash -n run_overnight.sh` and the dry run both exit 0.  The driver rejects a non-empty output
root without deleting anything.  An integration test with a stubbed `run.py` produced nine
`status.tsv` rows, recorded a forced exit-3 comparison as `FAILED`, continued through the
remaining comparisons, wrote `commands.sh` plus one shell-escaped `.command` per comparison
(all `bash -n` clean), generated both morning-summary files, and returned 1.  A synthetic
63-row summarizer run exercised MATCH, FAIL (count/hash mismatch, partial chunks, missing
summary) and NOT_RUN (missing comparison, no data, interrupted with partial data), with
incomplete timings marked and the duplicate-baseline noise table populated.

### Notes

- DS-21: as the work order states, the measured chunks have no waiting-state duplication, so
  this variant may only add overhead; it was implemented and handed off for comparison
  anyway.
- `--hot-rounds 0` remains available for measurements that do not want the warm-up.
- No overnight results, no winner, no acceptance decision, and no speedup claim are made in
  this report.

## R9-001 — DS-36…DS-35 preparation and handoff

- Task / instruction revision: R9 (2026-11-02)
- Status: **ready-for-review**.  Ten independent full-source variants, the R9 overnight
  driver and the R9 summarizer are delivered.  All ten build, pass `--smoke`, and pass the
  seven-pair lab acceptance.  **The 30 overnight comparisons were not run**, and no speedup,
  memory or winner claim is made here.
- Baseline (frozen parent for every variant):
  `experimental/algorithm/cfpq_rsm_lab/variants/baseline.c`,
  sha256 `f3642839be04eee2d6411d3db9d6973c50c19f386d7e61f4d9ff5a926af0447b`; it is
  byte-identical to `experimental/algorithm/LAGraph_CFPQ_RSM.c`, which is unchanged.
- Evidence root (fresh): `experimental/algorithm/cfpq_rsm_lab/build/r9-checks-1vbEwMGt`
  (created with `mktemp -d "$LAB/build/r9-checks-XXXXXXXX"`; `--force` was not used).
  `status.tsv` has exactly 30 rows (10 build, 10 functional, 10 lab), every one `exit_code 0`.
- Public API, true-only BOOL input contract, result and phase schedule are unchanged in
  every variant.  No variant links the CFL wrapper, adds a shared helper header, packs wide
  labels, uses explicit Kronecker matrices, or combines another experiment.  Production,
  baseline, the existing runner, tests, old variants and run artifacts are untouched.

### Variant hashes

| Variant | sha256 | One-line change |
| --- | --- | --- |
| `variants/ds36_pair.c` | `796030c006dc0df62d0aa51b21638015ea7181058627018e9faa6711301e29df` | all five mxm/mxv semirings → `GxB_ANY_PAIR_BOOL` |
| `variants/ds37_fused.c` | `21a56c43510f71f919ef5405a40317a30fe66a075701635eea4c7fc037fe32b3` | `s_mul_acc` body → one fused `GrB_mxm(C, NULL, GrB_LOR, ...)` |
| `variants/ds38_no_product_clear.c` | `ba91e5c42ec505760d601006c7edf3e0d7ccdf6772eb7be1e6cd4198ba370fd7` | deleted only the product-temporary clear in `s_mul_acc` |
| `variants/ds39_direct_calls.c` | `e9fbc199814b9901fb463631c10439a93d9f97227865f7e97f2dcef73e51ba00` | tuples + one `GrB_Matrix_build_BOOL` for `M_call`; `diag_entry`/`rsm_start` removed |
| `variants/ds30_assign.c` | `9952a1123f3e2edfae30b60abe006eb09892af9556a3b77eefccb74ef1e46d5f` | three growing-state unions → structural masked scalar `true` assign |
| `variants/ds31_joint.c` | `3b39940a19ba885d0a4ac5ae7798ab984425cf8ec3fa527ae0726dc369e14270` | sorted joint `(q,t)`/`(v,t)` index replaces row activity prediction |
| `variants/ds32_empty.c` | `a156634dba2e5aae15d8881df31b4250c6cdb2a11be88184cb0f4361b0022675` | first nonempty product swaps into `acc`; later products union |
| `variants/ds33_format.c` | `9196fb84375c529525e036f2558460c1f36bb4cd90068c823fcef184649da5d0` | terminal-only adaptive orientation with one immutable cache per active label |
| `variants/ds34_lazy_p.c` | `7aa7d7cca1b4a6210e88bb838d1fbf73f6be2b5278c759f32ed6147439e2692c` | visited `P` held as one disjoint component bag; Phase 5 subtracts it |
| `variants/ds35_lazy_nt.c` | `5c5331f4dbdbbf02b7a4c956b2d292c3cab2c44972dc818cd6efa942b9bc519b` | each `graph_nt[i]` held as a component bag; streamed skip/return products |

### Exact preparation commands

```bash
cd /home/hollow/repo/LAGraph
LAB=$PWD/experimental/algorithm/cfpq_rsm_lab
EVIDENCE=$(mktemp -d "$LAB/build/r9-checks-XXXXXXXX")
set -uo pipefail
printf 'variant\tstep\texit_code\n' > "$EVIDENCE/status.tsv"
prepare_one() {
    local name=$1 rc
    if make -B -C "$LAB/tests" R2="$LAB/variants/$name.c" \
        candidate_correctness_r2 >"$EVIDENCE/$name.build.log" 2>&1; then rc=0; else rc=$?; fi
    printf '%s\tbuild\t%s\n' "$name" "$rc" >> "$EVIDENCE/status.tsv"
    ((rc == 0)) || return "$rc"
    if env -u OMP_NUM_THREADS -u OMP_THREAD_LIMIT \
        "$LAB/build/tests/candidate_correctness_r2" --smoke \
        >"$EVIDENCE/$name.functional.log" 2>&1; then rc=0; else rc=$?; fi
    printf '%s\tfunctional\t%s\n' "$name" "$rc" >> "$EVIDENCE/status.tsv"
    ((rc == 0)) || return "$rc"
    if python3 "$LAB/run.py" --baseline "$LAB/variants/baseline.c" \
        --config "$LAB/configs/lab.csv" --variants "baseline,baseline,$name" \
        --source-size 1 --chunks 1 --rounds 1 --hot-rounds 0 \
        --seed 2026 --threads 0 --out "$EVIDENCE/$name" \
        >"$EVIDENCE/$name.lab.log" 2>&1; then rc=0; else rc=$?; fi
    printf '%s\tlab\t%s\n' "$name" "$rc" >> "$EVIDENCE/status.tsv"
    return "$rc"
}
for name in ds36_pair ds37_fused ds38_no_product_clear ds39_direct_calls ds30_assign ds31_joint ds32_empty ds33_format ds34_lazy_p ds35_lazy_nt; do
    prepare_one "$name" || continue
done
```

The `prepare_one` loop above is the exact command block that was run; the evidence root is
`build/r9-checks-1vbEwMGt`.  Functional logs: `checks=453 failures=0` in all ten.

### Seven-pair lab acceptance

The seven graph/grammar workloads in `configs/lab.csv` are Java/avrora,
RDF/eclass, RDF/go, RDF/go_hierarchy, C-alias/mm, C-alias/init and C-alias/block.  For every
variant the lab run wrote 21 `summary.csv` rows (7 `baseline`, 7 `baseline#2`, 7 candidate);
all 21 rows are `status=ok`, `count_ok=1`, `hash_ok=1`, and all seven distinct pairs are
present for each display.  Lab logs are `$EVIDENCE/<name>.lab.log` and summaries are
`$EVIDENCE/<name>/summary.csv`.  One measured round with `--hot-rounds 0` is a functional
check only; its timings are not performance evidence.

| Variant | build | `--smoke` | lab | seven-pair rows | bad rows |
| --- | --- | --- | --- | --- | --- |
| ds36_pair | 0 | 0 | 0 | 21 | 0 |
| ds37_fused | 0 | 0 | 0 | 21 | 0 |
| ds38_no_product_clear | 0 | 0 | 0 | 21 | 0 |
| ds39_direct_calls | 0 | 0 | 0 | 21 | 0 |
| ds30_assign | 0 | 0 | 0 | 21 | 0 |
| ds31_joint | 0 | 0 | 0 | 21 | 0 |
| ds32_empty | 0 | 0 | 0 | 21 | 0 |
| ds33_format | 0 | 0 | 0 | 21 | 0 |
| ds34_lazy_p | 0 | 0 | 0 | 21 | 0 |
| ds35_lazy_nt | 0 | 0 | 0 | 21 | 0 |

### R9 overnight scripts and handoff

- `experimental/algorithm/cfpq_rsm_lab/run_r9_overnight.sh` is a copy of
  `run_overnight.sh` with only the R9 variant list, the `summarize_r9_overnight.py` name,
  the `r9-overnight-` default prefix, the `total = ${#SOURCES[@]} * ${#VARIANTS[@]}` count
  and the ten-name help/comments changed.  It keeps sequential failure-continuing
  execution, command/log/status retention, fresh-output-root rejection and exit behavior.
- `experimental/algorithm/cfpq_rsm_lab/summarize_r9_overnight.py` is a copy of
  `summarize_overnight.py` with only the `VARIANTS` tuple (ten names), the 210-row
  description, the dynamic MATCH-none message and the script-name references changed.
  Correctness checks, duplicate-baseline noise, time ratios, process-memory scope and
  FAIL/NOT_RUN handling are unchanged.
- `bash -n run_r9_overnight.sh` and `python3 -m py_compile summarize_r9_overnight.py` exit 0.
- `bash "$LAB/run_r9_overnight.sh" --dry-run` exits 0 and prints exactly **30** commands
  (10 variants × 3 source sizes), each with `--chunks 30 --rounds 5 --hot-rounds 1
  --seed 2026 --threads 0`; the shared launch command for the user is:

```bash
LAB=/home/hollow/repo/LAGraph/experimental/algorithm/cfpq_rsm_lab
bash "$LAB/run_r9_overnight.sh"
```

- Omitted variants: **none**.  All ten passed build, `--smoke` and the seven-pair lab
  check, so every name remains in both scripts.
- Speed and process-memory fields for every variant: `not measured` (the user runs the
  30 long comparisons; DeepSeek ran only the dry run).

### DS-36-R9-001 — Pattern products (`variants/ds36_pair.c`)

- Task / instruction revision: R9 (2026-11-02), DS-36
- Status: ready-for-review; prepared, not timed
- Parent: `variants/baseline.c` sha256 `f3642839...`; candidate sha256
  `796030c006dc0df62d0aa51b21638015ea7181058627018e9faa6711301e29df`
- Exact edit: the five `GrB_LOR_LAND_SEMIRING_BOOL` uses in mxm/mxv were replaced by
  `GxB_ANY_PAIR_BOOL` — `s_shift`, `s_mul_acc`, the `M_call` product, the Phase 4
  `new_edges` product and the final reachability mxv.  All `GrB_LOR` accumulators,
  reductions, masks, layouts, clears, helpers and the phase schedule are unchanged.  No
  ANY accumulator or wrapper code was added.
- Build/test: `make -B -C "$LAB/tests" R2="$LAB/variants/ds36_pair.c" candidate_correctness_r2`
  exit 0 (`$EVIDENCE/ds36_pair.build.log`); `candidate_correctness_r2 --smoke` exit 0,
  `checks=453 failures=0` (`$EVIDENCE/ds36_pair.functional.log`); seven-pair lab command
  above exit 0 (`$EVIDENCE/ds36_pair.lab.log`).
- Seven-pair outcome: 7/7 candidate rows (and 7/7 for both baseline copies) `status=ok`,
  `count_ok=1`, `hash_ok=1`; `$EVIDENCE/ds36_pair/summary.csv`.
- Observed failure/fix: none.
- Overnight launch: `bash "$LAB/run_r9_overnight.sh"` runs this variant at sources 1, 10
  and 100; time and memory `not measured`.

### DS-37-R9-001 — Fused product accumulation (`variants/ds37_fused.c`)

- Task / instruction revision: R9 (2026-11-02), DS-37
- Status: ready-for-review; prepared, not timed
- Parent: `variants/baseline.c` sha256 `f3642839...`; candidate sha256
  `21a56c43510f71f919ef5405a40317a30fe66a075701635eea4c7fc037fe32b3`
- Exact edit: only the body of `s_mul_acc` became
  `GrB_mxm(C, GrB_NULL, GrB_LOR, GrB_LOR_LAND_SEMIRING_BOOL, A, B, GrB_NULL)`.  The
  signature is retained, `T` is unused, the `s_temp` allocation and cleanup remain, the
  iteration-boundary `acc` clear and every other operation are unchanged.  No ANY_PAIR,
  empty check, mask or format change was added.
- Build/test: shared `make -B` command exit 0 (`$EVIDENCE/ds37_fused.build.log`);
  `--smoke` exit 0, `checks=453 failures=0`
  (`$EVIDENCE/ds37_fused.functional.log`); lab exit 0 (`$EVIDENCE/ds37_fused.lab.log`).
- Seven-pair outcome: 7/7 each display `status=ok`, `count_ok=1`, `hash_ok=1`;
  `$EVIDENCE/ds37_fused/summary.csv`.  This is the control to compare separately with
  DS-32, which pays for a product-count query.
- Observed failure/fix: none.
- Overnight launch: `bash "$LAB/run_r9_overnight.sh"` runs this variant at sources 1, 10
  and 100; time and memory `not measured`.

### DS-38-R9-001 — Remove one redundant clear (`variants/ds38_no_product_clear.c`)

- Task / instruction revision: R9 (2026-11-02), DS-38
- Status: ready-for-review; prepared, not timed
- Parent: `variants/baseline.c` sha256 `f3642839...`; candidate sha256
  `ba91e5c42ec505760d601006c7edf3e0d7ccdf6772eb7be1e6cd4198ba370fd7`
- Exact edit: deleted only `H_TRY(GrB_Matrix_clear(T));` in `s_mul_acc`, immediately before
  its unmasked, no-accumulator overwrite mxm.  The mxm and the union remain; `s_unshift`,
  `rowvec`, `acc` and `M_call` clears and all other statements are retained.  No buffer
  rotation or fused accumulation.
- Build/test: shared `make -B` command exit 0 (`$EVIDENCE/ds38_no_product_clear.build.log`);
  `--smoke` exit 0, `checks=453 failures=0`
  (`$EVIDENCE/ds38_no_product_clear.functional.log`); lab exit 0
  (`$EVIDENCE/ds38_no_product_clear.lab.log`).
- Seven-pair outcome: 7/7 each display `status=ok`, `count_ok=1`, `hash_ok=1`;
  `$EVIDENCE/ds38_no_product_clear/summary.csv`.
- Observed failure/fix: none.
- Overnight launch: `bash "$LAB/run_r9_overnight.sh"` runs this variant at sources 1, 10
  and 100; time and memory `not measured`.

### DS-39-R9-001 — Direct flat-layout calls (`variants/ds39_direct_calls.c`)

- Task / instruction revision: R9 (2026-11-02), DS-39
- Status: ready-for-review; prepared, not timed
- Parent: `variants/baseline.c` sha256 `f3642839...`; candidate sha256
  `e9fbc199814b9901fb463631c10439a93d9f97227865f7e97f2dcef73e51ba00`
- Exact edit: `M/P/M_call` stay `Q x V²` and `entry_vec` reduction is retained.  Per
  iteration the reusable tuple length resets, the existing `M_call` clear remains, and
  after each box's `entry_vec` reduction its true vertex indices are extracted into a
  reusable `LAGraph_Realloc`-grown buffer; `(start_states[i], v*V+v, true)` tuples are
  appended.  The box's `diag_entry` creation, reshape, call mxm and free are removed; after
  the loop `M_call` is built once with `GrB_Matrix_build_BOOL(..., GrB_LOR)` (left empty
  when there are no tuples, duplicate entries union).  Extraction and tuple buffers are
  reused across iterations and freed in normal/error cleanup; `diag_entry` and `rsm_start`
  construction/cleanup are removed while input validation is kept.  Summary skip
  products, W updates and return order are unchanged; tuple extraction/build and setup
  are inside the timed call.
- Build/test: shared `make -B` command exit 0 (`$EVIDENCE/ds39_direct_calls.build.log`);
  `--smoke` exit 0, `checks=453 failures=0`
  (`$EVIDENCE/ds39_direct_calls.functional.log`); lab exit 0
  (`$EVIDENCE/ds39_direct_calls.lab.log`).
- Seven-pair outcome: 7/7 each display `status=ok`, `count_ok=1`, `hash_ok=1`;
  `$EVIDENCE/ds39_direct_calls/summary.csv`.
- Observed failure/fix: none.
- Overnight launch: `bash "$LAB/run_r9_overnight.sh"` runs this variant at sources 1, 10
  and 100; time and memory `not measured`.

### DS-30-R9-001 — Masked scalar insertion (`variants/ds30_assign.c`)

- Task / instruction revision: R9 (2026-11-02), DS-30
- Status: ready-for-review; prepared, not timed
- Parent: `variants/baseline.c` sha256 `f3642839...`; candidate sha256
  `9952a1123f3e2edfae30b60abe006eb09892af9556a3b77eefccb74ef1e46d5f`
- Exact edit: only the three growing-state updates changed to structural masked scalar
  `true` assignment with no REPLACE, complement or accumulator:
  `W[i]` with `scratch` (`Q*V x V`), `graph_nt[i]` with `new_edges` (`V x V`), and `P`
  with `M_new` (`Q x V*V`), each with `GrB_ALL` and `GrB_DESC_S`.  Every other union,
  subtraction, emptiness guard and operation order is unchanged; unmasked state entries
  survive and duplicate `W` insertions are allowed.
- Build/test: shared `make -B` command exit 0 (`$EVIDENCE/ds30_assign.build.log`);
  `--smoke` exit 0, `checks=453 failures=0` (`$EVIDENCE/ds30_assign.functional.log`);
  lab exit 0 (`$EVIDENCE/ds30_assign.lab.log`).
- Seven-pair outcome: 7/7 each display `status=ok`, `count_ok=1`, `hash_ok=1`;
  `$EVIDENCE/ds30_assign/summary.csv`.
- Observed failure/fix: none.
- Overnight launch: `bash "$LAB/run_r9_overnight.sh"` runs this variant at sources 1, 10
  and 100; time and memory `not measured`.

### DS-31-R9-001 — Joint state/vertex terminal filtering (`variants/ds31_joint.c`)

- Task / instruction revision: R9 (2026-11-02), DS-31
- Status: ready-for-review; prepared, not timed
- Parent: `variants/baseline.c` sha256 `f3642839...`; candidate sha256
  `3b39940a19ba885d0a4ac5ae7798ab984425cf8ec3fa527ae0726dc369e14270`
- Exact edit: static `term_active` is retained; for active labels only, RSM row indices and
  graph row indices are extracted once in setup, sorted and uniqued into `(q,t)` and
  `(v,t)` pairs; edge-sized temporary extraction arrays are freed after indexing.  RSM
  labels are stored as `Q+1` offsets with sorted label lists per `q`; graph labels as
  distinct present-vertex keys, offsets and sorted label IDs with binary search on the
  keys (no `V x labels` or `V²` allocation).  Per iteration the frontier row/column indices
  are extracted into reusable capacity-managed arrays, `v = column % V`, and the two sorted
  label lists are intersected; a label stays eligible for the remainder of the iteration
  and duplicate `(q,v)` visits are allowed.  The baseline `rowvec`/`active`/`term_src`
  prediction machinery and its allocations are removed; static graph/RSM emptiness checks
  are kept.  Phase 1 still runs the unchanged shift/product/unshift chain for eligible
  labels; nonterminal phases are untouched.  Index construction and per-iteration
  extraction are inside the timed call, so an expensive index can make this variant lose
  even when many products are skipped.
- Build/test: shared `make -B` command exit 0 (`$EVIDENCE/ds31_joint.build.log`);
  `--smoke` exit 0, `checks=453 failures=0` (`$EVIDENCE/ds31_joint.functional.log`);
  lab exit 0 (`$EVIDENCE/ds31_joint.lab.log`).
- Seven-pair outcome: 7/7 each display `status=ok`, `count_ok=1`, `hash_ok=1`, including
  Java/avrora and all six other pairs; `$EVIDENCE/ds31_joint/summary.csv`.
- Observed failure/fix in the required checks: none.  Note outside the R9 pass definition:
  the retained deterministic suite (`--no-random`, which is not part of the R9 acceptance)
  reports 3 failures for the `Q*V*V overflows int64` invalid-input case.  Baseline rejected
  that case only incidentally, because its removed `active`/`active_idx` arrays were
  `Q`-sized; DS-31's sparse index legitimately accepts the dimensions.  No code change was
  made; the retained log is `$EVIDENCE/optional-deterministic/ds31_joint.no-random.log`.
- Overnight launch: `bash "$LAB/run_r9_overnight.sh"` runs this variant at sources 1, 10
  and 100; time and memory `not measured`.

### DS-32-R9-001 — Empty product / first contribution (`variants/ds32_empty.c`)

- Task / instruction revision: R9 (2026-11-02), DS-32
- Status: ready-for-review; prepared, not timed
- Parent: `variants/baseline.c` sha256 `f3642839...`; candidate sha256
  `a156634dba2e5aae15d8881df31b4250c6cdb2a11be88184cb0f4361b0022675`
- Exact edit: `s_mul_acc` now takes `GrB_Matrix *C`, `GrB_Matrix *T` and `bool *acc_empty`.
  `acc_empty` starts true at `acc` creation and is reset true immediately after the existing
  Phase 5 `acc` clear.  The baseline `*T` clear and overwrite mxm are kept; product nvals is
  queried once after mxm, and a zero product returns without union and without changing the
  flag.  The first nonempty product swaps `*C`/`*T` and sets `acc_empty=false`; later
  nonempty products use the existing `C |= T` union.  All three call sites (terminal,
  summary skip, return) pass `&acc`, `&s_temp`, `&acc_empty`; no other clear was removed and
  Phase 5 is unchanged.  Cleanup still frees each current handle once.
- Build/test: shared `make -B` command exit 0 (`$EVIDENCE/ds32_empty.build.log`);
  `--smoke` exit 0, `checks=453 failures=0` (`$EVIDENCE/ds32_empty.functional.log`); lab
  exit 0 (`$EVIDENCE/ds32_empty.lab.log`), including the empty-source and recursive cases.
- Seven-pair outcome: 7/7 each display `status=ok`, `count_ok=1`, `hash_ok=1`;
  `$EVIDENCE/ds32_empty/summary.csv`.
- Observed failure/fix: none.
- Overnight launch: `bash "$LAB/run_r9_overnight.sh"` runs this variant at sources 1, 10
  and 100; time and memory `not measured`.

### DS-33-R9-001 — Adaptive orientation / immutable cache (`variants/ds33_format.c`)

- Task / instruction revision: R9 (2026-11-02), DS-33
- Status: ready-for-review; prepared, not timed
- Parent: `variants/baseline.c` sha256 `f3642839...`; candidate sha256
  `9196fb84375c529525e036f2558460c1f36bb4cd90068c823fcef184649da5d0`
- Exact edit: applies only to terminal products `scratch * graph_term[t]`.  Setup caches
  each active terminal's graph nvals and native `GxB_FORMAT`; the caller handle is borrowed
  read-only and one NULL-initialized private opposite-format `V x V` handle per active label
  is freed at query cleanup.  At a terminal product `a = tn`, `b = cached graph nvals`,
  desired is `GxB_BY_ROW` if `a < b` (ties choose `GxB_BY_COL`).  If the desired view is
  missing and `b <= a/3.0`, the ordinary baseline helper is used; otherwise the missing
  view is built once with `GrB_Matrix_dup` + `GrB_Matrix_set_INT32(..., desired, GxB_FORMAT)`,
  and a native desired orientation uses the borrowed handle.  An adapted product sets
  `scratch` and `s_temp` to the desired format, runs the baseline clear, mxm and union, then
  restores both to `GxB_BY_ROW`; `acc` keeps its baseline orientation and pays any
  mixed-format union cost.  No hypersparsity or threshold tuning was added.  Setup, cache
  conversion and restoration are timed; process peak memory is reported by the runner.
- Build/test: shared `make -B` command exit 0 (`$EVIDENCE/ds33_format.build.log`);
  `--smoke` exit 0, `checks=453 failures=0` (`$EVIDENCE/ds33_format.functional.log`); lab
  exit 0 (`$EVIDENCE/ds33_format.lab.log`).
- Seven-pair outcome: 7/7 each display `status=ok`, `count_ok=1`, `hash_ok=1`;
  `$EVIDENCE/ds33_format/summary.csv`.
- Observed failure/fix: none.  A slower result is still a completed experiment; the fixed
  heuristic was not redesigned.
- Overnight launch: `bash "$LAB/run_r9_overnight.sh"` runs this variant at sources 1, 10
  and 100; time and memory `not measured`.

### DS-34-R9-001 — Lazy visited state (`variants/ds34_lazy_p.c`)

- Task / instruction revision: R9 (2026-11-02), DS-34
- Status: ready-for-review; prepared, not timed
- Parent: `variants/baseline.c` sha256 `f3642839...`; candidate sha256
  `7aa7d7cca1b4a6210e88bb838d1fbf73f6be2b5278c759f32ed6147439e2692c`
- Exact edit: ordinary `P` is replaced by one component bag of `Q x V²` matrices, seeded
  with a duplicate of nonempty initial `M` and its known nnz; `M` stays independently owned.
  The fixed bag helper stores owned handles, cached component nnz, cached total nnz and a
  fixed `8*sizeof(GrB_Index)+1` live-record array; append ranks by `floor(log2(nnz))`,
  unions an equal-rank component into the carry with baseline `GrB_LOR`, frees/removes it,
  adds cached counts and repeats; subtraction visits records in reverse live order with
  `GrB_apply(..., GrB_DESC_RSC)`, refreshes the candidate nvals after each mask and stops at
  zero; immutable component counts are never updated on a read.  Phase 5 retains
  `reshapeDup` and the `acc` clear, forms `M_new = M_new OR M_call` with no mask, subtracts
  every bag component, and if the frontier is nonempty duplicates it once into an owned
  delta and appends it (the `M_new` handle is not transferred).  Ordinary `P` union/dup/free
  is removed; `graph_nt` and `W` stay ordinary; all products/calls are unchanged; `P` is
  never materialized; the final candidate nnz drives loop termination.  Frontier
  duplication and the multiple mask passes are real measured costs of this experiment.
- Build/test: shared `make -B` command exit 0 (`$EVIDENCE/ds34_lazy_p.build.log`);
  `--smoke` exit 0, `checks=453 failures=0` (`$EVIDENCE/ds34_lazy_p.functional.log`); lab
  exit 0 (`$EVIDENCE/ds34_lazy_p.lab.log`).
- Seven-pair outcome: 7/7 each display `status=ok`, `count_ok=1`, `hash_ok=1`;
  `$EVIDENCE/ds34_lazy_p/summary.csv`.
- Observed failure/fix: none.
- Overnight launch: `bash "$LAB/run_r9_overnight.sh"` runs this variant at sources 1, 10
  and 100; time and memory `not measured`.

### DS-35-R9-001 — Lazy summary relations (`variants/ds35_lazy_nt.c`)

- Task / instruction revision: R9 (2026-11-02), DS-35
- Status: ready-for-review; prepared, not timed
- Parent: `variants/baseline.c` sha256 `f3642839...`; candidate sha256
  `5c5331f4dbdbbf02b7a4c956b2d292c3cab2c44972dc818cd6efa942b9bc519b`
- Exact edit: each `graph_nt[i]` is replaced by an initially empty `V x V` component bag;
  emptiness queries use cached `total != 0`.  The Phase 2+3 skip product is streamed as
  `s_mul_acc(acc, scratch, component, s_temp)` for every live summary component with the
  unchanged helper; operands are never reversed and products are not kept.  In Phase 4,
  after the baseline reshape to `V x V`, the bag is subtracted and, if the delta is
  nonempty, duplicated once into an owned handle and appended to that box's bag where the
  old summary union occurred; the original `new_edges` is kept for the unchanged
  `W[i]*new_edges` product and later reshape, preserving same-iteration return ordering and
  disjoint summary deltas.  Final reachability allocates the usual zero output vector and
  calls `GrB_mxv(*reachable, NULL, GrB_LOR, GrB_LOR_LAND_SEMIRING_BOOL, component,
  source_mask, GrB_DESC_T0)` per start-summary component; an empty bag leaves the result
  empty, and no summary is materialized.  Bags/carries are cleaned up; ordinary `graph_nt`
  allocation/free is removed.  Product fan-out is a real measured cost; a loss is reported
  without redesign.
- Build/test: shared `make -B` command exit 0 (`$EVIDENCE/ds35_lazy_nt.build.log`);
  `--smoke` exit 0, `checks=453 failures=0` (`$EVIDENCE/ds35_lazy_nt.functional.log`); lab
  exit 0 (`$EVIDENCE/ds35_lazy_nt.lab.log`).
- Seven-pair outcome: 7/7 each display `status=ok`, `count_ok=1`, `hash_ok=1`;
  `$EVIDENCE/ds35_lazy_nt/summary.csv`.
- Observed failure/fix: none.
- Overnight launch: `bash "$LAB/run_r9_overnight.sh"` runs this variant at sources 1, 10
  and 100; time and memory `not measured`.

### Recommendation and follow-up

- Recommendation: retain all ten as independent experiments; stop for review and for the
  user's 30 overnight comparisons.  No combination, promotion or winner is proposed.
- Evidence supporting it: 30/30 preparation steps exit 0; 210/210 seven-pair lab rows
  (`status=ok`, `count_ok=1`, `hash_ok=1`); the 30-command dry run is correct.
- Every regression: timing and memory `not measured`; no performance claim is made.
- Proposed next task: the user runs `bash run_r9_overnight.sh`, then the morning summary is
  read against the duplicate-baseline noise spread before any decision.
- Questions raised (Q-IDs): none new.
- Reproducibility artifacts retained: evidence root `build/r9-checks-1vbEwMGt` (build,
  functional and lab logs, per-variant `summary.csv`, provenance with source hashes,
  `status.tsv`, optional DS-31 deterministic log).  Nothing external is needed beyond the
  existing CFG_bench checkout and GraphBLAS build.
- Reviewer decision reference: pending.

## R10-001 — D1/config_block/D3 preparation and 13-variant handoff

- Task / instruction revision: R10 (2026-11-02), implementing the three named
  `DEEPSEEK_REMAINDER.md` candidates at the user's direct activation.
- Status: **ready-for-review**.  Three new full-source variants are delivered, all build,
  pass `--smoke`, and pass the seven-pair lab acceptance.  The R10 overnight driver and
  summarizer cover all ten passing R9 variants plus these three (13 variants, 39
  comparisons).  **The 39 overnight comparisons were not run**, and no speedup, memory or
  winner claim is made here.
- Baseline (frozen parent): `experimental/algorithm/cfpq_rsm_lab/variants/baseline.c`,
  sha256 `f3642839be04eee2d6411d3db9d6973c50c19f386d7e61f4d9ff5a926af0447b`; it remains
  byte-identical to `experimental/algorithm/LAGraph_CFPQ_RSM.c` (unchanged).
- Evidence root (fresh): `experimental/algorithm/cfpq_rsm_lab/build/r10-checks-8JIj2Bx9`
  (created with `mktemp -d "$LAB/build/r10-checks-XXXXXXXX"`).  `status.tsv` has exactly
  9 rows (3 build, 3 functional, 3 lab), every one `exit_code 0`.
- Production, baseline, the existing runner/tests, all R9 variants and all R9 artifacts are
  unchanged.

### New variant hashes

| Variant | sha256 | Scope |
| --- | --- | --- |
| `variants/d1_native.c` | `c2d7e56d94b112eefb10ecf11636c9ae7f24940f9fb93ad4814fd5b0db25d259` | block P/calls, direct call tuples, subtract-before-frontier-reshape Phase 5 |
| `variants/config_block.c` | `291bf59c4494bc657ccb8ef81027be077a9d91b9d78725fe53695a214fcca808` | all configuration matrices block `QV x V`, implicit RSM routing, no reshape |
| `variants/d3_masked_product.c` | `d1f8f856ca86000e215d92cc8bae0f31a2c512e8999568e5437eec71318accad` | d1_native with terminal/skip/return graph products masked by block P |

### d1_native — exact edits

`variants/d1_native.c` is a full source based on the frozen baseline.  Frontier `M`/`M_new`
stay `Q x V²`; `P`, `acc` and `M_call` are block `QV x V`; `W`/`scratch` remain `QV x V`;
graph adjacency/summaries stay `V x V`; RSM matrices stay `Q x Q`.  `P` is initialized with
`GxB_Matrix_reshapeDup(&P, M, false, Q*V, V, GrB_NULL)` (row-major mapping).  The
`entry_vec` reduction is kept; each entry vertex `v` appends the block call tuple
`(start_states[i]*V+v, v, true)`, `M_call` is cleared once per iteration, tuples are
accumulated across boxes with reused capacity-managed buffers and built once with
`GrB_Matrix_build_BOOL(..., GrB_LOR)`; `diag_entry` and `rsm_start` are removed while
validation is kept.  Phase 5 is exactly the specified sequence:

```c
GRB_TRY(GrB_eWiseAdd(acc, P, GrB_NULL, GrB_LOR, acc, M_call, GrB_DESC_RSC));
GRB_TRY(GrB_eWiseAdd(P, GrB_NULL, GrB_NULL, GrB_LOR, P, acc, GrB_NULL));
GRB_TRY(GrB_free(&M_new));
GRB_TRY(GxB_Matrix_reshapeDup(&M_new, acc, false, Q, V * V, GrB_NULL));
GRB_TRY(GrB_Matrix_clear(acc));
```

The baseline frontier swap and termination check are retained; `M_call` is cleared at the
normal next-iteration boundary.  Terminal products, summary products, W bookkeeping,
return ordering and baseline operators are unchanged; no lazy bags, ANY_PAIR, masked
scalar insertion, fused accumulation or format tuning were added.  The direct-call block
uses the same mechanism as the earlier DS-39 experiment but with the block-shaped
`start_state*V+v` row and `v` column; d1_native's layout remains independent and is not a
DS-39 combination.  Call extraction/build and every reshape are inside the timed call.

### config_block — exact edits

`variants/config_block.c` is an independent full source from the same baseline.  Frontier
`M`/`M_new`, `P`, `acc`, `M_call`, `W` and `scratch` are block `QV x V`; graph
relations/summaries stay `V x V`; RSM relations stay `Q x Q`; no Kronecker matrix or
reshape/`reshapeDup` is used.  Initial calls are seeded at `[start_state*V+s, s]`.  Setup
extracts each active terminal's and each present nonterminal's RSM transitions into
per-label `q -> r` adjacency lists, preserving repeated destinations, and extracts each
box's final-state indices once.  Each iteration extracts the block frontier tuples once,
decodes `q = row/V`, `u = row%V`, `v = column`, and buckets the tuple indices by `q` with
`Q`-sized offset/cursor arrays (no `QV` activity array).  Routing one label visits its
`q -> r` edges, emits `(r*V+u, v, true)` for each tuple in bucket `q`, clears the `QV x V`
scratch and builds it with LOR duplicate handling.  Terminal propagation then uses the
baseline `acc |= scratch * graph_term[t]`; nonterminal propagation uses the same routing,
the same block call insertion, the baseline summary product and the W union in the
baseline order.  Phase 4 visits the same frontier buckets for each box's final-state list
and bulk-builds `V x V` summary candidates `(u, v)`, then keeps the baseline
`new_edges \ graph_nt[i]` subtraction, summary union and `W[i]*dG` ordering.  Phase 5
overwrites block `M_new` with `(acc OR M_call) \ P` using the complemented structural P
mask, unions `M_new` into P, clears `acc` and swaps frontiers; `M_call` clears at its
normal boundary.  Semirings, state unions, input contract and result are unchanged.
Extraction, routing, bucketing, tuple builds and setup are inside the timed call; routing
may cost more than the baseline and is not redesigned here.

### d3_masked_product — exact edits

`variants/d3_masked_product.c` is a copy of `variants/d1_native.c` with the immediate
d1_native control retained.  Only the graph-product helper changed: its signature receives
the block-shaped visited `P`, and the overwrite product is

```c
GrB_mxm(T, P, GrB_NULL, GrB_LOR_LAND_SEMIRING_BOOL, A, B, GrB_DESC_RSC)
```

with the subsequent `acc` union unchanged.  The mask is passed at all three graph-product
sites (terminal, summary-skip and return); the flat `Q x V²` RSM shift is not masked, and
fused accumulation is not introduced.  The final Phase 5 subtraction, iteration schedule
and calls are unchanged.  d3 must be timed against both the frozen baseline and d1_native
to separate masking from layout.

### Exact preparation commands

```bash
cd /home/hollow/repo/LAGraph
LAB=$PWD/experimental/algorithm/cfpq_rsm_lab
EVIDENCE=$(mktemp -d "$LAB/build/r10-checks-XXXXXXXX")
set -uo pipefail
printf 'variant\tstep\texit_code\n' > "$EVIDENCE/status.tsv"
prepare_one() {
    local name=$1 rc
    if make -B -C "$LAB/tests" R2="$LAB/variants/$name.c" \
        candidate_correctness_r2 >"$EVIDENCE/$name.build.log" 2>&1; then rc=0; else rc=$?; fi
    printf '%s\tbuild\t%s\n' "$name" "$rc" >> "$EVIDENCE/status.tsv"
    ((rc == 0)) || return "$rc"
    if env -u OMP_NUM_THREADS -u OMP_THREAD_LIMIT \
        "$LAB/build/tests/candidate_correctness_r2" --smoke \
        >"$EVIDENCE/$name.functional.log" 2>&1; then rc=0; else rc=$?; fi
    printf '%s\tfunctional\t%s\n' "$name" "$rc" >> "$EVIDENCE/status.tsv"
    ((rc == 0)) || return "$rc"
    if python3 "$LAB/run.py" --baseline "$LAB/variants/baseline.c" \
        --config "$LAB/configs/lab.csv" --variants "baseline,baseline,$name" \
        --source-size 1 --chunks 1 --rounds 1 --hot-rounds 0 \
        --seed 2026 --threads 0 --out "$EVIDENCE/$name" \
        >"$EVIDENCE/$name.lab.log" 2>&1; then rc=0; else rc=$?; fi
    printf '%s\tlab\t%s\n' "$name" "$rc" >> "$EVIDENCE/status.tsv"
    return "$rc"
}
for name in d1_native config_block d3_masked_product; do
    prepare_one "$name" || continue
done
```

`--smoke` logs show `checks=453 failures=0` for all three.  The optional deterministic
`--no-random` suite also passes for all three (`checks=2008 failures=0`); it is not part of
the stated acceptance.  Those optional logs are retained under
`$EVIDENCE/optional-deterministic/<name>.no-random.log`.

### Seven-pair lab acceptance

For every new variant the lab run wrote 21 `summary.csv` rows (7 `baseline`, 7
`baseline#2`, 7 candidate); all rows are `status=ok`, `count_ok=1`, `hash_ok=1`, with all
seven graph/grammar pairs present for each display.  Candidate counts and hashes equal the
baseline exactly on all seven pairs, including Java/avrora.

| Variant | build | `--smoke` | lab | seven-pair rows | bad rows |
| --- | --- | --- | --- | --- | --- |
| d1_native | 0 | 0 | 0 | 21 | 0 |
| config_block | 0 | 0 | 0 | 21 | 0 |
| d3_masked_product | 0 | 0 | 0 | 21 | 0 |

Logs: `$EVIDENCE/<name>.build.log`, `$EVIDENCE/<name>.functional.log`,
`$EVIDENCE/<name>.lab.log`, `$EVIDENCE/<name>/summary.csv`.

### Overnight handoff

The R9 handoff pair is preserved as the 10-variant artifact.  The updated 13-variant
handoff is `experimental/algorithm/cfpq_rsm_lab/run_r10_overnight.sh` with
`experimental/algorithm/cfpq_rsm_lab/summarize_r10_overnight.py`.  They include, in this
order: `ds36_pair`, `ds37_fused`, `ds38_no_product_clear`, `ds39_direct_calls`,
`ds30_assign`, `ds31_joint`, `ds32_empty`, `ds33_format`, `ds34_lazy_p`, `ds35_lazy_nt`,
`d1_native`, `config_block`, `d3_masked_product`.  Benchmark settings are unchanged:
source sizes `1 10 100`, `CHUNKS=30`, `ROUNDS=5`, `HOT_ROUNDS=1`, `SEED=2026`,
`THREADS=0`, frozen baseline and `configs/lab.csv`.

- `bash -n run_r10_overnight.sh` and `python3 -m py_compile summarize_r10_overnight.py`
  exit 0.
- `bash "$LAB/run_r10_overnight.sh" --dry-run` exits 0 and prints exactly **39** commands
  (13 variants × 3 source sizes), 13 per source size and 3 per variant; every command has
  `--chunks 30 --rounds 5 --hot-rounds 1 --seed 2026 --threads 0`.  Saved at
  `$EVIDENCE/r10-overnight-dry-run.txt`.
- `summarize_r10_overnight.py` was exercised against an empty status file: it emits the
  expected **273** rows (13 variants × 3 source sizes × 7 workloads), all `NOT_RUN`.
- Omitted variants: **none**.  All three new variants passed, and the ten R9 variants are
  unchanged and remain passing from [R9-001](#r9-001--ds-36ds-35-preparation-and-handoff).
- Speed and process-memory fields for all 13 variants: `not measured`; the user launches
  the 39 comparisons with:

```bash
LAB=/home/hollow/repo/LAGraph/experimental/algorithm/cfpq_rsm_lab
bash "$LAB/run_r10_overnight.sh"
```

### Recommendation and follow-up

- Recommendation: retain all three as independent experiments; stop for review and for the
  user's 39 overnight comparisons.  No combination, promotion or winner is proposed.
- Evidence supporting it: 9/9 preparation steps exit 0; 63/63 seven-pair lab rows
  (`status=ok`, `count_ok=1`, `hash_ok=1`); 39-command dry run correct; R10 summarizer
  row count correct.
- Every regression: timing and memory `not measured`; no performance claim is made.
- Proposed next task: run `run_r10_overnight.sh`, read the morning summary against the
  duplicate-baseline noise spread, and compare d3 separately against both baseline and
  d1_native.
- Questions raised (Q-IDs): none new.
- Reproducibility artifacts retained: `build/r10-checks-8JIj2Bx9` (build, functional and
  lab logs, per-variant `summary.csv`, provenance with source hashes, `status.tsv`, dry-run
  output); `build/r10-summary-smoke/` for the 273-row summarizer check.
- Reviewer decision reference: pending.
