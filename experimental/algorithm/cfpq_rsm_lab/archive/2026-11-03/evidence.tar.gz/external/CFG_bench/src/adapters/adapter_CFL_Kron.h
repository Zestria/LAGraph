#pragma once

#include "adapter.h"
#include <GraphBLAS.h>
#include <LAGraph.h>

AdapterMethods adapter_CFL_Kron_get_methods(void);
