# DeepSeek work order — R9 with accepted R10 additions (2026-11-02)

**CURRENT HANDOFF: R10.** The three remainder candidates (`d1_native`, `config_block`, `d3_masked_product`) are also accepted; see `DEEPSEEK_REMAINDER.md` for the review record. All 13 variants are ready. The user should run `bash experimental/algorithm/cfpq_rsm_lab/run_r10_overnight.sh`, which supersedes the ten-variant R9 launch command retained below. No overnight benchmark has been launched by the reviewer. D4/D5 are removed; no preparation tasks remain for this batch.

**R9 PREPARATION ACCEPTED — reviewer, 2026-11-02.** All ten variants are ready for the user-run overnight experiment. The retained work order below describes the completed preparation; do not repeat it or reopen accepted tasks. DeepSeek must not launch the long experiment or combine/promote variants. No speedup or memory conclusion is available yet.

Review evidence: `experimental/algorithm/cfpq_rsm_lab/build/r9-checks-1vbEwMGt`. Verified 30/30 successful preparation statuses, all ten `checks=453 failures=0` logs, 210/210 matching lab summary rows (seven workloads x three baseline/candidate displays x ten comparisons), and current source hashes matching both reports and smoke provenance. Frozen baseline still matches production. The overnight driver passes Bash syntax and its dry run produces exactly 30 commands with the required settings; summarizer settings and syntax match. No new workload run was needed.

Non-blocking note: optional DS-31 `--no-random` diagnostics have three assertions for one synthetic enormous-dimension case that now returns success rather than the expected error. Required smoke/lab checks pass; no repair or extra test sweep is required for this experiment.

Next action: user runs `bash experimental/algorithm/cfpq_rsm_lab/run_r9_overnight.sh`. Keep each variant independent and retain all artifacts. The original implementation hold and future-tense preparation wording below are historical; this acceptance governs the completed R9 batch. The three additions in `DEEPSEEK_REMAINDER.md` have since been activated, completed and accepted under R10; see the current handoff above.

## Fixed scope and files

All paths below are relative to `/home/hollow/repo/LAGraph` unless expanded by the commands.

- `LAB=experimental/algorithm/cfpq_rsm_lab`.
- Frozen parent for **every** variant: `$LAB/variants/baseline.c`, SHA-256 `f3642839be04eee2d6411d3db9d6973c50c19f386d7e61f4d9ff5a926af0447b`.
- Create ten independent full-source variants in `$LAB/variants/`: `ds36_pair.c`, `ds37_fused.c`, `ds38_no_product_clear.c`, `ds39_direct_calls.c`, then `ds30_assign.c`, `ds31_joint.c`, `ds32_empty.c`, `ds33_format.c`, `ds34_lazy_p.c`, `ds35_lazy_nt.c`. Each copies the frozen parent, never another experiment. Put variant-specific static helpers in that file; do not link the CFL wrapper or add shared helper headers.
- Allowed support additions: `$LAB/run_r9_overnight.sh` and `$LAB/summarize_r9_overnight.py`, specified below. Append reports to `DEEPSEEK_FEEDBACK.md`. Preserve production, baseline, existing runner/tests/scripts, old variants and run artifacts.
- True-only BOOL input contract; same public API, result and phase schedule. Keep `GrB_LOR_LAND_SEMIRING_BOOL`, `GrB_LOR`, matrix dimensions and baseline storage choices except where a recipe explicitly changes them. Count all setup, conversions, copies, merges and cleanup inside the query. No cross-query cache.
- No wide label packing (`V x kV` / `kV x V`), explicit Kronecker matrices, BLOCK wrapper or combined optimizations. D1, consistent block configuration storage, D3 and D4/D5 are preserved in `DEEPSEEK_REMAINDER.md`, with explicit implementation/readiness status; they are not discarded by this work order.
- DS-00/01 stay accepted. DS-20/21/22 are completed negative experiments: all 63 overnight rows matched; do not reopen or rerun them.

## Execution order after activation

1. Prepare **DS-36, DS-37, DS-38, DS-39 first**, in that order. They are included in this work order, not postponed to an unspecified later batch.
2. Prepare DS-30 through DS-35, in numerical order. Do not wait for overnight timing results to build these independent variants.
3. Hand over one sequential overnight script for all passing variants, with the inexpensive variants first within each source-count group. The user runs the long comparisons.
4. Future layout/batching work stays in `DEEPSEEK_REMAINDER.md`; do not implement it as an incidental change to this batch. No automatic promotion or combination after timing.

The existing implementation hold still applies. Once the user activates this work order, the four inexpensive variants require no additional design decision or separate activation.

## DS-36 — pattern products (`variants/ds36_pair.c`)

Copy baseline. Replace every `GrB_LOR_LAND_SEMIRING_BOOL` used in mxm/mxv by `GxB_ANY_PAIR_BOOL`, including shift, graph products, call construction, final-state extraction and final reachability. Keep all LOR accumulators/unions, reductions, masks, layouts, clears and helpers unchanged. True-only BOOL inputs make these products equivalent on the accepted contract. Do not introduce ANY accumulators or wrapper code.

Build/test: `prepare_one ds36_pair`. Benchmark: `bench_one ds36_pair 1`, `10`, `100`. Pass: common functional and seven-pair lab acceptance below.

## DS-37 — fused product accumulation (`variants/ds37_fused.c`)

Copy baseline. Replace only the body of `s_mul_acc` by:

```c
H_TRY(GrB_mxm(C, GrB_NULL, GrB_LOR, GrB_LOR_LAND_SEMIRING_BOOL,
              A, B, GrB_NULL));
return GrB_SUCCESS;
```

Keep its signature and the existing s_temp allocation/cleanup (T is unused here); this isolates the operation change. Retain iteration-boundary acc clear and every other operation. Do not add ANY_PAIR, empty checks, masks or format changes.

Build/test: `prepare_one ds37_fused`. Benchmark: `bench_one ds37_fused 1`, `10`, `100`. Pass: common acceptance. Compare separately with DS-32, which pays for a product-count query.

## DS-38 — remove one redundant clear (`variants/ds38_no_product_clear.c`)

Copy baseline. Delete only `H_TRY(GrB_Matrix_clear(T));` in `s_mul_acc`, immediately before its unmasked, no-accumulator overwrite mxm. Keep the mxm and union. Keep s_unshift clear, rowvec clear, acc clear, M_call clear and all other statements. No buffer rotation or fused accumulation.

Build/test: `prepare_one ds38_no_product_clear`. Benchmark: `bench_one ds38_no_product_clear 1`, `10`, `100`. Pass: common acceptance.

## DS-39 — direct flat-layout calls (`variants/ds39_direct_calls.c`)

Copy baseline. Keep M/P/M_call as Q x V² and retain the existing entry_vec reduction. Change only call construction:

1. At each iteration reset a reusable tuple-list length to zero and retain the existing M_call clear. After each box's entry_vec reduction, query/extract its true vertex indices into a reusable buffer. Append `(start_states[i], v*V+v, true)` for every extracted v.
2. Remove that box's diag_entry creation, reshape, call mxm and diag free. After the nonterminal loop, build M_call once from all accumulated tuples with `GrB_Matrix_build_BOOL(..., GrB_LOR)`. If no tuples, leave it empty. Duplicate call entries across boxes must union correctly.
3. Grow extraction and tuple buffers with LAGraph allocations; reuse their capacities across iterations and free them in error/normal cleanup. Remove now-unused diag_entry and rsm_start matrix construction/cleanup, while keeping existing input validation. No block layout, per-tuple GraphBLAS setElement loop or new call deduplication subsystem.
4. Keep summary skip products, W updates and return order unchanged. Include tuple extraction/build and setup costs in timing.

Build/test: `prepare_one ds39_direct_calls`. Benchmark: `bench_one ds39_direct_calls 1`, `10`, `100`. Pass: common acceptance.

## DS-30 — masked scalar insertion (`variants/ds30_assign.c`)

Change only the following three growing-state updates. Replace each self-union `C = C OR delta` by structural masked scalar true assignment; **no REPLACE, complement or accumulator**:

```c
/* Phase 2+3: replaces W[i] |= scratch */
GRB_TRY(GrB_Matrix_assign_BOOL(W[i], scratch, GrB_NULL, true,
                              GrB_ALL, Q * V, GrB_ALL, V, GrB_DESC_S));
/* Phase 4: replaces graph_nt[i] |= new_edges */
GRB_TRY(GrB_Matrix_assign_BOOL(graph_nt[i], new_edges, GrB_NULL, true,
                              GrB_ALL, V, GrB_ALL, V, GrB_DESC_S));
/* Phase 5: replaces P |= M_new */
GRB_TRY(GrB_Matrix_assign_BOOL(P, M_new, GrB_NULL, true,
                              GrB_ALL, Q, GrB_ALL, V * V, GrB_DESC_S));
```

Preserve every other union, subtraction, emptiness guard and operation order. Unmasked state entries must survive; duplicate W insertions are allowed. This is one experiment changing the insertion mechanism at all three sites, not three independently measured claims. SuiteSparse's `GB_subassign_05_template.c` has mask-driven scalar insertion, but later pending-tuple assembly can still cost time; include it.

Build/test: `prepare_one ds30_assign`. Benchmark: `bench_one ds30_assign 1`, then `10`, then `100` (functions below; user launches long runs). Pass: the common functional + seven-pair lab acceptance below. Faster timing is a separate outcome, not a correctness requirement.

## DS-31 — joint state/vertex terminal filtering (`variants/ds31_joint.c`)

Skip a terminal chain only if **no** frontier entry `M[q,u*V+v]` has both an outgoing `rsm_term[t]` transition from q and an outgoing `graph_term[t]` edge from v. Never merge labels or use independent global state/vertex activity as this predicate.

Implement this fixed sparse-index recipe:

1. Retain static `term_active`. For active labels only, extract RSM row indices and graph row indices once during setup. Build sorted, unique `(q,t)` and `(v,t)` pairs. Free temporary edge-sized extraction arrays after indexing.
2. Store RSM labels as sorted lists per q (Q+1 offsets). Store graph labels as sorted lists per **present** v: distinct vertex keys, offsets and label IDs; binary-search keys. No array of size V times number of labels, and no allocation by V squared. Use `LAGraph_Malloc/Realloc/Free`; add all new allocations to error cleanup.
3. Once per iteration, extract frontier row/column indices into reusable capacity-managed arrays. Values need not be extracted. For every tuple obtain q and `v = column % V`; intersect the two sorted label lists and mark each common t eligible. A label stays eligible for the remainder of this iteration. Duplicate `(q,v)` visits are allowed; do not add a new deduplication subsystem.
4. Replace the baseline rowvec/active/term_src prediction machinery by this eligibility computation; remove its unused vectors/arrays and allocations. Keep static graph/RSM emptiness checks. In Phase 1, run the unchanged shift/product/unshift chain exactly for eligible labels. Leave nonterminal phases untouched.
5. Index construction and per-iteration extraction are timed. No external preprocessing. In the feedback state these costs explicitly; an expensive index can make this variant lose even when many products are skipped.

Build/test: `prepare_one ds31_joint`. Benchmark: `bench_one ds31_joint 1`, `10`, `100`. Pass: common acceptance; in particular Java/avrora must match as well as all six other pairs. No instrumentation or counters in timing builds.

## DS-32 — empty product / first contribution (`variants/ds32_empty.c`)

Change `s_mul_acc` and its three kinds of call sites only (terminal, summary skip, return):

1. Pass `GrB_Matrix *C`, `GrB_Matrix *T`, and `bool *acc_empty`. Initialize the flag true when acc is created; reset true immediately after the existing Phase 5 clear of acc.
2. Keep the baseline clear of `*T` and overwrite mxm, unchanged semiring. Query product nvals once after mxm. If zero, return without union and without changing `acc_empty`.
3. On the first nonempty product, swap `*C` and `*T`, set `acc_empty=false`, return. Both are QV x V; no duplicate/copy/union is needed. The displaced acc is empty and becomes product scratch.
4. On subsequent nonempty products, execute the existing `C |= T` union. Do not query acc nvals, add fused mxm accumulation, change Phase 5, or remove any other clear.
5. All calls use `&acc`, `&s_temp`, `&acc_empty`. Existing cleanup frees the current handles once each. Product-count synchronization is part of measured cost.

Build/test: `prepare_one ds32_empty`. Benchmark: `bench_one ds32_empty 1`, `10`, `100`. Pass: common acceptance, including the existing empty-source case and recursive case.

## DS-33 — adaptive orientation / immutable cache (`variants/ds33_format.c`)

Apply only to terminal products `scratch * graph_term[t]`. Nonterminal products, W, summaries and all RSM shifts stay baseline. Do not repeat DS-20's permanent CSC W/dG policy.

1. Cache graph terminal nvals and native orientation during setup. Borrow the native operand read-only. Maintain one NULL-initialized private opposite-format handle per active label. Do not mutate or free caller handles. Free private caches at query cleanup.
2. At a terminal product, reuse the already queried scratch nvals as a. Let b be cached graph nvals. Desired format is `GxB_BY_ROW` if a < b; otherwise `GxB_BY_COL` (ties choose column).
3. Fixed adaptation of `matrix_mxm_format` with the graph treated as the cacheable first wrapper operand and `swap=true`: if the desired graph view is missing and **b <= a/3.0**, skip adaptation for this product and use the ordinary baseline helper. Otherwise build the missing private view once using `GrB_Matrix_dup` then `GrB_Matrix_set_INT32(view, desired, GxB_FORMAT)`. If desired is native, use the borrowed handle. Cache hits need no conversion guard.
4. For an adapted product set scratch and s_temp to desired format with `GrB_Matrix_set_INT32`; run baseline clear, mxm and union using the selected graph view. Acc keeps its baseline orientation; pay any mixed-format union cost. Restore scratch and s_temp to `GxB_BY_ROW` before the usual unshift/next baseline use. Do not force hypersparsity or tune thresholds.
5. Cache dimensions stay V x V. No dual cache for mutable matrices. Setup/cache conversion and restoration are timed, and process peak memory is reported. The fixed heuristic is an experiment, not an assumed improvement.

Build/test: `prepare_one ds33_format`. Benchmark: `bench_one ds33_format 1`, `10`, `100`. Pass: common acceptance. A slower result is still a completed experiment; do not redesign the heuristic in this pass.

## Lazy source audit and port decisions

Read references: `experimental/algorithm/LAGraph_CFL_optimized_matrix_opt.c` and `.h`. The RSM variants must not modify these files or import their whole abstraction.

| Area / source function | Actual behavior and cost | Decision for RSM |
| --- | --- | --- |
| Component ownership: `matrix_wise_lazy` (~1072) | Duplicates the addend, reallocates the list, repeatedly merges components within a factor of ten (sizes floored at ten), then sorts and updates metadata. Reused scratch is safe because it was copied; append is not zero-copy. | Retain independent ownership and bounded merging; use the fixed bins below. Copy a live frontier/reused summary delta once; no dangling aliases. |
| Bookkeeping: `matrix_sort_lazy`, `matrix_combine_lazy`, `CFL_matrix_update` (~495/560/590) | Pairwise O(k²) sorting recounts components; combine sorts and may merge during a read; outer and inner wrappers repeat updates. Lazy nvals is the **sum** of component nvals, not overlap-aware union cardinality. | Port cached dimensions/counts and write-time bins only. Exact summed counts are valid for our disjoint P/summary deltas. No repeated metadata scans, read-triggered compaction or generic flags. |
| Products: `matrix_mxm_lazy` (~808) | Dispatch expands only its first wrapper argument (swap preserves algebraic order); allocates all component products, then another accumulator, then copies/unions into output. | Stream in correct operand order with the RSM's existing one reusable product scratch. No product list or intermediate whole-result matrix. Keep baseline operators and helper so lazy measurements do not silently include ANY_PAIR or fused accumulation. |
| Subtraction: `matrix_rsub_lazy` (~1253) | May compact the mask, orders by size, applies one complemented structural mask per component; the outer loop continues after the candidate empties. | Apply recent components first, check candidate nvals after each application and stop at zero. Do not copy/merge masks during a read. No support-skipping index in this batch. |
| Materialization: `CFL_matrix_to_base` (~514) | Clones the component collection and its matrices before unioning them into an owned result. | Drop this cloning path. Neither selected lazy variant needs a full matrix at query end: P is never materialized; summaries feed final mxv component by component. If a future consumer needs a matrix, union read-only original components into one owned destination, never into the components. Do not implement unused materialization code now. |

Worth porting now as **two separate storage experiments**: lazy P and lazy graph_nt. Do not port lazy W: W deltas can overlap, and adding scratch-minus-W is the already measured DS-21 extra work. Do not port lazy acc now: contributions overlap, sum-nvals would be wrong, and plain fused accumulation is a smaller first comparison. Do not port BLOCK, dual mutable caches, wrapper-wide recounts or size-dependent read-side merging.

### Fixed component helper used locally in DS-34 and DS-35

Copy this same helper design into each source; do not invent policies:

- A bag contains owned `GrB_Matrix` handles, cached component nnz, cached total nnz, and a fixed live-record array of capacity `8*sizeof(GrB_Index)+1`. Dimensions are fixed on bag creation. Empty bag has count/total zero; no dummy matrix.
- Rank of a nonempty component is floor(log2(nnz)), computed with an integer loop. Append takes ownership of a local carry. If an existing component has the same rank, union it into carry using baseline `GrB_LOR`, free/remove that component, add cached counts and repeat with the new rank. Append the resulting carry at the end. At most one component per rank remains. No sorting, adaptive thresholds or recount of unchanged components.
- Components appended to these bags are disjoint from prior contents. Merges preserve disjointness, so sum counts are exact. Rank/count arithmetic uses `GrB_Index`; append updates total by the original delta count only. Keep carry owned by cleanup until successfully published; cleanup frees every live handle once.
- A subtraction helper takes a mutable ordinary candidate and its known nnz. Visit records in reverse live-array order (most recently appended/merged first); use `GrB_apply(candidate, component, NULL, GrB_IDENTITY_BOOL, candidate, GrB_DESC_RSC)`. Refresh **candidate** nvals after each mask; stop at zero. Never update immutable component counts on a read.
- No instrumentation in timing builds. No new random/large test suites. Existing smoke and all-lab comparison exercise append, masks and recursion sufficiently for this review.

### DS-34 — lazy visited state (`variants/ds34_lazy_p.c`)

1. Replace ordinary P storage by one component bag of Q x V² matrices. Seed it with a duplicate of nonempty initial M and its already known nnz. Keep M independently owned.
2. Phase 5: retain reshapeDup and acc clear. Form `M_new = M_new OR M_call` with **no mask**, then subtract every P component using the helper. The baseline combined complemented P mask becomes this sequence.
3. If the resulting frontier is nonempty, duplicate M_new once and append that owned delta. M_new remains the next M, so do not transfer its live handle. Remove ordinary P union/dup/free. Reuse the final candidate nnz for loop termination.
4. Keep graph_nt and W ordinary, and all products/calls unchanged. Never materialize P. Report this experiment's frontier duplication and multiple mask passes as real costs.

Build/test: `prepare_one ds34_lazy_p`. Benchmark: `bench_one ds34_lazy_p 1`, `10`, `100`. Pass: common acceptance. Do not add waiting-state deduplication.

### DS-35 — lazy summary relations (`variants/ds35_lazy_nt.c`)

1. Replace each graph_nt[i] by an initially empty V x V bag. Keep P and W ordinary. Replace graph_nt emptiness queries by cached total != 0.
2. Phase 2+3: compute the skip product as `scratch * component` for each live summary component, calling unchanged `s_mul_acc(acc, scratch, component, s_temp)` sequentially. This is streaming through one reusable scratch and unions possibly overlapping product outputs. Never reverse the algebraic operands or keep all products.
3. Phase 4: after the baseline reshape of new_edges to V x V, subtract the bag with the helper. If empty, restore its 1 x V² shape and continue as baseline. If nonempty, duplicate the delta once into an owned handle and append to that box's bag **where the old summary union occurred**. Keep the original new_edges for the unchanged W[i]*new_edges product and later reshape. This preserves same-iteration return ordering and disjoint summary deltas.
4. Final reachability: allocate the usual zero output vector. For each start-summary component call `GrB_mxv(*reachable, NULL, GrB_LOR, GrB_LOR_LAND_SEMIRING_BOOL, component, source_mask, GrB_DESC_T0)`. An empty bag leaves the result empty. Do not materialize a summary, copy components, or allocate one result per component.
5. Cleanup all bags/carries; remove ordinary graph_nt matrix allocation/free. No new full materialization helper, lazy W or lazy acc.

Build/test: `prepare_one ds35_lazy_nt`. Benchmark: `bench_one ds35_lazy_nt 1`, `10`, `100`. Pass: common acceptance. Expect possible product fan-out overhead; report a loss without redesign.

## Exact build, functional and lab-smoke commands (after activation)

Run from Bash. These functions apply to each named experiment; no default Makefile `check`, random suite or sanitizer target. `make -B` prevents accidentally reusing the shared test binary from another variant. Use a fresh evidence directory; do not pass `--force`.

```bash
cd /home/hollow/repo/LAGraph
LAB=$PWD/experimental/algorithm/cfpq_rsm_lab
EVIDENCE=$(mktemp -d "$LAB/build/r9-checks-XXXXXXXX")
set -uo pipefail
printf 'variant\tstep\texit_code\n' > "$EVIDENCE/status.tsv"
prepare_one() {
    local name=$1 rc
    if make -B -C "$LAB/tests" R2="$LAB/variants/$name.c" \
        candidate_correctness_r2 >"$EVIDENCE/$name.build.log" 2>&1; then rc=0; else rc=$?; fi
    printf '%s\tbuild\t%s\n' "$name" "$rc" >> "$EVIDENCE/status.tsv"
    ((rc == 0)) || return "$rc"
    if env -u OMP_NUM_THREADS -u OMP_THREAD_LIMIT \
        "$LAB/build/tests/candidate_correctness_r2" --smoke \
        >"$EVIDENCE/$name.functional.log" 2>&1; then rc=0; else rc=$?; fi
    printf '%s\tfunctional\t%s\n' "$name" "$rc" >> "$EVIDENCE/status.tsv"
    ((rc == 0)) || return "$rc"
    if python3 "$LAB/run.py" --baseline "$LAB/variants/baseline.c" \
        --config "$LAB/configs/lab.csv" --variants "baseline,baseline,$name" \
        --source-size 1 --chunks 1 --rounds 1 --hot-rounds 0 \
        --seed 2026 --threads 0 --out "$EVIDENCE/$name" \
        >"$EVIDENCE/$name.lab.log" 2>&1; then rc=0; else rc=$?; fi
    printf '%s\tlab\t%s\n' "$name" "$rc" >> "$EVIDENCE/status.tsv"
    return "$rc"
}
for name in ds36_pair ds37_fused ds38_no_product_clear ds39_direct_calls ds30_assign ds31_joint ds32_empty ds33_format ds34_lazy_p ds35_lazy_nt; do
    prepare_one "$name" || continue
done
```

The runner builds uninstrumented shared libraries as part of each lab smoke. **Pass per variant:** build exit 0; `--smoke` exit 0 (existing trivial terminal, empty-source and recursion checks); lab runner exit 0; all seven graph/grammar pairs present with `status=ok`, `count_ok=1`, `hash_ok=1` for both baseline copies and candidate. One-round smoke timings are not speedup evidence. A failed/missing workload is not a pass. Continue other variants if one fails.

One review pass; at most one repair/follow-up for an observed failure. No formal proofs, fuzzing, large/randomized suites, allocation injection, sanitizer sweeps or extra seeds. Accept a matching variant; do not block on hypothetical concerns. Faster/slower/inconclusive is decided separately from correctness.

## Exact timing commands and user handoff

Create `run_r9_overnight.sh` by copying the existing `run_overnight.sh`. Keep its sequential failure-continuing execution, command/log/status retention, fresh output directory rejection and exit behavior. Make only these functional replacements:

- `VARIANTS=(ds36_pair ds37_fused ds38_no_product_clear ds39_direct_calls ds30_assign ds31_joint ds32_empty ds33_format ds34_lazy_p ds35_lazy_nt)`.
- Use `summarize_r9_overnight.py`; change default directory prefix from `overnight-` to `r9-overnight-`.
- Replace hardcoded nine-comparison counts/messages with `total=$(( ${#SOURCES[@]} * ${#VARIANTS[@]} ))` (30); update help/comments to the ten names.
- Do not include failed smoke variants silently: before handoff list their names in feedback; if any remains failed, remove that name from **both** scripts' variant lists and explicitly report the omission. Keep passing experiments independent.

Create `summarize_r9_overnight.py` by copying `summarize_overnight.py`; change only its VARIANTS tuple to the same ten names and update descriptive counts (210 workload/source rows). Preserve correctness checks, duplicate-baseline noise, time ratios, process memory scope and FAIL/NOT_RUN handling. If variants are omitted, adjust counts accordingly. Do not change run.py acceptance or profiling generator.

The underlying benchmark command for every experiment/source count is exactly:

```bash
# User-run timing only; LAB as above, a fresh OUT chosen by the script.
bench_one() {
    local name=$1 sources=$2
    python3 "$LAB/run.py" --baseline "$LAB/variants/baseline.c" \
      --config "$LAB/configs/lab.csv" --variants "baseline,baseline,$name" \
      --source-size "$sources" --chunks 30 --rounds 5 --hot-rounds 1 \
      --seed 2026 --threads 0 --out "$OUT/$name/s$sources"
}
# The script runs sources 1, 10, 100, with each passing variant sequentially.
# User launches the retained-command/status/log wrapper:
bash "$LAB/run_r9_overnight.sh" --dry-run
bash "$LAB/run_r9_overnight.sh"
```

DeepSeek runs only the dry run and checks its 30 commands after smoke preparation; **the user launches the real overnight command**. Do not use `bench_one` manually during preparation. Retain source hashes, CSVs, logs, exact commands, exit statuses and morning Markdown/CSV. Morning MATCH requires all seven workloads, all 30 chunks x 5 rounds, matching counts/hashes and zero exit status, separately for each source size. Memory is process peak, not isolated kernel memory. Compare ratios against duplicate-baseline spread; a noisy tie is inconclusive. Do not combine variants based on a few winning rows.

No profiling during timings. The current `make_profile_variant.py` uses exact baseline source anchors; it is **not** a general profiler for these edited variants. Do not pass a changed variant as `--baseline --profile` and assume it works. If a later observed regression needs attribution, request a separate targeted profiling work order; no profiling work is required for this handoff.

## Previously discussed inexpensive changes: history and scheduled tasks

Historical evidence: the feedback queue leaves DS-10 queued and recommends these ablations; R5 implemented only DS-20/21/22. There is no retained report showing that any of the following was built, failed or benchmarked. The common actual blocker was **selection/scheduling**, followed by the explicit research hold—not a measured technical rejection. Specific constraints and dispositions:

| Change | Actual constraint / current decision |
| --- | --- |
| ANY_PAIR | Originally tied to stored-false/pattern semantics (Q-001). The accepted true-only BOOL contract resolves that for these workloads. No current correctness blocker. **Implement first as DS-36 when this work order starts**: replace mxm/mxv semirings only with `GxB_ANY_PAIR_BOOL`; retain LOR accumulators and all other edits unchanged. Never smuggle it into a lazy/format variant. |
| Fused accumulation | No observed blocker; simply never selected. **Implement second as DS-37**: replace s_mul_acc's clear/product/union by `GrB_mxm(C, NULL, GrB_LOR, GrB_LOR_LAND_SEMIRING_BOOL, A, B, NULL)`. Acc must still clear at the iteration boundary. This is the simpler control to compare with DS-32; no claim yet that either wins. |
| Redundant-clear removal | A blanket removal is invalid as an optimization recipe: s_unshift clears before a shape change, while acc/M_call clears reset live state. **Implement third as DS-38, only the safe small ablation**: remove the product-temporary clear immediately before unmasked, no-accumulator overwrite mxm in s_mul_acc. Retain all other clears. No observed failure prevented this limited edit. |
| Buffer reuse | scratch and s_temp already reuse handles; generic “reuse buffers” has no additional defined edit. Frontier Phase 5 still copies data via reshapeDup; merely rotating handles does not eliminate that copy, and reshaping a populated dead frontier can add work. **Drop the generic standalone task from this batch**. A specific frontier-transfer/layout recipe remains parked; no measured failure is claimed. |
| Direct call insertion | No current semantic blocker; the earlier block-shaped formulation depended on a layout candidate that stayed parked. Baseline flat layout also permits entries `M_call[start_states[i], v*V+v]=true` from entry_vec. **Implement fourth as DS-39**: accumulate call tuples for all boxes and build M_call once per iteration with LOR duplicate handling, replacing diag/reshape/rsm_start mxm. Keep baseline flat layout; include extraction/build costs. |

The four implementable inexpensive changes are now explicit tasks at the front of this same work order. They must be prepared before DS-30–35 after activation. Generic buffer reuse remains deferred to the concrete layout recipes in `DEEPSEEK_REMAINDER.md`. Do not silently combine variants or claim historical blockers not recorded in the reports.

## Deliverable / stop

After activation and preparation, append one short report per variant: exact edits/hash, build and smoke commands/status/log paths, seven-pair count/hash outcome, any observed failure/fix, and the overnight launch command. For an omission, identify the failing command. Leave speed/memory fields `not measured` until the user supplies overnight artifacts. Stop after smoke checks and script handoff. This R9 edit itself leaves implementation on hold.
