#include "adapter_CFL_adv.h"
#include "computed_cache.h"
#include "memory.h"
#include "parser.h"
#include "registry.h"
#include "result_manager.h"
#include <GraphBLAS.h>
#include <LAGraph.h>
#include <LAGraphX.h>
#include <errno.h>
#include <getopt.h>
#include <limits.h>
#include <malloc.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define run_algorithm()                                                                                                \
    LAGraph_CFL_reachability_adv(outputs, adj_matrices, symbols_amount, grammar.rules, grammar.rules_count, msg,       \
                                 optimizations)

#define check_error(error)                                                                                             \
    {                                                                                                                  \
        retval = run_algorithm();                                                                                      \
        TEST_CHECK(retval == error);                                                                                   \
        TEST_MSG("retval = %d (%s)", retval, msg);                                                                     \
    }

#define check_result(result)                                                                                           \
    {                                                                                                                  \
        char *expected = output_to_str(0);                                                                             \
        TEST_CHECK(strcmp(result, expected) == 0);                                                                     \
        TEST_MSG("Wrong result. Actual: %s", expected);                                                                \
    }

#define TRY(GrB_method)                                                                                                \
    {                                                                                                                  \
        GrB_Info LG_GrB_Info = GrB_method;                                                                             \
        if (LG_GrB_Info < GrB_SUCCESS) {                                                                               \
            fprintf(stderr, "LAGraph failure (file %s, line %d): (%d) \n", __FILE__, __LINE__, LG_GrB_Info);           \
            return (LG_GrB_Info);                                                                                      \
        }                                                                                                              \
    }

GrB_Matrix *adj_matrices = NULL;
GrB_Matrix *outputs = NULL;
grammar_t grammar = {0, 0, NULL};
char msg[LAGRAPH_MSG_LEN];
size_t symbols_amount = 0;

void print_rules(Grammar grammar, SymbolList list) {
    for (size_t i = 0; i < grammar.rules_count; i++) {
        Rule rule = grammar.rules[i];
        if (rule.first != -1) {
            printf("%s ->", list.symbols[rule.first].label);
        }
        if (rule.second != -1) {
            printf(" %s", list.symbols[rule.second].label);
        }
        if (rule.third != -1) {
            printf(" %s", list.symbols[rule.third].label);
        }
        printf("\n");
    }
}

void print_list(SymbolList list, size_t *map) {
    if (map == NULL) {
        for (size_t i = 0; i < list.count; i++) {
            Symbol sym = list.symbols[i];
            printf("[%2ld] %s [%s] %s\n", i, sym.label, sym.is_nonterm ? "N" : "T", sym.is_indexed ? "[I]" : "");
        }
    } else {
        for (size_t i = 0; i < list.count; i++) {
            Symbol sym = list.symbols[i];
            printf("[%2ld] %s [%s] %s\n", map[i], sym.label, sym.is_nonterm ? "N" : "T", sym.is_indexed ? "[I]" : "");
        }
    }
}

#define RESET "\033[0m"
#define BLACK "\033[30m"
#define RED "\033[31m"
#define GREEN "\033[32m"
#define YELLOW "\033[33m"
#define BLUE "\033[34m"
#define MAGENTA "\033[35m"
#define CYAN "\033[36m"
#define WHITE "\033[37m"

// Use your custom configuration for the benchmark (default is the xz.g graph
// and vf.cnf grammar)
#define configs_macro configs_java

#define OPT_EMPTY (1 << 0)
#define OPT_FORMAT (1 << 1)
#define OPT_LAZY (1 << 2)
#define OPT_BLOCK (1 << 3)

enum {
    HOT_OPTION = 1000,
    BENCH_PARSE_OPTION = 1001,
    CFL_ALL_PATH_USE_CFPQ = 1002,
    USE_START_NODES_OPTION = 1003,
    COMPUTE_RESULTS_OPTION = 1004,
    USE_RANDOM_PERCENT_OPTION = 1005,
    EXPERIMENT_OPTION = 1006,
    SOURCE_SIZES_OPTION = 1007,
    CHUNKS_OPTION = 1008,
    SEED_OPTION = 1009,
    RESULTS_FILE_OPTION = 1010,
    RSM_LIB_OPTION = 1011
};

// the random start vertices are the same for every run
#define RANDOM_START_NODES_SEED 2026
#define DEFAULT_EXPERIMENT_SEED RANDOM_START_NODES_SEED
#define DEFAULT_CHUNKS_COUNT 30

static void print_usage(const char *program_name) {
    fprintf(stderr,
            "Usage: %s -c <config file> [options]\n"
            "\n"
            "Required:\n"
            "  -c <config file>  Path to benchmark config file\n"
            "\n"
            "Benchmark options:\n"
            "  -r <rounds>       Number of benchmark rounds (default: 10)\n"
            "  --hot             Enable HOT launch (warm-up run before measurements)\n"
            "  --bench-parse     Print grammar and graph parsing times only\n"
            "  --use-start-nodes Use start vertices from the path specified in the config\n"
            "  --use-random-percent <n>\n"
            "                    Use a random n%% of the vertices as start vertices, the same\n"
            "                    ones for every run\n"
            "  --experiment      Measure a multiple-source algorithm on source chunks from the\n"
            "                    start vertices file (implies --use-start-nodes)\n"
            "  --source-sizes <list>\n"
            "                    Comma-separated source set sizes (default: 1,10,100)\n"
            "  --chunks <n>      Number of source chunks per size (default: 30)\n"
            "  --seed <n>        Seed for shuffling source vertices (default: 2026)\n"
            "  --results-file <path>\n"
            "                    Write results to this CSV file instead of results/results_<time>.csv\n"
            "  --rsm-lib <path>  Load LAGraph_CFPQ_RSM from this shared library instead of\n"
            "                    liblagraphx (CFL_CFPQ_RSM only)\n"
            "  -a <algorithm>    Algorithm to use (default: " DEFAULT_ALGORITHM "; options: ",
            program_name);
    registry_print_names(stderr);
    fprintf(stderr,
            ")\n"
            "\n"
            "Optimization flags:\n"
            "  -e                Enable empty optimization\n"
            "  -f                Enable format optimization\n"
            "  -l                Enable lazy optimization\n"
            "  -b                Enable block optimization\n"
            "\n"
            "Other:\n"
            "  -t                Enable test mode: run each config once and check the result\n"
            "                    (-r and --hot are ignored)\n"
            "  --compute-results Check the result against CFL_adv -efbl on the same data instead of\n"
            "                    the config value (only with -t); CFL_multsrc, CFL_multsrc_adv and\n"
            "                    CFL_CFPQ_RSM need it, values are cached in .cache when run from the\n"
            "                    project root\n"
            "  -h                Print this help message\n"
            "  --CFL-all-path-use-CFPQ-Core      Use CFPQ_Core in CFL_all_path algorithm\n"
            "\n"
            "Example:\n"
            "  %s -c configs/configs_my.csv -r 10 --hot\n",
            program_name);
}

// replaces the start vertices with a random percent of all vertices
static void choose_random_start_nodes(ParserResult *parser_result, size_t percent) {
    size_t node_count = parser_result->graph.node_count;
    size_t count = node_count * percent / 100;
    if (count == 0 && node_count > 0) {
        count = 1;
    }

    GrB_Index *nodes = malloc(node_count * sizeof(*nodes));
    if (nodes == NULL) {
        fprintf(stderr, "Failed to allocate memory for start vertices\n");
        exit(EXIT_FAILURE);
    }
    for (size_t i = 0; i < node_count; i++) {
        nodes[i] = i;
    }

    // the first "count" vertices of a partial Fisher-Yates shuffle
    unsigned int seed = RANDOM_START_NODES_SEED;
    for (size_t i = 0; i < count; i++) {
        size_t j = i + (size_t)rand_r(&seed) % (node_count - i);
        GrB_Index swap = nodes[i];
        nodes[i] = nodes[j];
        nodes[j] = swap;
    }

    free(parser_result->start_nodes);
    parser_result->start_nodes = nodes;
    parser_result->start_nodes_count = count;
}

static void shuffle_start_nodes(GrB_Index *nodes, size_t count, unsigned int seed) {
    // Fisher-Yates shuffle, so the same seed and the same candidate file give
    // the same chunks for every algorithm
    for (size_t i = count; i > 1; i--) {
        size_t j = (size_t)rand_r(&seed) % i;
        GrB_Index swap = nodes[i - 1];
        nodes[i - 1] = nodes[j];
        nodes[j] = swap;
    }
}

// parses a comma-separated list of positive source set sizes
static size_t *parse_source_sizes(const char *arg, size_t *out_count) {
    char *copy = strdup(arg);
    if (copy == NULL) {
        fprintf(stderr, "Failed to allocate memory for source sizes\n");
        exit(EXIT_FAILURE);
    }

    size_t *sizes = NULL;
    size_t count = 0;
    size_t capacity = 0;
    char *saveptr = NULL;

    for (char *token = strtok_r(copy, ",", &saveptr); token != NULL; token = strtok_r(NULL, ",", &saveptr)) {
        char *start = token;
        while (*start == ' ' || *start == '\t') {
            start++;
        }

        errno = 0;
        char *end = NULL;
        unsigned long value = strtoul(start, &end, 10);

        while (end != NULL && (*end == ' ' || *end == '\t')) {
            end++;
        }

        if (*start < '0' || *start > '9' || errno != 0 || end == start || *end != '\0' || value == 0 ||
            value > SIZE_MAX) {
            fprintf(stderr, "Invalid source size: %s\n", token);
            exit(EXIT_FAILURE);
        }

        for (size_t i = 0; i < count; i++) {
            if (sizes[i] == (size_t)value) {
                fprintf(stderr, "Duplicate source size: %lu\n", value);
                exit(EXIT_FAILURE);
            }
        }

        if (count == capacity) {
            capacity = capacity == 0 ? 4 : capacity * 2;
            sizes = realloc(sizes, capacity * sizeof(*sizes));
            if (sizes == NULL) {
                fprintf(stderr, "Failed to allocate memory for source sizes\n");
                exit(EXIT_FAILURE);
            }
        }
        sizes[count++] = (size_t)value;
    }

    free(copy);

    if (count == 0) {
        fprintf(stderr, "Source sizes must not be empty\n");
        exit(EXIT_FAILURE);
    }

    *out_count = count;
    return sizes;
}

// Runs a multiple-source algorithm on shuffled source chunks. The candidate
// pool is parser_result->start_nodes, loaded from the config's fourth column.
// For every chunk the adapter is prepared from scratch, then one warm-up run
// and rounds_count measured runs are performed.
static int run_experiment_config(const config_row *config, const AlgorithmEntry *algo, AdapterMethods *adapter,
                                 const AlgorithmOptions *algo_options, ParserResult *parser_result, size_t rounds_count,
                                 bool is_hot_enabled, const size_t *source_sizes, size_t source_sizes_count,
                                 size_t chunks_count, unsigned int seed) {
    if (parser_result->start_nodes == NULL || parser_result->start_nodes_count == 0) {
        fprintf(stderr, "Experiment mode requires a non-empty start vertices file (config row: %s)\n",
                config->start_nodes_path == NULL ? "<none>" : config->start_nodes_path);
        return EXIT_FAILURE;
    }

    GrB_Index *pool = parser_result->start_nodes;
    size_t pool_count = parser_result->start_nodes_count;
    shuffle_start_nodes(pool, pool_count, seed);

    size_t max_source_size = 0;
    for (size_t i = 0; i < source_sizes_count; i++) {
        if (source_sizes[i] > max_source_size) {
            max_source_size = source_sizes[i];
        }
    }

    GrB_Index *chunk_nodes = malloc(max_source_size * sizeof(*chunk_nodes));
    if (chunk_nodes == NULL) {
        fprintf(stderr, "Failed to allocate memory for source chunk\n");
        return EXIT_FAILURE;
    }

    for (size_t size_index = 0; size_index < source_sizes_count; size_index++) {
        size_t source_size = source_sizes[size_index];

        for (size_t chunk = 0; chunk < chunks_count; chunk++) {
            size_t offset = chunk * source_size;
            for (size_t i = 0; i < source_size; i++) {
                // cycle through the shuffled pool when it is smaller than
                // chunks_count * source_size; this keeps exactly 30 chunks
                chunk_nodes[i] = pool[(offset + i) % pool_count];
            }

            parser_result->start_nodes = chunk_nodes;
            parser_result->start_nodes_count = source_size;
            GrB_Info info = algo->prepare(adapter, parser_result, algo_options);
            parser_result->start_nodes = pool;
            parser_result->start_nodes_count = pool_count;

            if (info != GrB_SUCCESS) {
                fprintf(stderr, "LAGraph failure while preparing |S|=%zu chunk=%zu: %d\n", source_size, chunk, info);
                free(chunk_nodes);
                return EXIT_FAILURE;
            }

            bool is_hot = is_hot_enabled;
            size_t measured = 0;
            double sum = 0.0;

            while (measured < rounds_count) {
                info = adapter->init_outputs();
                if (info != GrB_SUCCESS) {
                    fprintf(stderr, "LAGraph failure in init_outputs for |S|=%zu chunk=%zu: %d\n", source_size, chunk,
                            info);
                    adapter->cleanup();
                    free(chunk_nodes);
                    return EXIT_FAILURE;
                }

                // in some cases free don't change memory usage, so we need to reset it manually
                malloc_trim(0);
                if (mem_peak_reset() != 0) {
                    fprintf(stderr, "Failed to reset memory peak\n");
                    adapter->free_outputs();
                    adapter->cleanup();
                    free(chunk_nodes);
                    return EXIT_FAILURE;
                }

                double start_time = LAGraph_WallClockTime();
                info = adapter->run();
                double end_time = LAGraph_WallClockTime();
                ssize_t max_memory_kb = mem_get_peak_kb();

                if (info != GrB_SUCCESS) {
                    fprintf(stderr, "LAGraph failure in run for |S|=%zu chunk=%zu: %d\n", source_size, chunk, info);
                    adapter->free_outputs();
                    adapter->cleanup();
                    free(chunk_nodes);
                    return EXIT_FAILURE;
                }

                if (is_hot) {
                    is_hot = false;
                    info = adapter->free_outputs();
                    if (info != GrB_SUCCESS) {
                        fprintf(stderr, "LAGraph failure in free_outputs for |S|=%zu chunk=%zu: %d\n", source_size,
                                chunk, info);
                        adapter->cleanup();
                        free(chunk_nodes);
                        return EXIT_FAILURE;
                    }
                    continue;
                }

                size_t result = adapter->get_result();
                uint64_t result_hash = adapter->get_result_hash != NULL ? adapter->get_result_hash() : 0;
                info = adapter->free_outputs();
                if (info != GrB_SUCCESS) {
                    fprintf(stderr, "LAGraph failure in free_outputs for |S|=%zu chunk=%zu: %d\n", source_size, chunk,
                            info);
                    adapter->cleanup();
                    free(chunk_nodes);
                    return EXIT_FAILURE;
                }

                double elapsed = end_time - start_time;
                sum += elapsed;
                measured++;

                save_result(algo->name, config->grammar, config->graph, source_size, chunk, result, result_hash,
                            max_memory_kb, elapsed);
                malloc_trim(0);
            }

            info = adapter->cleanup();
            if (info != GrB_SUCCESS) {
                fprintf(stderr, "LAGraph failure in cleanup for |S|=%zu chunk=%zu: %d\n", source_size, chunk, info);
                free(chunk_nodes);
                return EXIT_FAILURE;
            }

            printf("\t|S|=%zu chunk=%zu/%zu: %.6f s (avg of %zu runs)\n", source_size, chunk + 1, chunks_count,
                   sum / (double)measured, measured);
            fflush(stdout);
        }
    }

    free(chunk_nodes);
    return EXIT_SUCCESS;
}

// runs CFL_adv with all optimizations on the same data and returns the result "algo" must have
static GrB_Info compute_expected_result(const ParserResult *parser_result, const AlgorithmEntry *algo,
                                        bool use_start_nodes, size_t *expected) {
    AdapterMethods reference = adapter_CFL_adv_get_methods();
    TRY(reference.prepare(parser_result,
                          &(CFL_adv_PrepareData){.optimizations = OPT_EMPTY | OPT_FORMAT | OPT_LAZY | OPT_BLOCK}));
    TRY(reference.init_outputs());
    TRY(reference.run());

    if (algo->is_multiple_source) {
        if (!use_start_nodes) {
            TRY(adapter_CFL_adv_count_reachable(NULL, 0, expected));
        } else if (parser_result->start_nodes_count == 0) {
            *expected = 0;
        } else {
            TRY(adapter_CFL_adv_count_reachable(parser_result->start_nodes, parser_result->start_nodes_count,
                                                expected));
        }
    } else {
        *expected = reference.get_result();
    }

    TRY(reference.free_outputs());
    TRY(reference.cleanup());
    return GrB_SUCCESS;
}

int main(int argc, char **argv) {
    GrB_Info retval = GrB_SUCCESS;
    int8_t optimizations = 0;
    int opt;
    bool is_test = false;
    bool has_test_failure = false;
    bool is_hot_enabled = false;
    bool is_bench_parse_enabled = false;
    bool use_start_nodes = false;
    size_t random_percent = 0; // 0 when --use-random-percent is not given
    bool compute_results = false;
    bool is_config = false;
    const AlgorithmEntry *algo = NULL;
    char *input_config = NULL;
    size_t rounds_count = 10;
    bool use_cfpq = false;
    bool experiment = false;
    size_t default_source_sizes[] = {1, 10, 100};
    size_t *source_sizes = default_source_sizes;
    size_t source_sizes_count = sizeof(default_source_sizes) / sizeof(default_source_sizes[0]);
    bool source_sizes_allocated = false;
    bool source_sizes_given = false;
    bool chunks_given = false;
    bool seed_given = false;
    size_t chunks_count = DEFAULT_CHUNKS_COUNT;
    unsigned int experiment_seed = DEFAULT_EXPERIMENT_SEED;
    char *results_file = NULL;
    char *rsm_lib = NULL;

    AdapterMethods adapter = {0};

    static struct option long_options[] = {
        {"hot", no_argument, 0, HOT_OPTION},
        {"bench-parse", no_argument, 0, BENCH_PARSE_OPTION},
        {"use-start-nodes", no_argument, 0, USE_START_NODES_OPTION},
        {"CFL-all-path-use-CFPQ-Core", no_argument, 0, CFL_ALL_PATH_USE_CFPQ},
        {"compute-results", no_argument, 0, COMPUTE_RESULTS_OPTION},
        {"use-random-percent", required_argument, 0, USE_RANDOM_PERCENT_OPTION},
        {"experiment", no_argument, 0, EXPERIMENT_OPTION},
        {"source-sizes", required_argument, 0, SOURCE_SIZES_OPTION},
        {"chunks", required_argument, 0, CHUNKS_OPTION},
        {"seed", required_argument, 0, SEED_OPTION},
        {"results-file", required_argument, 0, RESULTS_FILE_OPTION},
        {"rsm-lib", required_argument, 0, RSM_LIB_OPTION},
        {0, 0, 0, 0},
    };

    while ((opt = getopt_long(argc, argv, "eflbthr:c:a:", long_options, NULL)) != -1) {
        switch (opt) {
        case 'e':
            optimizations |= OPT_EMPTY;
            break;
        case 'f':
            optimizations |= OPT_FORMAT;
            break;
        case 'l':
            optimizations |= OPT_LAZY;
            break;
        case 'b':
            optimizations |= OPT_BLOCK;
            break;
        case 'h':
            print_usage(argv[0]);
            exit(EXIT_SUCCESS);
        case HOT_OPTION:
            is_hot_enabled = true;
            break;
        case BENCH_PARSE_OPTION:
            is_bench_parse_enabled = true;
            break;
        case USE_START_NODES_OPTION:
            use_start_nodes = true;
            break;
        case COMPUTE_RESULTS_OPTION:
            compute_results = true;
            break;
        case USE_RANDOM_PERCENT_OPTION:
            random_percent = strtoul(optarg, NULL, 10);
            if (random_percent == 0 || random_percent > 100) {
                fprintf(stderr, "--use-random-percent takes a number from 1 to 100\n");
                exit(EXIT_FAILURE);
            }
            break;
        case EXPERIMENT_OPTION:
            experiment = true;
            break;
        case SOURCE_SIZES_OPTION:
            if (source_sizes_allocated) {
                free(source_sizes);
            }
            source_sizes = parse_source_sizes(optarg, &source_sizes_count);
            source_sizes_allocated = true;
            source_sizes_given = true;
            break;
        case CHUNKS_OPTION: {
            errno = 0;
            char *end = NULL;
            unsigned long value = strtoul(optarg, &end, 10);
            bool is_digit = optarg[0] >= '0' && optarg[0] <= '9';
            if (!is_digit || errno != 0 || end == optarg || *end != '\0' || value == 0 || value > SIZE_MAX) {
                fprintf(stderr, "--chunks takes a positive integer\n");
                exit(EXIT_FAILURE);
            }
            chunks_count = (size_t)value;
            chunks_given = true;
            break;
        }
        case SEED_OPTION: {
            errno = 0;
            char *end = NULL;
            unsigned long value = strtoul(optarg, &end, 10);
            bool is_digit = optarg[0] >= '0' && optarg[0] <= '9';
            if (!is_digit || errno != 0 || end == optarg || *end != '\0' || value > UINT_MAX) {
                fprintf(stderr, "--seed takes an unsigned integer\n");
                exit(EXIT_FAILURE);
            }
            experiment_seed = (unsigned int)value;
            seed_given = true;
            break;
        }
        case RESULTS_FILE_OPTION:
            results_file = optarg;
            break;
        case RSM_LIB_OPTION:
            rsm_lib = optarg;
            break;
        case 't':
            is_test = true;
            break;
        case 'r':
            rounds_count = strtoul(optarg, NULL, 10);
            if (rounds_count == 0) {
                fprintf(stderr, "Rounds count must be greater than 0\n");
                exit(EXIT_FAILURE);
            }
            printf("Choosen rounds count: %zu\n", rounds_count);
            break;
        case 'c':
            is_config = true;
            input_config = optarg;
            printf("Choosen config: %s\n", input_config);
            break;
        case 'a':
            printf("Choosen algorithm: %s\n", optarg);

            algo = registry_find(optarg);
            if (algo == NULL) {
                fprintf(stderr, "Unknown algorithm: %s\n", optarg);
                exit(EXIT_FAILURE);
            }
            adapter = algo->get_methods();
            break;
        case CFL_ALL_PATH_USE_CFPQ:
            use_cfpq = true;
            break;
        default:
            print_usage(argv[0]);
            exit(EXIT_FAILURE);
        }
    }

    if (compute_results && !is_test) {
        fprintf(stderr, "--compute-results works only with -t\n");
        exit(EXIT_FAILURE);
    }

    if (!experiment && (source_sizes_given || chunks_given || seed_given)) {
        fprintf(stderr, "--source-sizes, --chunks and --seed require --experiment\n");
        exit(EXIT_FAILURE);
    }

    if (experiment && (is_test || is_bench_parse_enabled || compute_results)) {
        fprintf(stderr, "--experiment can't be used with -t, --bench-parse or --compute-results\n");
        exit(EXIT_FAILURE);
    }

    if (experiment && random_percent > 0) {
        fprintf(stderr, "--experiment and --use-random-percent can't be used together\n");
        exit(EXIT_FAILURE);
    }

    if (random_percent > 0 && use_start_nodes) {
        fprintf(stderr, "--use-random-percent and --use-start-nodes can't be used together\n");
        exit(EXIT_FAILURE);
    }
    // the random vertices replace the ones from the config file
    if (random_percent > 0) {
        use_start_nodes = true;
    }
    if (experiment) {
        use_start_nodes = true;
    }

    if (algo == NULL) {
        algo = registry_find(DEFAULT_ALGORITHM);
        adapter = algo->get_methods();
        printf("No algorithm chosen, using " DEFAULT_ALGORITHM " by default\n");
    }

    if (experiment && !algo->is_multiple_source) {
        fprintf(stderr, "--experiment is only supported for multiple-source algorithms\n");
        exit(EXIT_FAILURE);
    }

    if (rsm_lib != NULL && strcmp(algo->name, "CFL_CFPQ_RSM") != 0) {
        fprintf(stderr, "--rsm-lib is only supported by CFL_CFPQ_RSM\n");
        exit(EXIT_FAILURE);
    }

    if (results_file != NULL) {
        set_result_file(results_file);
    }

    AlgorithmOptions algo_options = {
        .optimizations = optimizations,
        .use_start_nodes = use_start_nodes,
        .use_cfpq = use_cfpq,
        .rsm_lib = rsm_lib,
    };

    if (is_test && !compute_results && algo->is_multiple_source) {
        fprintf(stderr,
                YELLOW "Warning: %s ignores the expected result from the config, "
                       "use --compute-results to check the result" RESET "\n",
                algo->name);
    }

    TRY(adapter.setup());

    if (!is_config) {
        fprintf(stderr, "Need to choose config by flag -c [config file]\n");
        exit(EXIT_FAILURE);
    }

    size_t configs_count = 0;
    char *config_text;
    config_row *configs = get_configs_from_file(input_config, &configs_count, &config_text);

    printf("Start bench\n");
    fflush(stdout);

    for (size_t i = 0; i < configs_count; i++) {
        config_row config = configs[i];
        printf("CONFIG: grammar: %s, graph: %s\n", config.grammar, config.graph);
        fflush(stdout);

        ParserResult parser_result = parser(config, is_bench_parse_enabled);
        if (is_bench_parse_enabled) {
            free_parser_result(&parser_result);
            continue;
        }
        if (random_percent > 0) {
            choose_random_start_nodes(&parser_result, random_percent);
        }

        if (experiment) {
            int experiment_status =
                run_experiment_config(&config, algo, &adapter, &algo_options, &parser_result, rounds_count,
                                      is_hot_enabled, source_sizes, source_sizes_count, chunks_count, experiment_seed);
            free_parser_result(&parser_result);
            if (experiment_status != EXIT_SUCCESS) {
                has_test_failure = true;
                break;
            }
            printf("\n");
            continue;
        }

        double *start = calloc(rounds_count, sizeof(double));
        double *end = calloc(rounds_count, sizeof(double));
        if (start == NULL || end == NULL) {
            fprintf(stderr, "Failed to allocate memory for benchmark rounds\n");
            free(start);
            free(end);
            exit(EXIT_FAILURE);
        }

        // computed before the tested algorithm: parser_result is freed after prepare and
        // the CFL_adv adapter state can't be shared with a tested CFL_adv run
        size_t expected_result = config.valid_result;
        bool is_cached = false;
        if (compute_results) {
            const char *kind = "pairs";
            char random_kind[64];
            const char *start_nodes = NULL;
            if (algo->is_multiple_source && random_percent > 0) {
                snprintf(random_kind, sizeof(random_kind), "random_%zu_percent_vertices", random_percent);
                kind = random_kind;
            } else if (algo->is_multiple_source) {
                kind = use_start_nodes ? "start_vertices" : "vertices";
                start_nodes = use_start_nodes ? config.start_nodes_path : NULL;
            }

            is_cached = computed_cache_get(kind, config.graph, config.grammar, start_nodes, &expected_result);
            if (!is_cached) {
                TRY(compute_expected_result(&parser_result, algo, use_start_nodes, &expected_result));
                computed_cache_put(kind, config.graph, config.grammar, start_nodes, expected_result);
            }
        }

        size_t run_source_size = 0;
        if (algo->is_multiple_source && use_start_nodes) {
            run_source_size = parser_result.start_nodes_count;
        }

        algo->prepare(&adapter, &parser_result, &algo_options);
        free_parser_result(&parser_result);

        bool is_hot = is_hot_enabled;

        size_t result = 0;
        ssize_t max_memory_kb = 0;
        for (size_t j = 0; j < rounds_count; j++) {
            TRY(adapter.init_outputs());

            // in some cases free don't change memory usage, so we need to reset it manually
            malloc_trim(0);
            if (mem_peak_reset() != 0) {
                fprintf(stderr, "Failed to reset memory peak\n");
                exit(EXIT_FAILURE);
            }

            start[j] = LAGraph_WallClockTime();
#ifndef CI
            retval = adapter.run();
#endif
            end[j] = LAGraph_WallClockTime();
            max_memory_kb = mem_get_peak_kb();

            if (is_test) {
                size_t result = 0;
                char status[256];
                if (retval != GrB_SUCCESS) {
                    // outputs are not valid after a failed run, so the result is not checked
                    has_test_failure = true;
                    snprintf(status, sizeof(status), RED "[Failed]" RESET);
                } else {
                    result = adapter.get_result();
                    ResultType result_type = RESULT_UNKNOWN;
                    if (compute_results) {
                        result_type = result == expected_result ? RESULT_OK : RESULT_ERROR;
                    } else {
                        result_type = adapter.is_result_valid(config.valid_result);
                    }
                    switch (result_type) {
                    case RESULT_OK:
                        snprintf(status, sizeof(status), GREEN "[OK]" RESET);
                        break;
                    case RESULT_ERROR:
                        has_test_failure = true;
                        snprintf(status, sizeof(status), RED "[Wrong] (Result must be %zu)" RESET, expected_result);
                        break;
                    case RESULT_UNKNOWN:
                        snprintf(status, sizeof(status), YELLOW "[Unknown]" RESET);
                        break;
                    default:
                        fprintf(stderr, "Unknown result type: %d\n", result_type);
                        abort();
                    }
                }

                printf("\tResult: %ld (Return code: %d) %s", result, retval, status);

                if (compute_results) {
                    printf(" (%s: %zu)", is_cached ? "Cached" : "Computed", expected_result);
                }

                if (retval != 0) {
                    printf("\t(MSG: %s)", msg);
                }
                printf(" (%.4f sec)", end[j] - start[j]);

                TRY(adapter.free_outputs());
                break;
            }

            if (is_hot) {
                is_hot = false;
                j--;
                TRY(adapter.free_outputs());
                continue;
            }

            printf("\t%.3fs", end[j] - start[j]);
            fflush(stdout);

            result = adapter.get_result();
            uint64_t result_hash = adapter.get_result_hash != NULL ? adapter.get_result_hash() : 0;
            TRY(adapter.free_outputs());
            save_result(algo->name, config.grammar, config.graph, run_source_size, j, result, result_hash,
                        max_memory_kb, end[j] - start[j]);
            // in some cases free don't change memory usage, so we need to reset it manually
            malloc_trim(0);
        }
        printf("\n");

        if (is_test) {
            free(start);
            free(end);
            adapter.cleanup();

            fflush(stdout);
            continue;
        }

        double sum = 0;
        for (size_t j = 0; j < rounds_count; j++) {
            sum += end[j] - start[j];
        }
        printf("\tTime elapsed (avg): %.6f seconds. %zd KB max memory. Result: %ld (return code "
               "%d) (%s)\n\n",
               sum / rounds_count, max_memory_kb, result, retval, msg);

        free(start);
        free(end);

        TRY(adapter.cleanup());

        fflush(stdout);
    }

    free(configs);
    free(config_text);
    if (source_sizes_allocated) {
        free(source_sizes);
    }
    TRY(adapter.teardown());
    return has_test_failure ? EXIT_FAILURE : EXIT_SUCCESS;
}
