# DeepSeek remainder — three candidates accepted (2026-11-02)

**R10 PREPARATION ACCEPTED — reviewer, 2026-11-02.** `d1_native`, `config_block` and `d3_masked_product` are complete and ready for the user-run experiment. D4/D5 are removed from scope. The specifications below are retained for reference; do not reimplement or rerun accepted preparation.

Reviewed evidence: `experimental/algorithm/cfpq_rsm_lab/build/r10-checks-8JIj2Bx9`. All 9 build/functional/lab steps succeeded; every candidate has `checks=453 failures=0`; all 63 lab summary rows match counts/hashes across the seven workloads and both baseline copies. Current source hashes match the report and smoke provenance. No additional workload run was needed.

The ten accepted R9 sources are unchanged. `run_r10_overnight.sh` passes Bash syntax and generates exactly 39 correctly configured comparison commands; `summarize_r10_overnight.py` includes all 13 variants and 273 workload/source result rows. No blocking issue was found. Timing and memory are not measured yet. D3's immediate control is d1_native; the standard morning summary reports ratios against frozen baseline, so inspect D3 versus D1 separately when interpreting masking gains.

User launch: `bash /home/hollow/repo/LAGraph/experimental/algorithm/cfpq_rsm_lab/run_r10_overnight.sh`. DeepSeek must not launch it, combine variants or promote changes without further instruction.

## Queue and status

| Variant | Reviewed status / control | Scope |
| --- | --- | --- |
| `d1_native.c` | Accepted; independent frozen-baseline variant | Native block P/calls; subtract before frontier reshape. |
| `config_block.c` | Accepted; independent frozen-baseline variant | All configuration relations QV x V, with implicit RSM routing. |
| `d3_masked_product.c` | Accepted; d1_native is its immediate control | Complemented visited mask on graph products; keep layout identical between control and candidate. |

D1/config_block use one configuration relation with Q state blocks. Graph relations remain V x V; no wide label packing is introduced.

## D1 — `variants/d1_native.c`: native block calls and lean Phase 5

Start from `experimental/algorithm/cfpq_rsm_lab/variants/baseline.c`, not DS-22 or a winner from the current batch. Let `B[q*V+u,v]` correspond to flat `M[q,u*V+v]`.

- Keep frontier M/M_new Q x V², and existing shift/unshift helpers. P, acc and M_call are QV x V. W/scratch during graph products are already QV x V. Graph adjacency/summaries stay V x V, RSM matrices Q x Q.
- Initialize P with `GxB_Matrix_reshapeDup(&P, M, false, Q*V, V, GrB_NULL)`. Row-major mapping (`false`) is mandatory.
- Keep the entry_vec reduction for each nonterminal. Collect calls directly as `(start_states[i]*V+v, v, true)` from entry vertices. Clear M_call once per iteration, accumulate tuples across boxes, and build it once with LOR duplicate handling after the nonterminal loop. Reuse capacity-managed tuple/index buffers. Do not create a diagonal matrix or reshape calls. Remove unused diag_entry/rsm_start matrix machinery, retaining validation.
- Preserve terminal products, summary products, W bookkeeping, return ordering and baseline operators. Do not add lazy bags, ANY_PAIR, masked scalar insertion, fused products or format tuning.
- Replace Phase 5 by exactly:

```c
GRB_TRY(GrB_eWiseAdd(acc, P, GrB_NULL, GrB_LOR, acc, M_call, GrB_DESC_RSC));
GRB_TRY(GrB_eWiseAdd(P, GrB_NULL, GrB_NULL, GrB_LOR, P, acc, GrB_NULL));
GRB_TRY(GrB_free(&M_new));
GRB_TRY(GxB_Matrix_reshapeDup(&M_new, acc, false, Q, V * V, GrB_NULL));
GRB_TRY(GrB_Matrix_clear(acc));
```

Then retain the baseline frontier swap and termination check. Clear M_call at the normal next-iteration boundary. No fresh_B or call reshapes. Only the fresh frontier is reshaped/copied; a denser matrix is not the objective. This removes overhead that measured DS-22 retained, so DS-22's loss does not settle this candidate.

Include call extraction/build and every reshape in timing. Build/test using `prepare_one d1_native`; long comparison uses `bench_one d1_native` at source sizes 1/10/100 after inclusion in a separately named future overnight script. These functions are defined in the current work order and require its LAB/EVIDENCE/OUT setup. Acceptance: existing --smoke plus all seven lab.csv pairs with matching counts/hashes. Direct flat calls DS-39 is a useful independent comparison, not a parent to silently copy.

## Full configuration layout — `variants/config_block.c`

Start independently from the same frozen baseline. Store frontier M/M_new, P, acc, M_call, W and configuration scratch as QV x V. Seed initial calls at `[start_state*V+s,s]`. Graph relations/summaries remain V x V and RSM relations remain Q x Q. No materialized Kronecker matrix.

Fixed routing recipe for future activation:

1. During setup extract the small RSM transitions into per-label adjacency lists q -> r. Retain exact labels, including repeated destination states.
2. At each iteration extract existing M tuples once. Decode q=row/V, u=row%V, v=column; bucket the tuples by q. Reuse extraction/bucket/route buffers. Do not allocate a dense QV activity array or scan all V vertices per RSM transition.
3. To shift one label, visit its q -> r edges and emit `(r*V+u,v,true)` for every existing tuple in bucket q. Build one cleared QV x V scratch with LOR duplicate handling. Multiple predecessor states may reach the same configuration. This replaces small RSM mxm plus reshape, not the subsequent graph product.
4. Terminal propagation is the baseline graph product `acc |= scratch * graph_term[t]`. Nonterminal propagation uses identical routing, direct block call insertion from entry vertices, the baseline summary product and W union. Preserve W-before-return ordering.
5. For Phase 4, visit the same frontier buckets for each box's final states and bulk-build V x V summary candidates `(u,v)`. Keep baseline subtraction against graph_nt, summary union and W*dG ordering. Final-state membership comes from the existing vectors extracted during setup.
6. Phase 5 overwrites block M_new with `(acc OR M_call) minus P`, unions M_new into P, clears acc and swaps frontiers. No frontier/call reshape or reshapeDup anywhere. Clear M_call at its normal boundary.
7. Keep semirings, state unions, input contract and result unchanged. Include extraction, routing, sorting/bucketing, tuple builds and setup in timing. Routing may cost more than the baseline; report the result without redesign.

Build/test: `prepare_one config_block`; benchmark source sizes 1/10/100 with the common commands after a future script is prepared. Same seven-pair count/hash pass condition. This is independent of D1; do not combine it with current experiments.

## D3 — visited-mask products, separate from layout

This candidate isolates visited masking from its D1 layout control.

After d1_native has passed, copy it to `variants/d3_masked_product.c` and retain d1_native as the immediate control. In its graph-product helper, change only the overwrite product to:

```c
GrB_mxm(T, P, GrB_NULL, GrB_LOR_LAND_SEMIRING_BOOL, A, B, GrB_DESC_RSC)
```

Pass the block-shaped visited P to the helper. Apply to terminal, summary-skip and return graph products, all of which output QV x V. Keep the subsequent acc union, final Phase 5 subtraction, iteration schedule and calls unchanged. Do not mask the flat Q x V² RSM shift. Do not introduce fused accumulation in this candidate. This tests masked product construction; whether the selected SuiteSparse kernels save work is a measurement question.

Use the same smoke/lab checks against frozen baseline for result correctness, and timing against both frozen baseline and d1_native to distinguish layout from masking. No sanitizer sweep or formal proof request.



## Current handoff

All three candidates and the ten R9 variants are accepted for the same user-run overnight experiment. Use the R10 driver above, which preserves sequential execution, duplicate baselines, all lab.csv workloads, source counts 1/10/100, 30 chunks, 5 rounds, 1 warm-up, seed 2026, unrestricted threads, separate artifacts and failure continuation. The old preparation recipes above are historical. Do not reopen accepted checks or combine optimizations before their measurements are known.
